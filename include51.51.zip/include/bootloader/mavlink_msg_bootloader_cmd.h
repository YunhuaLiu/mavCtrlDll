// MESSAGE BOOTLOADER_CMD PACKING

#if MAVLINK_C2000
#include "../protocol_c2000.h"
#endif

#define MAVLINK_MSG_ID_BOOTLOADER_CMD 171

typedef struct __mavlink_bootloader_cmd_t
{
 uint16_t num_packets; /*< Number of packets to be sent to upload new image*/
 uint16_t crc; /*< New image checksum*/
 uint8_t target_component; /*< Target component id. See KIRKWOOD_COMP_ID*/
 uint8_t cmd; /*< See BOOTLOADER_CMD_xxx*/
} mavlink_bootloader_cmd_t;

#define MAVLINK_MSG_ID_BOOTLOADER_CMD_LEN 6
#define MAVLINK_MSG_ID_171_LEN 6

#define MAVLINK_MSG_ID_BOOTLOADER_CMD_CRC 232
#define MAVLINK_MSG_ID_171_CRC 232



#define MAVLINK_MESSAGE_INFO_BOOTLOADER_CMD { \
	"BOOTLOADER_CMD", \
	4, \
	{  { "num_packets", NULL, MAVLINK_TYPE_UINT16_T, 0, 0, offsetof(mavlink_bootloader_cmd_t, num_packets) }, \
         { "crc", NULL, MAVLINK_TYPE_UINT16_T, 0, 2, offsetof(mavlink_bootloader_cmd_t, crc) }, \
         { "target_component", NULL, MAVLINK_TYPE_UINT8_T, 0, 4, offsetof(mavlink_bootloader_cmd_t, target_component) }, \
         { "cmd", NULL, MAVLINK_TYPE_UINT8_T, 0, 5, offsetof(mavlink_bootloader_cmd_t, cmd) }, \
         } \
}


/**
 * @brief Pack a bootloader_cmd message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param target_component Target component id. See KIRKWOOD_COMP_ID
 * @param cmd See BOOTLOADER_CMD_xxx
 * @param num_packets Number of packets to be sent to upload new image
 * @param crc New image checksum
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_bootloader_cmd_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
						       uint8_t target_component, uint8_t cmd, uint16_t num_packets, uint16_t crc)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_BOOTLOADER_CMD_LEN];
	_mav_put_uint16_t(buf, 0, num_packets);
	_mav_put_uint16_t(buf, 2, crc);
	_mav_put_uint8_t(buf, 4, target_component);
	_mav_put_uint8_t(buf, 5, cmd);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_BOOTLOADER_CMD_LEN);
#elif MAVLINK_C2000
		mav_put_uint16_t_c2000(&(msg->payload64[0]), 0, num_packets);
		mav_put_uint16_t_c2000(&(msg->payload64[0]), 2, crc);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 4, target_component);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 5, cmd);
	
	
#else
	mavlink_bootloader_cmd_t packet;
	packet.num_packets = num_packets;
	packet.crc = crc;
	packet.target_component = target_component;
	packet.cmd = cmd;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_BOOTLOADER_CMD_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_BOOTLOADER_CMD;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_BOOTLOADER_CMD_LEN, MAVLINK_MSG_ID_BOOTLOADER_CMD_CRC);
#else
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_BOOTLOADER_CMD_LEN);
#endif
}

/**
 * @brief Pack a bootloader_cmd message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param target_component Target component id. See KIRKWOOD_COMP_ID
 * @param cmd See BOOTLOADER_CMD_xxx
 * @param num_packets Number of packets to be sent to upload new image
 * @param crc New image checksum
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_bootloader_cmd_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
							   mavlink_message_t* msg,
						           uint8_t target_component,uint8_t cmd,uint16_t num_packets,uint16_t crc)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_BOOTLOADER_CMD_LEN];
	_mav_put_uint16_t(buf, 0, num_packets);
	_mav_put_uint16_t(buf, 2, crc);
	_mav_put_uint8_t(buf, 4, target_component);
	_mav_put_uint8_t(buf, 5, cmd);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_BOOTLOADER_CMD_LEN);
#else
	mavlink_bootloader_cmd_t packet;
	packet.num_packets = num_packets;
	packet.crc = crc;
	packet.target_component = target_component;
	packet.cmd = cmd;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_BOOTLOADER_CMD_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_BOOTLOADER_CMD;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_BOOTLOADER_CMD_LEN, MAVLINK_MSG_ID_BOOTLOADER_CMD_CRC);
#else
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_BOOTLOADER_CMD_LEN);
#endif
}

/**
 * @brief Encode a bootloader_cmd struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param bootloader_cmd C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_bootloader_cmd_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_bootloader_cmd_t* bootloader_cmd)
{
	return mavlink_msg_bootloader_cmd_pack(system_id, component_id, msg, bootloader_cmd->target_component, bootloader_cmd->cmd, bootloader_cmd->num_packets, bootloader_cmd->crc);
}

/**
 * @brief Encode a bootloader_cmd struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param bootloader_cmd C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_bootloader_cmd_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_bootloader_cmd_t* bootloader_cmd)
{
	return mavlink_msg_bootloader_cmd_pack_chan(system_id, component_id, chan, msg, bootloader_cmd->target_component, bootloader_cmd->cmd, bootloader_cmd->num_packets, bootloader_cmd->crc);
}

/**
 * @brief Send a bootloader_cmd message
 * @param chan MAVLink channel to send the message
 *
 * @param target_component Target component id. See KIRKWOOD_COMP_ID
 * @param cmd See BOOTLOADER_CMD_xxx
 * @param num_packets Number of packets to be sent to upload new image
 * @param crc New image checksum
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_bootloader_cmd_send(mavlink_channel_t chan, uint8_t target_component, uint8_t cmd, uint16_t num_packets, uint16_t crc)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_BOOTLOADER_CMD_LEN];
	_mav_put_uint16_t(buf, 0, num_packets);
	_mav_put_uint16_t(buf, 2, crc);
	_mav_put_uint8_t(buf, 4, target_component);
	_mav_put_uint8_t(buf, 5, cmd);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_BOOTLOADER_CMD, buf, MAVLINK_MSG_ID_BOOTLOADER_CMD_LEN, MAVLINK_MSG_ID_BOOTLOADER_CMD_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_BOOTLOADER_CMD, buf, MAVLINK_MSG_ID_BOOTLOADER_CMD_LEN);
#endif
#else
	mavlink_bootloader_cmd_t packet;
	packet.num_packets = num_packets;
	packet.crc = crc;
	packet.target_component = target_component;
	packet.cmd = cmd;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_BOOTLOADER_CMD, (const char *)&packet, MAVLINK_MSG_ID_BOOTLOADER_CMD_LEN, MAVLINK_MSG_ID_BOOTLOADER_CMD_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_BOOTLOADER_CMD, (const char *)&packet, MAVLINK_MSG_ID_BOOTLOADER_CMD_LEN);
#endif
#endif
}

#if MAVLINK_MSG_ID_BOOTLOADER_CMD_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_bootloader_cmd_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint8_t target_component, uint8_t cmd, uint16_t num_packets, uint16_t crc)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char *buf = (char *)msgbuf;
	_mav_put_uint16_t(buf, 0, num_packets);
	_mav_put_uint16_t(buf, 2, crc);
	_mav_put_uint8_t(buf, 4, target_component);
	_mav_put_uint8_t(buf, 5, cmd);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_BOOTLOADER_CMD, buf, MAVLINK_MSG_ID_BOOTLOADER_CMD_LEN, MAVLINK_MSG_ID_BOOTLOADER_CMD_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_BOOTLOADER_CMD, buf, MAVLINK_MSG_ID_BOOTLOADER_CMD_LEN);
#endif
#else
	mavlink_bootloader_cmd_t *packet = (mavlink_bootloader_cmd_t *)msgbuf;
	packet->num_packets = num_packets;
	packet->crc = crc;
	packet->target_component = target_component;
	packet->cmd = cmd;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_BOOTLOADER_CMD, (const char *)packet, MAVLINK_MSG_ID_BOOTLOADER_CMD_LEN, MAVLINK_MSG_ID_BOOTLOADER_CMD_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_BOOTLOADER_CMD, (const char *)packet, MAVLINK_MSG_ID_BOOTLOADER_CMD_LEN);
#endif
#endif
}
#endif

#endif

// MESSAGE BOOTLOADER_CMD UNPACKING


/**
 * @brief Get field target_component from bootloader_cmd message
 *
 * @return Target component id. See KIRKWOOD_COMP_ID
 */
static inline uint8_t mavlink_msg_bootloader_cmd_get_target_component(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  4);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  4);
#endif
}

/**
 * @brief Get field cmd from bootloader_cmd message
 *
 * @return See BOOTLOADER_CMD_xxx
 */
static inline uint8_t mavlink_msg_bootloader_cmd_get_cmd(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  5);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  5);
#endif
}

/**
 * @brief Get field num_packets from bootloader_cmd message
 *
 * @return Number of packets to be sent to upload new image
 */
static inline uint16_t mavlink_msg_bootloader_cmd_get_num_packets(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint16_t(msg,  0);
#else
	return mav_get_uint16_t_c2000(&(msg->payload64[0]),  0);
#endif
}

/**
 * @brief Get field crc from bootloader_cmd message
 *
 * @return New image checksum
 */
static inline uint16_t mavlink_msg_bootloader_cmd_get_crc(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint16_t(msg,  2);
#else
	return mav_get_uint16_t_c2000(&(msg->payload64[0]),  2);
#endif
}

/**
 * @brief Decode a bootloader_cmd message into a struct
 *
 * @param msg The message to decode
 * @param bootloader_cmd C-struct to decode the message contents into
 */
static inline void mavlink_msg_bootloader_cmd_decode(const mavlink_message_t* msg, mavlink_bootloader_cmd_t* bootloader_cmd)
{
#if MAVLINK_NEED_BYTE_SWAP || MAVLINK_C2000
	bootloader_cmd->num_packets = mavlink_msg_bootloader_cmd_get_num_packets(msg);
	bootloader_cmd->crc = mavlink_msg_bootloader_cmd_get_crc(msg);
	bootloader_cmd->target_component = mavlink_msg_bootloader_cmd_get_target_component(msg);
	bootloader_cmd->cmd = mavlink_msg_bootloader_cmd_get_cmd(msg);
#else
	memcpy(bootloader_cmd, _MAV_PAYLOAD(msg), MAVLINK_MSG_ID_BOOTLOADER_CMD_LEN);
#endif
}
