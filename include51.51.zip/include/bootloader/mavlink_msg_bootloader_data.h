// MESSAGE BOOTLOADER_DATA PACKING

#if MAVLINK_C2000
#include "../protocol_c2000.h"
#endif

#define MAVLINK_MSG_ID_BOOTLOADER_DATA 172

typedef struct __mavlink_bootloader_data_t
{
 uint16_t packet_num; /*< Packet sequence. Starts at 0 for the first packet. Incremented for every packet. Corresponds to num_packets in _CMD*/
 uint16_t data[124]; /*< Section data*/
 uint8_t target_component; /*< Target component id. See KIRKWOOD_COMP_ID*/
 uint8_t memory_align_byte; /*< Unused*/
} mavlink_bootloader_data_t;

#define MAVLINK_MSG_ID_BOOTLOADER_DATA_LEN 252
#define MAVLINK_MSG_ID_172_LEN 252

#define MAVLINK_MSG_ID_BOOTLOADER_DATA_CRC 227
#define MAVLINK_MSG_ID_172_CRC 227

#define MAVLINK_MSG_BOOTLOADER_DATA_FIELD_DATA_LEN 124

#define MAVLINK_MESSAGE_INFO_BOOTLOADER_DATA { \
	"BOOTLOADER_DATA", \
	4, \
	{  { "packet_num", NULL, MAVLINK_TYPE_UINT16_T, 0, 0, offsetof(mavlink_bootloader_data_t, packet_num) }, \
         { "data", NULL, MAVLINK_TYPE_UINT16_T, 124, 2, offsetof(mavlink_bootloader_data_t, data) }, \
         { "target_component", NULL, MAVLINK_TYPE_UINT8_T, 0, 250, offsetof(mavlink_bootloader_data_t, target_component) }, \
         { "memory_align_byte", NULL, MAVLINK_TYPE_UINT8_T, 0, 251, offsetof(mavlink_bootloader_data_t, memory_align_byte) }, \
         } \
}


/**
 * @brief Pack a bootloader_data message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param target_component Target component id. See KIRKWOOD_COMP_ID
 * @param memory_align_byte Unused
 * @param packet_num Packet sequence. Starts at 0 for the first packet. Incremented for every packet. Corresponds to num_packets in _CMD
 * @param data Section data
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_bootloader_data_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
						       uint8_t target_component, uint8_t memory_align_byte, uint16_t packet_num, const uint16_t *data)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_BOOTLOADER_DATA_LEN];
	_mav_put_uint16_t(buf, 0, packet_num);
	_mav_put_uint8_t(buf, 250, target_component);
	_mav_put_uint8_t(buf, 251, memory_align_byte);
	_mav_put_uint16_t_array(buf, 2, data, 124);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_BOOTLOADER_DATA_LEN);
#elif MAVLINK_C2000
		mav_put_uint16_t_c2000(&(msg->payload64[0]), 0, packet_num);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 250, target_component);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 251, memory_align_byte);
	
		mav_put_uint16_t_array_c2000(&(msg->payload64[0]), data, 2, 124);
	
#else
	mavlink_bootloader_data_t packet;
	packet.packet_num = packet_num;
	packet.target_component = target_component;
	packet.memory_align_byte = memory_align_byte;
	mav_array_memcpy(packet.data, data, sizeof(uint16_t)*124);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_BOOTLOADER_DATA_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_BOOTLOADER_DATA;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_BOOTLOADER_DATA_LEN, MAVLINK_MSG_ID_BOOTLOADER_DATA_CRC);
#else
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_BOOTLOADER_DATA_LEN);
#endif
}

/**
 * @brief Pack a bootloader_data message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param target_component Target component id. See KIRKWOOD_COMP_ID
 * @param memory_align_byte Unused
 * @param packet_num Packet sequence. Starts at 0 for the first packet. Incremented for every packet. Corresponds to num_packets in _CMD
 * @param data Section data
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_bootloader_data_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
							   mavlink_message_t* msg,
						           uint8_t target_component,uint8_t memory_align_byte,uint16_t packet_num,const uint16_t *data)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_BOOTLOADER_DATA_LEN];
	_mav_put_uint16_t(buf, 0, packet_num);
	_mav_put_uint8_t(buf, 250, target_component);
	_mav_put_uint8_t(buf, 251, memory_align_byte);
	_mav_put_uint16_t_array(buf, 2, data, 124);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_BOOTLOADER_DATA_LEN);
#else
	mavlink_bootloader_data_t packet;
	packet.packet_num = packet_num;
	packet.target_component = target_component;
	packet.memory_align_byte = memory_align_byte;
	mav_array_memcpy(packet.data, data, sizeof(uint16_t)*124);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_BOOTLOADER_DATA_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_BOOTLOADER_DATA;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_BOOTLOADER_DATA_LEN, MAVLINK_MSG_ID_BOOTLOADER_DATA_CRC);
#else
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_BOOTLOADER_DATA_LEN);
#endif
}

/**
 * @brief Encode a bootloader_data struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param bootloader_data C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_bootloader_data_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_bootloader_data_t* bootloader_data)
{
	return mavlink_msg_bootloader_data_pack(system_id, component_id, msg, bootloader_data->target_component, bootloader_data->memory_align_byte, bootloader_data->packet_num, bootloader_data->data);
}

/**
 * @brief Encode a bootloader_data struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param bootloader_data C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_bootloader_data_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_bootloader_data_t* bootloader_data)
{
	return mavlink_msg_bootloader_data_pack_chan(system_id, component_id, chan, msg, bootloader_data->target_component, bootloader_data->memory_align_byte, bootloader_data->packet_num, bootloader_data->data);
}

/**
 * @brief Send a bootloader_data message
 * @param chan MAVLink channel to send the message
 *
 * @param target_component Target component id. See KIRKWOOD_COMP_ID
 * @param memory_align_byte Unused
 * @param packet_num Packet sequence. Starts at 0 for the first packet. Incremented for every packet. Corresponds to num_packets in _CMD
 * @param data Section data
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_bootloader_data_send(mavlink_channel_t chan, uint8_t target_component, uint8_t memory_align_byte, uint16_t packet_num, const uint16_t *data)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_BOOTLOADER_DATA_LEN];
	_mav_put_uint16_t(buf, 0, packet_num);
	_mav_put_uint8_t(buf, 250, target_component);
	_mav_put_uint8_t(buf, 251, memory_align_byte);
	_mav_put_uint16_t_array(buf, 2, data, 124);
#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_BOOTLOADER_DATA, buf, MAVLINK_MSG_ID_BOOTLOADER_DATA_LEN, MAVLINK_MSG_ID_BOOTLOADER_DATA_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_BOOTLOADER_DATA, buf, MAVLINK_MSG_ID_BOOTLOADER_DATA_LEN);
#endif
#else
	mavlink_bootloader_data_t packet;
	packet.packet_num = packet_num;
	packet.target_component = target_component;
	packet.memory_align_byte = memory_align_byte;
	mav_array_memcpy(packet.data, data, sizeof(uint16_t)*124);
#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_BOOTLOADER_DATA, (const char *)&packet, MAVLINK_MSG_ID_BOOTLOADER_DATA_LEN, MAVLINK_MSG_ID_BOOTLOADER_DATA_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_BOOTLOADER_DATA, (const char *)&packet, MAVLINK_MSG_ID_BOOTLOADER_DATA_LEN);
#endif
#endif
}

#if MAVLINK_MSG_ID_BOOTLOADER_DATA_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_bootloader_data_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint8_t target_component, uint8_t memory_align_byte, uint16_t packet_num, const uint16_t *data)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char *buf = (char *)msgbuf;
	_mav_put_uint16_t(buf, 0, packet_num);
	_mav_put_uint8_t(buf, 250, target_component);
	_mav_put_uint8_t(buf, 251, memory_align_byte);
	_mav_put_uint16_t_array(buf, 2, data, 124);
#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_BOOTLOADER_DATA, buf, MAVLINK_MSG_ID_BOOTLOADER_DATA_LEN, MAVLINK_MSG_ID_BOOTLOADER_DATA_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_BOOTLOADER_DATA, buf, MAVLINK_MSG_ID_BOOTLOADER_DATA_LEN);
#endif
#else
	mavlink_bootloader_data_t *packet = (mavlink_bootloader_data_t *)msgbuf;
	packet->packet_num = packet_num;
	packet->target_component = target_component;
	packet->memory_align_byte = memory_align_byte;
	mav_array_memcpy(packet->data, data, sizeof(uint16_t)*124);
#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_BOOTLOADER_DATA, (const char *)packet, MAVLINK_MSG_ID_BOOTLOADER_DATA_LEN, MAVLINK_MSG_ID_BOOTLOADER_DATA_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_BOOTLOADER_DATA, (const char *)packet, MAVLINK_MSG_ID_BOOTLOADER_DATA_LEN);
#endif
#endif
}
#endif

#endif

// MESSAGE BOOTLOADER_DATA UNPACKING


/**
 * @brief Get field target_component from bootloader_data message
 *
 * @return Target component id. See KIRKWOOD_COMP_ID
 */
static inline uint8_t mavlink_msg_bootloader_data_get_target_component(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  250);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  250);
#endif
}

/**
 * @brief Get field memory_align_byte from bootloader_data message
 *
 * @return Unused
 */
static inline uint8_t mavlink_msg_bootloader_data_get_memory_align_byte(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  251);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  251);
#endif
}

/**
 * @brief Get field packet_num from bootloader_data message
 *
 * @return Packet sequence. Starts at 0 for the first packet. Incremented for every packet. Corresponds to num_packets in _CMD
 */
static inline uint16_t mavlink_msg_bootloader_data_get_packet_num(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint16_t(msg,  0);
#else
	return mav_get_uint16_t_c2000(&(msg->payload64[0]),  0);
#endif
}

/**
 * @brief Get field data from bootloader_data message
 *
 * @return Section data
 */
static inline uint16_t mavlink_msg_bootloader_data_get_data(const mavlink_message_t* msg, uint16_t *data)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint16_t_array(msg, data, 124,  2);
#else
	return mav_get_uint16_t_array_c2000(&(msg->payload64[0]), data, 124,  2);
#endif
}

/**
 * @brief Decode a bootloader_data message into a struct
 *
 * @param msg The message to decode
 * @param bootloader_data C-struct to decode the message contents into
 */
static inline void mavlink_msg_bootloader_data_decode(const mavlink_message_t* msg, mavlink_bootloader_data_t* bootloader_data)
{
#if MAVLINK_NEED_BYTE_SWAP || MAVLINK_C2000
	bootloader_data->packet_num = mavlink_msg_bootloader_data_get_packet_num(msg);
	mavlink_msg_bootloader_data_get_data(msg, bootloader_data->data);
	bootloader_data->target_component = mavlink_msg_bootloader_data_get_target_component(msg);
	bootloader_data->memory_align_byte = mavlink_msg_bootloader_data_get_memory_align_byte(msg);
#else
	memcpy(bootloader_data, _MAV_PAYLOAD(msg), MAVLINK_MSG_ID_BOOTLOADER_DATA_LEN);
#endif
}
