/** @file
 *	@brief MAVLink comm protocol testsuite generated from bootloader.xml
 *	@see http://qgroundcontrol.org/mavlink/
 */
#ifndef BOOTLOADER_TESTSUITE_H
#define BOOTLOADER_TESTSUITE_H

#ifdef __cplusplus
extern "C" {
#endif

#ifndef MAVLINK_TEST_ALL
#define MAVLINK_TEST_ALL
static void mavlink_test_kirkwood_component_id(uint8_t, uint8_t, mavlink_message_t *last_msg);
static void mavlink_test_bootloader(uint8_t, uint8_t, mavlink_message_t *last_msg);

static void mavlink_test_all(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
	mavlink_test_kirkwood_component_id(system_id, component_id, last_msg);
	mavlink_test_bootloader(system_id, component_id, last_msg);
}
#endif

#include "../kirkwood_component_id/testsuite.h"


static void mavlink_test_bootloader_handshake(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
	mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
	mavlink_bootloader_handshake_t packet_in = {
		963497464,17443,17547,17651,163,230
    };
	mavlink_bootloader_handshake_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        	packet1.fw_version = packet_in.fw_version;
        	packet1.product_id = packet_in.product_id;
        	packet1.crc = packet_in.crc;
        	packet1.status = packet_in.status;
        	packet1.target_component = packet_in.target_component;
        	packet1.ack = packet_in.ack;
        
        

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_bootloader_handshake_encode(system_id, component_id, &msg, &packet1);
	mavlink_msg_bootloader_handshake_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_bootloader_handshake_pack(system_id, component_id, &msg , packet1.target_component , packet1.ack , packet1.product_id , packet1.fw_version , packet1.crc , packet1.status );
	mavlink_msg_bootloader_handshake_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_bootloader_handshake_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.target_component , packet1.ack , packet1.product_id , packet1.fw_version , packet1.crc , packet1.status );
	mavlink_msg_bootloader_handshake_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
        	comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
	mavlink_msg_bootloader_handshake_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_bootloader_handshake_send(MAVLINK_COMM_1 , packet1.target_component , packet1.ack , packet1.product_id , packet1.fw_version , packet1.crc , packet1.status );
	mavlink_msg_bootloader_handshake_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
}

static void mavlink_test_bootloader_cmd(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
	mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
	mavlink_bootloader_cmd_t packet_in = {
		17235,17339,17,84
    };
	mavlink_bootloader_cmd_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        	packet1.num_packets = packet_in.num_packets;
        	packet1.crc = packet_in.crc;
        	packet1.target_component = packet_in.target_component;
        	packet1.cmd = packet_in.cmd;
        
        

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_bootloader_cmd_encode(system_id, component_id, &msg, &packet1);
	mavlink_msg_bootloader_cmd_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_bootloader_cmd_pack(system_id, component_id, &msg , packet1.target_component , packet1.cmd , packet1.num_packets , packet1.crc );
	mavlink_msg_bootloader_cmd_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_bootloader_cmd_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.target_component , packet1.cmd , packet1.num_packets , packet1.crc );
	mavlink_msg_bootloader_cmd_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
        	comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
	mavlink_msg_bootloader_cmd_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_bootloader_cmd_send(MAVLINK_COMM_1 , packet1.target_component , packet1.cmd , packet1.num_packets , packet1.crc );
	mavlink_msg_bootloader_cmd_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
}

static void mavlink_test_bootloader_data(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
	mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
	mavlink_bootloader_data_t packet_in = {
		17235,{ 17339, 17340, 17341, 17342, 17343, 17344, 17345, 17346, 17347, 17348, 17349, 17350, 17351, 17352, 17353, 17354, 17355, 17356, 17357, 17358, 17359, 17360, 17361, 17362, 17363, 17364, 17365, 17366, 17367, 17368, 17369, 17370, 17371, 17372, 17373, 17374, 17375, 17376, 17377, 17378, 17379, 17380, 17381, 17382, 17383, 17384, 17385, 17386, 17387, 17388, 17389, 17390, 17391, 17392, 17393, 17394, 17395, 17396, 17397, 17398, 17399, 17400, 17401, 17402, 17403, 17404, 17405, 17406, 17407, 17408, 17409, 17410, 17411, 17412, 17413, 17414, 17415, 17416, 17417, 17418, 17419, 17420, 17421, 17422, 17423, 17424, 17425, 17426, 17427, 17428, 17429, 17430, 17431, 17432, 17433, 17434, 17435, 17436, 17437, 17438, 17439, 17440, 17441, 17442, 17443, 17444, 17445, 17446, 17447, 17448, 17449, 17450, 17451, 17452, 17453, 17454, 17455, 17456, 17457, 17458, 17459, 17460, 17461, 17462 },115,182
    };
	mavlink_bootloader_data_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        	packet1.packet_num = packet_in.packet_num;
        	packet1.target_component = packet_in.target_component;
        	packet1.memory_align_byte = packet_in.memory_align_byte;
        
        	mav_array_memcpy(packet1.data, packet_in.data, sizeof(uint16_t)*124);
        

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_bootloader_data_encode(system_id, component_id, &msg, &packet1);
	mavlink_msg_bootloader_data_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_bootloader_data_pack(system_id, component_id, &msg , packet1.target_component , packet1.memory_align_byte , packet1.packet_num , packet1.data );
	mavlink_msg_bootloader_data_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_bootloader_data_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.target_component , packet1.memory_align_byte , packet1.packet_num , packet1.data );
	mavlink_msg_bootloader_data_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
        	comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
	mavlink_msg_bootloader_data_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_bootloader_data_send(MAVLINK_COMM_1 , packet1.target_component , packet1.memory_align_byte , packet1.packet_num , packet1.data );
	mavlink_msg_bootloader_data_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
}

static void mavlink_test_bootloader(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
	mavlink_test_bootloader_handshake(system_id, component_id, last_msg);
	mavlink_test_bootloader_cmd(system_id, component_id, last_msg);
	mavlink_test_bootloader_data(system_id, component_id, last_msg);
}

#ifdef __cplusplus
}
#endif // __cplusplus
#endif // BOOTLOADER_TESTSUITE_H
