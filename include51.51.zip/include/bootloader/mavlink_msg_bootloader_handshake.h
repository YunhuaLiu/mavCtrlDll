// MESSAGE BOOTLOADER_HANDSHAKE PACKING

#if MAVLINK_C2000
#include "../protocol_c2000.h"
#endif

#define MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE 170

typedef struct __mavlink_bootloader_handshake_t
{
 uint32_t fw_version; /*< 4 version numbers. 1 byte each. Following Kirkwood FW version spec*/
 uint16_t product_id; /*< Differentiate hardware. See HARDWARE_REVISION_xxx*/
 uint16_t crc; /*< Main app image checksum*/
 uint16_t status; /*< Bitmask. See BOOTLOADER_HS_STATUS_xxx*/
 uint8_t target_component; /*< Target component id. See KIRKWOOD_COMP_ID*/
 uint8_t ack; /*< Set to 0 when initializing handshake, 1 when acknowledging*/
} mavlink_bootloader_handshake_t;

#define MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE_LEN 12
#define MAVLINK_MSG_ID_170_LEN 12

#define MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE_CRC 24
#define MAVLINK_MSG_ID_170_CRC 24



#define MAVLINK_MESSAGE_INFO_BOOTLOADER_HANDSHAKE { \
	"BOOTLOADER_HANDSHAKE", \
	6, \
	{  { "fw_version", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_bootloader_handshake_t, fw_version) }, \
         { "product_id", NULL, MAVLINK_TYPE_UINT16_T, 0, 4, offsetof(mavlink_bootloader_handshake_t, product_id) }, \
         { "crc", NULL, MAVLINK_TYPE_UINT16_T, 0, 6, offsetof(mavlink_bootloader_handshake_t, crc) }, \
         { "status", NULL, MAVLINK_TYPE_UINT16_T, 0, 8, offsetof(mavlink_bootloader_handshake_t, status) }, \
         { "target_component", NULL, MAVLINK_TYPE_UINT8_T, 0, 10, offsetof(mavlink_bootloader_handshake_t, target_component) }, \
         { "ack", NULL, MAVLINK_TYPE_UINT8_T, 0, 11, offsetof(mavlink_bootloader_handshake_t, ack) }, \
         } \
}


/**
 * @brief Pack a bootloader_handshake message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param target_component Target component id. See KIRKWOOD_COMP_ID
 * @param ack Set to 0 when initializing handshake, 1 when acknowledging
 * @param product_id Differentiate hardware. See HARDWARE_REVISION_xxx
 * @param fw_version 4 version numbers. 1 byte each. Following Kirkwood FW version spec
 * @param crc Main app image checksum
 * @param status Bitmask. See BOOTLOADER_HS_STATUS_xxx
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_bootloader_handshake_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
						       uint8_t target_component, uint8_t ack, uint16_t product_id, uint32_t fw_version, uint16_t crc, uint16_t status)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE_LEN];
	_mav_put_uint32_t(buf, 0, fw_version);
	_mav_put_uint16_t(buf, 4, product_id);
	_mav_put_uint16_t(buf, 6, crc);
	_mav_put_uint16_t(buf, 8, status);
	_mav_put_uint8_t(buf, 10, target_component);
	_mav_put_uint8_t(buf, 11, ack);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE_LEN);
#elif MAVLINK_C2000
		mav_put_uint32_t_c2000(&(msg->payload64[0]), 0, fw_version);
		mav_put_uint16_t_c2000(&(msg->payload64[0]), 4, product_id);
		mav_put_uint16_t_c2000(&(msg->payload64[0]), 6, crc);
		mav_put_uint16_t_c2000(&(msg->payload64[0]), 8, status);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 10, target_component);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 11, ack);
	
	
#else
	mavlink_bootloader_handshake_t packet;
	packet.fw_version = fw_version;
	packet.product_id = product_id;
	packet.crc = crc;
	packet.status = status;
	packet.target_component = target_component;
	packet.ack = ack;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE_LEN, MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE_CRC);
#else
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE_LEN);
#endif
}

/**
 * @brief Pack a bootloader_handshake message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param target_component Target component id. See KIRKWOOD_COMP_ID
 * @param ack Set to 0 when initializing handshake, 1 when acknowledging
 * @param product_id Differentiate hardware. See HARDWARE_REVISION_xxx
 * @param fw_version 4 version numbers. 1 byte each. Following Kirkwood FW version spec
 * @param crc Main app image checksum
 * @param status Bitmask. See BOOTLOADER_HS_STATUS_xxx
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_bootloader_handshake_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
							   mavlink_message_t* msg,
						           uint8_t target_component,uint8_t ack,uint16_t product_id,uint32_t fw_version,uint16_t crc,uint16_t status)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE_LEN];
	_mav_put_uint32_t(buf, 0, fw_version);
	_mav_put_uint16_t(buf, 4, product_id);
	_mav_put_uint16_t(buf, 6, crc);
	_mav_put_uint16_t(buf, 8, status);
	_mav_put_uint8_t(buf, 10, target_component);
	_mav_put_uint8_t(buf, 11, ack);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE_LEN);
#else
	mavlink_bootloader_handshake_t packet;
	packet.fw_version = fw_version;
	packet.product_id = product_id;
	packet.crc = crc;
	packet.status = status;
	packet.target_component = target_component;
	packet.ack = ack;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE_LEN, MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE_CRC);
#else
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE_LEN);
#endif
}

/**
 * @brief Encode a bootloader_handshake struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param bootloader_handshake C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_bootloader_handshake_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_bootloader_handshake_t* bootloader_handshake)
{
	return mavlink_msg_bootloader_handshake_pack(system_id, component_id, msg, bootloader_handshake->target_component, bootloader_handshake->ack, bootloader_handshake->product_id, bootloader_handshake->fw_version, bootloader_handshake->crc, bootloader_handshake->status);
}

/**
 * @brief Encode a bootloader_handshake struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param bootloader_handshake C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_bootloader_handshake_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_bootloader_handshake_t* bootloader_handshake)
{
	return mavlink_msg_bootloader_handshake_pack_chan(system_id, component_id, chan, msg, bootloader_handshake->target_component, bootloader_handshake->ack, bootloader_handshake->product_id, bootloader_handshake->fw_version, bootloader_handshake->crc, bootloader_handshake->status);
}

/**
 * @brief Send a bootloader_handshake message
 * @param chan MAVLink channel to send the message
 *
 * @param target_component Target component id. See KIRKWOOD_COMP_ID
 * @param ack Set to 0 when initializing handshake, 1 when acknowledging
 * @param product_id Differentiate hardware. See HARDWARE_REVISION_xxx
 * @param fw_version 4 version numbers. 1 byte each. Following Kirkwood FW version spec
 * @param crc Main app image checksum
 * @param status Bitmask. See BOOTLOADER_HS_STATUS_xxx
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_bootloader_handshake_send(mavlink_channel_t chan, uint8_t target_component, uint8_t ack, uint16_t product_id, uint32_t fw_version, uint16_t crc, uint16_t status)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE_LEN];
	_mav_put_uint32_t(buf, 0, fw_version);
	_mav_put_uint16_t(buf, 4, product_id);
	_mav_put_uint16_t(buf, 6, crc);
	_mav_put_uint16_t(buf, 8, status);
	_mav_put_uint8_t(buf, 10, target_component);
	_mav_put_uint8_t(buf, 11, ack);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE, buf, MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE_LEN, MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE, buf, MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE_LEN);
#endif
#else
	mavlink_bootloader_handshake_t packet;
	packet.fw_version = fw_version;
	packet.product_id = product_id;
	packet.crc = crc;
	packet.status = status;
	packet.target_component = target_component;
	packet.ack = ack;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE, (const char *)&packet, MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE_LEN, MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE, (const char *)&packet, MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE_LEN);
#endif
#endif
}

#if MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_bootloader_handshake_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint8_t target_component, uint8_t ack, uint16_t product_id, uint32_t fw_version, uint16_t crc, uint16_t status)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char *buf = (char *)msgbuf;
	_mav_put_uint32_t(buf, 0, fw_version);
	_mav_put_uint16_t(buf, 4, product_id);
	_mav_put_uint16_t(buf, 6, crc);
	_mav_put_uint16_t(buf, 8, status);
	_mav_put_uint8_t(buf, 10, target_component);
	_mav_put_uint8_t(buf, 11, ack);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE, buf, MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE_LEN, MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE, buf, MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE_LEN);
#endif
#else
	mavlink_bootloader_handshake_t *packet = (mavlink_bootloader_handshake_t *)msgbuf;
	packet->fw_version = fw_version;
	packet->product_id = product_id;
	packet->crc = crc;
	packet->status = status;
	packet->target_component = target_component;
	packet->ack = ack;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE, (const char *)packet, MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE_LEN, MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE, (const char *)packet, MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE_LEN);
#endif
#endif
}
#endif

#endif

// MESSAGE BOOTLOADER_HANDSHAKE UNPACKING


/**
 * @brief Get field target_component from bootloader_handshake message
 *
 * @return Target component id. See KIRKWOOD_COMP_ID
 */
static inline uint8_t mavlink_msg_bootloader_handshake_get_target_component(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  10);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  10);
#endif
}

/**
 * @brief Get field ack from bootloader_handshake message
 *
 * @return Set to 0 when initializing handshake, 1 when acknowledging
 */
static inline uint8_t mavlink_msg_bootloader_handshake_get_ack(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  11);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  11);
#endif
}

/**
 * @brief Get field product_id from bootloader_handshake message
 *
 * @return Differentiate hardware. See HARDWARE_REVISION_xxx
 */
static inline uint16_t mavlink_msg_bootloader_handshake_get_product_id(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint16_t(msg,  4);
#else
	return mav_get_uint16_t_c2000(&(msg->payload64[0]),  4);
#endif
}

/**
 * @brief Get field fw_version from bootloader_handshake message
 *
 * @return 4 version numbers. 1 byte each. Following Kirkwood FW version spec
 */
static inline uint32_t mavlink_msg_bootloader_handshake_get_fw_version(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint32_t(msg,  0);
#else
	return mav_get_uint32_t_c2000(&(msg->payload64[0]),  0);
#endif
}

/**
 * @brief Get field crc from bootloader_handshake message
 *
 * @return Main app image checksum
 */
static inline uint16_t mavlink_msg_bootloader_handshake_get_crc(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint16_t(msg,  6);
#else
	return mav_get_uint16_t_c2000(&(msg->payload64[0]),  6);
#endif
}

/**
 * @brief Get field status from bootloader_handshake message
 *
 * @return Bitmask. See BOOTLOADER_HS_STATUS_xxx
 */
static inline uint16_t mavlink_msg_bootloader_handshake_get_status(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint16_t(msg,  8);
#else
	return mav_get_uint16_t_c2000(&(msg->payload64[0]),  8);
#endif
}

/**
 * @brief Decode a bootloader_handshake message into a struct
 *
 * @param msg The message to decode
 * @param bootloader_handshake C-struct to decode the message contents into
 */
static inline void mavlink_msg_bootloader_handshake_decode(const mavlink_message_t* msg, mavlink_bootloader_handshake_t* bootloader_handshake)
{
#if MAVLINK_NEED_BYTE_SWAP || MAVLINK_C2000
	bootloader_handshake->fw_version = mavlink_msg_bootloader_handshake_get_fw_version(msg);
	bootloader_handshake->product_id = mavlink_msg_bootloader_handshake_get_product_id(msg);
	bootloader_handshake->crc = mavlink_msg_bootloader_handshake_get_crc(msg);
	bootloader_handshake->status = mavlink_msg_bootloader_handshake_get_status(msg);
	bootloader_handshake->target_component = mavlink_msg_bootloader_handshake_get_target_component(msg);
	bootloader_handshake->ack = mavlink_msg_bootloader_handshake_get_ack(msg);
#else
	memcpy(bootloader_handshake, _MAV_PAYLOAD(msg), MAVLINK_MSG_ID_BOOTLOADER_HANDSHAKE_LEN);
#endif
}
