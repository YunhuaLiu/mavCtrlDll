// MESSAGE KIRKWOOD_MANEUVER_STATUS PACKING

#if MAVLINK_C2000
#include "../protocol_c2000.h"
#endif

#define MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS 163

typedef struct __mavlink_kirkwood_maneuver_status_t
{
 uint16_t type; /*< Maneuver type. See KW_MANEUVER_**/
 uint16_t state; /*< Maneuver state. See KW_MANEUVER_STATE_**/
 uint16_t trigger; /*< See KW_MANEUVER_TRIGGER_TYPE_**/
 uint8_t progress; /*< Percentage completed. 0-100*/
 uint8_t status; /*< See KW_MANEUVER_STATUS_**/
} mavlink_kirkwood_maneuver_status_t;

#define MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS_LEN 8
#define MAVLINK_MSG_ID_163_LEN 8

#define MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS_CRC 113
#define MAVLINK_MSG_ID_163_CRC 113



#define MAVLINK_MESSAGE_INFO_KIRKWOOD_MANEUVER_STATUS { \
	"KIRKWOOD_MANEUVER_STATUS", \
	5, \
	{  { "type", NULL, MAVLINK_TYPE_UINT16_T, 0, 0, offsetof(mavlink_kirkwood_maneuver_status_t, type) }, \
         { "state", NULL, MAVLINK_TYPE_UINT16_T, 0, 2, offsetof(mavlink_kirkwood_maneuver_status_t, state) }, \
         { "trigger", NULL, MAVLINK_TYPE_UINT16_T, 0, 4, offsetof(mavlink_kirkwood_maneuver_status_t, trigger) }, \
         { "progress", NULL, MAVLINK_TYPE_UINT8_T, 0, 6, offsetof(mavlink_kirkwood_maneuver_status_t, progress) }, \
         { "status", NULL, MAVLINK_TYPE_UINT8_T, 0, 7, offsetof(mavlink_kirkwood_maneuver_status_t, status) }, \
         } \
}


/**
 * @brief Pack a kirkwood_maneuver_status message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param type Maneuver type. See KW_MANEUVER_*
 * @param state Maneuver state. See KW_MANEUVER_STATE_*
 * @param progress Percentage completed. 0-100
 * @param status See KW_MANEUVER_STATUS_*
 * @param trigger See KW_MANEUVER_TRIGGER_TYPE_*
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_kirkwood_maneuver_status_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
						       uint16_t type, uint16_t state, uint8_t progress, uint8_t status, uint16_t trigger)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS_LEN];
	_mav_put_uint16_t(buf, 0, type);
	_mav_put_uint16_t(buf, 2, state);
	_mav_put_uint16_t(buf, 4, trigger);
	_mav_put_uint8_t(buf, 6, progress);
	_mav_put_uint8_t(buf, 7, status);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS_LEN);
#elif MAVLINK_C2000
		mav_put_uint16_t_c2000(&(msg->payload64[0]), 0, type);
		mav_put_uint16_t_c2000(&(msg->payload64[0]), 2, state);
		mav_put_uint16_t_c2000(&(msg->payload64[0]), 4, trigger);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 6, progress);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 7, status);
	
	
#else
	mavlink_kirkwood_maneuver_status_t packet;
	packet.type = type;
	packet.state = state;
	packet.trigger = trigger;
	packet.progress = progress;
	packet.status = status;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS_LEN, MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS_CRC);
#else
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS_LEN);
#endif
}

/**
 * @brief Pack a kirkwood_maneuver_status message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param type Maneuver type. See KW_MANEUVER_*
 * @param state Maneuver state. See KW_MANEUVER_STATE_*
 * @param progress Percentage completed. 0-100
 * @param status See KW_MANEUVER_STATUS_*
 * @param trigger See KW_MANEUVER_TRIGGER_TYPE_*
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_kirkwood_maneuver_status_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
							   mavlink_message_t* msg,
						           uint16_t type,uint16_t state,uint8_t progress,uint8_t status,uint16_t trigger)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS_LEN];
	_mav_put_uint16_t(buf, 0, type);
	_mav_put_uint16_t(buf, 2, state);
	_mav_put_uint16_t(buf, 4, trigger);
	_mav_put_uint8_t(buf, 6, progress);
	_mav_put_uint8_t(buf, 7, status);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS_LEN);
#else
	mavlink_kirkwood_maneuver_status_t packet;
	packet.type = type;
	packet.state = state;
	packet.trigger = trigger;
	packet.progress = progress;
	packet.status = status;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS_LEN, MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS_CRC);
#else
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS_LEN);
#endif
}

/**
 * @brief Encode a kirkwood_maneuver_status struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param kirkwood_maneuver_status C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_kirkwood_maneuver_status_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_kirkwood_maneuver_status_t* kirkwood_maneuver_status)
{
	return mavlink_msg_kirkwood_maneuver_status_pack(system_id, component_id, msg, kirkwood_maneuver_status->type, kirkwood_maneuver_status->state, kirkwood_maneuver_status->progress, kirkwood_maneuver_status->status, kirkwood_maneuver_status->trigger);
}

/**
 * @brief Encode a kirkwood_maneuver_status struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param kirkwood_maneuver_status C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_kirkwood_maneuver_status_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_kirkwood_maneuver_status_t* kirkwood_maneuver_status)
{
	return mavlink_msg_kirkwood_maneuver_status_pack_chan(system_id, component_id, chan, msg, kirkwood_maneuver_status->type, kirkwood_maneuver_status->state, kirkwood_maneuver_status->progress, kirkwood_maneuver_status->status, kirkwood_maneuver_status->trigger);
}

/**
 * @brief Send a kirkwood_maneuver_status message
 * @param chan MAVLink channel to send the message
 *
 * @param type Maneuver type. See KW_MANEUVER_*
 * @param state Maneuver state. See KW_MANEUVER_STATE_*
 * @param progress Percentage completed. 0-100
 * @param status See KW_MANEUVER_STATUS_*
 * @param trigger See KW_MANEUVER_TRIGGER_TYPE_*
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_kirkwood_maneuver_status_send(mavlink_channel_t chan, uint16_t type, uint16_t state, uint8_t progress, uint8_t status, uint16_t trigger)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS_LEN];
	_mav_put_uint16_t(buf, 0, type);
	_mav_put_uint16_t(buf, 2, state);
	_mav_put_uint16_t(buf, 4, trigger);
	_mav_put_uint8_t(buf, 6, progress);
	_mav_put_uint8_t(buf, 7, status);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS, buf, MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS_LEN, MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS, buf, MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS_LEN);
#endif
#else
	mavlink_kirkwood_maneuver_status_t packet;
	packet.type = type;
	packet.state = state;
	packet.trigger = trigger;
	packet.progress = progress;
	packet.status = status;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS, (const char *)&packet, MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS_LEN, MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS, (const char *)&packet, MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS_LEN);
#endif
#endif
}

#if MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_kirkwood_maneuver_status_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint16_t type, uint16_t state, uint8_t progress, uint8_t status, uint16_t trigger)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char *buf = (char *)msgbuf;
	_mav_put_uint16_t(buf, 0, type);
	_mav_put_uint16_t(buf, 2, state);
	_mav_put_uint16_t(buf, 4, trigger);
	_mav_put_uint8_t(buf, 6, progress);
	_mav_put_uint8_t(buf, 7, status);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS, buf, MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS_LEN, MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS, buf, MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS_LEN);
#endif
#else
	mavlink_kirkwood_maneuver_status_t *packet = (mavlink_kirkwood_maneuver_status_t *)msgbuf;
	packet->type = type;
	packet->state = state;
	packet->trigger = trigger;
	packet->progress = progress;
	packet->status = status;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS, (const char *)packet, MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS_LEN, MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS, (const char *)packet, MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS_LEN);
#endif
#endif
}
#endif

#endif

// MESSAGE KIRKWOOD_MANEUVER_STATUS UNPACKING


/**
 * @brief Get field type from kirkwood_maneuver_status message
 *
 * @return Maneuver type. See KW_MANEUVER_*
 */
static inline uint16_t mavlink_msg_kirkwood_maneuver_status_get_type(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint16_t(msg,  0);
#else
	return mav_get_uint16_t_c2000(&(msg->payload64[0]),  0);
#endif
}

/**
 * @brief Get field state from kirkwood_maneuver_status message
 *
 * @return Maneuver state. See KW_MANEUVER_STATE_*
 */
static inline uint16_t mavlink_msg_kirkwood_maneuver_status_get_state(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint16_t(msg,  2);
#else
	return mav_get_uint16_t_c2000(&(msg->payload64[0]),  2);
#endif
}

/**
 * @brief Get field progress from kirkwood_maneuver_status message
 *
 * @return Percentage completed. 0-100
 */
static inline uint8_t mavlink_msg_kirkwood_maneuver_status_get_progress(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  6);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  6);
#endif
}

/**
 * @brief Get field status from kirkwood_maneuver_status message
 *
 * @return See KW_MANEUVER_STATUS_*
 */
static inline uint8_t mavlink_msg_kirkwood_maneuver_status_get_status(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  7);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  7);
#endif
}

/**
 * @brief Get field trigger from kirkwood_maneuver_status message
 *
 * @return See KW_MANEUVER_TRIGGER_TYPE_*
 */
static inline uint16_t mavlink_msg_kirkwood_maneuver_status_get_trigger(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint16_t(msg,  4);
#else
	return mav_get_uint16_t_c2000(&(msg->payload64[0]),  4);
#endif
}

/**
 * @brief Decode a kirkwood_maneuver_status message into a struct
 *
 * @param msg The message to decode
 * @param kirkwood_maneuver_status C-struct to decode the message contents into
 */
static inline void mavlink_msg_kirkwood_maneuver_status_decode(const mavlink_message_t* msg, mavlink_kirkwood_maneuver_status_t* kirkwood_maneuver_status)
{
#if MAVLINK_NEED_BYTE_SWAP || MAVLINK_C2000
	kirkwood_maneuver_status->type = mavlink_msg_kirkwood_maneuver_status_get_type(msg);
	kirkwood_maneuver_status->state = mavlink_msg_kirkwood_maneuver_status_get_state(msg);
	kirkwood_maneuver_status->trigger = mavlink_msg_kirkwood_maneuver_status_get_trigger(msg);
	kirkwood_maneuver_status->progress = mavlink_msg_kirkwood_maneuver_status_get_progress(msg);
	kirkwood_maneuver_status->status = mavlink_msg_kirkwood_maneuver_status_get_status(msg);
#else
	memcpy(kirkwood_maneuver_status, _MAV_PAYLOAD(msg), MAVLINK_MSG_ID_KIRKWOOD_MANEUVER_STATUS_LEN);
#endif
}
