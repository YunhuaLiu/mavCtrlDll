// MESSAGE COYOTE_STATUS PACKING

#if MAVLINK_C2000
#include "../protocol_c2000.h"
#endif

#define MAVLINK_MSG_ID_COYOTE_STATUS 175

typedef struct __mavlink_coyote_status_t
{
 uint32_t time_boot_ms; /*< Timestamp (milliseconds since system boot)*/
 uint32_t state; /*< Bitmask. See COYOTE_STATE_ENUM*/
 uint32_t mode; /*< Bitmask. See COYOTE_CUSTOM_CMD_ENUM*/
 float axis_angle[3]; /*< Estimated angle*/
} mavlink_coyote_status_t;

#define MAVLINK_MSG_ID_COYOTE_STATUS_LEN 24
#define MAVLINK_MSG_ID_175_LEN 24

#define MAVLINK_MSG_ID_COYOTE_STATUS_CRC 109
#define MAVLINK_MSG_ID_175_CRC 109

#define MAVLINK_MSG_COYOTE_STATUS_FIELD_AXIS_ANGLE_LEN 3

#define MAVLINK_MESSAGE_INFO_COYOTE_STATUS { \
	"COYOTE_STATUS", \
	4, \
	{  { "time_boot_ms", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_coyote_status_t, time_boot_ms) }, \
         { "state", NULL, MAVLINK_TYPE_UINT32_T, 0, 4, offsetof(mavlink_coyote_status_t, state) }, \
         { "mode", NULL, MAVLINK_TYPE_UINT32_T, 0, 8, offsetof(mavlink_coyote_status_t, mode) }, \
         { "axis_angle", NULL, MAVLINK_TYPE_FLOAT, 3, 12, offsetof(mavlink_coyote_status_t, axis_angle) }, \
         } \
}


/**
 * @brief Pack a coyote_status message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param time_boot_ms Timestamp (milliseconds since system boot)
 * @param state Bitmask. See COYOTE_STATE_ENUM
 * @param mode Bitmask. See COYOTE_CUSTOM_CMD_ENUM
 * @param axis_angle Estimated angle
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_coyote_status_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
						       uint32_t time_boot_ms, uint32_t state, uint32_t mode, const float *axis_angle)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_COYOTE_STATUS_LEN];
	_mav_put_uint32_t(buf, 0, time_boot_ms);
	_mav_put_uint32_t(buf, 4, state);
	_mav_put_uint32_t(buf, 8, mode);
	_mav_put_float_array(buf, 12, axis_angle, 3);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_COYOTE_STATUS_LEN);
#elif MAVLINK_C2000
		mav_put_uint32_t_c2000(&(msg->payload64[0]), 0, time_boot_ms);
		mav_put_uint32_t_c2000(&(msg->payload64[0]), 4, state);
		mav_put_uint32_t_c2000(&(msg->payload64[0]), 8, mode);
	
		mav_put_float_array_c2000(&(msg->payload64[0]), axis_angle, 12, 3);
	
#else
	mavlink_coyote_status_t packet;
	packet.time_boot_ms = time_boot_ms;
	packet.state = state;
	packet.mode = mode;
	mav_array_memcpy(packet.axis_angle, axis_angle, sizeof(float)*3);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_COYOTE_STATUS_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_COYOTE_STATUS;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_COYOTE_STATUS_LEN, MAVLINK_MSG_ID_COYOTE_STATUS_CRC);
#else
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_COYOTE_STATUS_LEN);
#endif
}

/**
 * @brief Pack a coyote_status message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param time_boot_ms Timestamp (milliseconds since system boot)
 * @param state Bitmask. See COYOTE_STATE_ENUM
 * @param mode Bitmask. See COYOTE_CUSTOM_CMD_ENUM
 * @param axis_angle Estimated angle
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_coyote_status_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
							   mavlink_message_t* msg,
						           uint32_t time_boot_ms,uint32_t state,uint32_t mode,const float *axis_angle)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_COYOTE_STATUS_LEN];
	_mav_put_uint32_t(buf, 0, time_boot_ms);
	_mav_put_uint32_t(buf, 4, state);
	_mav_put_uint32_t(buf, 8, mode);
	_mav_put_float_array(buf, 12, axis_angle, 3);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_COYOTE_STATUS_LEN);
#else
	mavlink_coyote_status_t packet;
	packet.time_boot_ms = time_boot_ms;
	packet.state = state;
	packet.mode = mode;
	mav_array_memcpy(packet.axis_angle, axis_angle, sizeof(float)*3);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_COYOTE_STATUS_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_COYOTE_STATUS;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_COYOTE_STATUS_LEN, MAVLINK_MSG_ID_COYOTE_STATUS_CRC);
#else
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_COYOTE_STATUS_LEN);
#endif
}

/**
 * @brief Encode a coyote_status struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param coyote_status C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_coyote_status_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_coyote_status_t* coyote_status)
{
	return mavlink_msg_coyote_status_pack(system_id, component_id, msg, coyote_status->time_boot_ms, coyote_status->state, coyote_status->mode, coyote_status->axis_angle);
}

/**
 * @brief Encode a coyote_status struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param coyote_status C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_coyote_status_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_coyote_status_t* coyote_status)
{
	return mavlink_msg_coyote_status_pack_chan(system_id, component_id, chan, msg, coyote_status->time_boot_ms, coyote_status->state, coyote_status->mode, coyote_status->axis_angle);
}

/**
 * @brief Send a coyote_status message
 * @param chan MAVLink channel to send the message
 *
 * @param time_boot_ms Timestamp (milliseconds since system boot)
 * @param state Bitmask. See COYOTE_STATE_ENUM
 * @param mode Bitmask. See COYOTE_CUSTOM_CMD_ENUM
 * @param axis_angle Estimated angle
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_coyote_status_send(mavlink_channel_t chan, uint32_t time_boot_ms, uint32_t state, uint32_t mode, const float *axis_angle)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_COYOTE_STATUS_LEN];
	_mav_put_uint32_t(buf, 0, time_boot_ms);
	_mav_put_uint32_t(buf, 4, state);
	_mav_put_uint32_t(buf, 8, mode);
	_mav_put_float_array(buf, 12, axis_angle, 3);
#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_COYOTE_STATUS, buf, MAVLINK_MSG_ID_COYOTE_STATUS_LEN, MAVLINK_MSG_ID_COYOTE_STATUS_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_COYOTE_STATUS, buf, MAVLINK_MSG_ID_COYOTE_STATUS_LEN);
#endif
#else
	mavlink_coyote_status_t packet;
	packet.time_boot_ms = time_boot_ms;
	packet.state = state;
	packet.mode = mode;
	mav_array_memcpy(packet.axis_angle, axis_angle, sizeof(float)*3);
#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_COYOTE_STATUS, (const char *)&packet, MAVLINK_MSG_ID_COYOTE_STATUS_LEN, MAVLINK_MSG_ID_COYOTE_STATUS_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_COYOTE_STATUS, (const char *)&packet, MAVLINK_MSG_ID_COYOTE_STATUS_LEN);
#endif
#endif
}

#if MAVLINK_MSG_ID_COYOTE_STATUS_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_coyote_status_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint32_t time_boot_ms, uint32_t state, uint32_t mode, const float *axis_angle)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char *buf = (char *)msgbuf;
	_mav_put_uint32_t(buf, 0, time_boot_ms);
	_mav_put_uint32_t(buf, 4, state);
	_mav_put_uint32_t(buf, 8, mode);
	_mav_put_float_array(buf, 12, axis_angle, 3);
#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_COYOTE_STATUS, buf, MAVLINK_MSG_ID_COYOTE_STATUS_LEN, MAVLINK_MSG_ID_COYOTE_STATUS_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_COYOTE_STATUS, buf, MAVLINK_MSG_ID_COYOTE_STATUS_LEN);
#endif
#else
	mavlink_coyote_status_t *packet = (mavlink_coyote_status_t *)msgbuf;
	packet->time_boot_ms = time_boot_ms;
	packet->state = state;
	packet->mode = mode;
	mav_array_memcpy(packet->axis_angle, axis_angle, sizeof(float)*3);
#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_COYOTE_STATUS, (const char *)packet, MAVLINK_MSG_ID_COYOTE_STATUS_LEN, MAVLINK_MSG_ID_COYOTE_STATUS_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_COYOTE_STATUS, (const char *)packet, MAVLINK_MSG_ID_COYOTE_STATUS_LEN);
#endif
#endif
}
#endif

#endif

// MESSAGE COYOTE_STATUS UNPACKING


/**
 * @brief Get field time_boot_ms from coyote_status message
 *
 * @return Timestamp (milliseconds since system boot)
 */
static inline uint32_t mavlink_msg_coyote_status_get_time_boot_ms(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint32_t(msg,  0);
#else
	return mav_get_uint32_t_c2000(&(msg->payload64[0]),  0);
#endif
}

/**
 * @brief Get field state from coyote_status message
 *
 * @return Bitmask. See COYOTE_STATE_ENUM
 */
static inline uint32_t mavlink_msg_coyote_status_get_state(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint32_t(msg,  4);
#else
	return mav_get_uint32_t_c2000(&(msg->payload64[0]),  4);
#endif
}

/**
 * @brief Get field mode from coyote_status message
 *
 * @return Bitmask. See COYOTE_CUSTOM_CMD_ENUM
 */
static inline uint32_t mavlink_msg_coyote_status_get_mode(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint32_t(msg,  8);
#else
	return mav_get_uint32_t_c2000(&(msg->payload64[0]),  8);
#endif
}

/**
 * @brief Get field axis_angle from coyote_status message
 *
 * @return Estimated angle
 */
static inline uint16_t mavlink_msg_coyote_status_get_axis_angle(const mavlink_message_t* msg, float *axis_angle)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float_array(msg, axis_angle, 3,  12);
#else
	return mav_get_float_array_c2000(&(msg->payload64[0]), axis_angle, 3,  12);
#endif
}

/**
 * @brief Decode a coyote_status message into a struct
 *
 * @param msg The message to decode
 * @param coyote_status C-struct to decode the message contents into
 */
static inline void mavlink_msg_coyote_status_decode(const mavlink_message_t* msg, mavlink_coyote_status_t* coyote_status)
{
#if MAVLINK_NEED_BYTE_SWAP || MAVLINK_C2000
	coyote_status->time_boot_ms = mavlink_msg_coyote_status_get_time_boot_ms(msg);
	coyote_status->state = mavlink_msg_coyote_status_get_state(msg);
	coyote_status->mode = mavlink_msg_coyote_status_get_mode(msg);
	mavlink_msg_coyote_status_get_axis_angle(msg, coyote_status->axis_angle);
#else
	memcpy(coyote_status, _MAV_PAYLOAD(msg), MAVLINK_MSG_ID_COYOTE_STATUS_LEN);
#endif
}
