// MESSAGE KIRKWOOD_BATTERY_STATUS PACKING

#if MAVLINK_C2000
#include "../protocol_c2000.h"
#endif

#define MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS 168

typedef struct __mavlink_kirkwood_battery_status_t
{
 int32_t current_battery; /*< Battery current, in 10*millamperes (1 = 10 milliampere), -1: autopilot does not measure the current*/
 uint32_t current_consumed; /*< Consumed charge, in milliampere hours (1 = 1 mAh), -1: autopilot does not provide mAh consumption estimate*/
 int32_t energy_consumed; /*< Consumed energy, in 100*Joules (integrated U*I*dt) (1 = 100 Joule), -1: autopilot doesn not provide energy consumption estimate*/
 int16_t temperature; /*< Temperature of the battery in centi-degrees celcius. INT16_MAX for unknown temperature*/
 uint16_t voltage1; /*< Voltage of cell 1, in millivolts (1 = 1 millivolt)*/
 uint16_t voltage2; /*< Voltage of cell 2, in millivolts (1 = 1 millivolt)*/
 uint16_t voltage3; /*< Voltage of cell 3, in millivolts (1 = 1 millivolt)*/
 uint16_t voltage4; /*< Voltage of cell 4, in millivolts (1 = 1 millivolt)*/
 uint16_t bat_time_to_empty; /*< ,Remaining time (minutes) before battery energy becomes zero -1: autopilot does not estimate the remaining battery time*/
 uint16_t bat_soh; /*< Current Percentage of design capacity (State of Health): (0%: 0, 100%: 100), -1: autopilot does not estimate battery state of health*/
 uint16_t bat_cycle_count; /*< Number of discharge cycles the battery has experienced -1: autopilot does not estimate discharge cycles */
 uint8_t id; /*< Battery ID*/
 uint8_t battery_function; /*< Function of the battery*/
 uint8_t type; /*< Type of battery*/
 int8_t battery_remaining; /*< Remaining battery energy: (0%: 0, 100%: 100), -1: autopilot does not estimate the remaining battery*/
} mavlink_kirkwood_battery_status_t;

#define MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS_LEN 32
#define MAVLINK_MSG_ID_168_LEN 32

#define MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS_CRC 132
#define MAVLINK_MSG_ID_168_CRC 132



#define MAVLINK_MESSAGE_INFO_KIRKWOOD_BATTERY_STATUS { \
	"KIRKWOOD_BATTERY_STATUS", \
	15, \
	{  { "current_battery", NULL, MAVLINK_TYPE_INT32_T, 0, 0, offsetof(mavlink_kirkwood_battery_status_t, current_battery) }, \
         { "current_consumed", NULL, MAVLINK_TYPE_UINT32_T, 0, 4, offsetof(mavlink_kirkwood_battery_status_t, current_consumed) }, \
         { "energy_consumed", NULL, MAVLINK_TYPE_INT32_T, 0, 8, offsetof(mavlink_kirkwood_battery_status_t, energy_consumed) }, \
         { "temperature", NULL, MAVLINK_TYPE_INT16_T, 0, 12, offsetof(mavlink_kirkwood_battery_status_t, temperature) }, \
         { "voltage1", NULL, MAVLINK_TYPE_UINT16_T, 0, 14, offsetof(mavlink_kirkwood_battery_status_t, voltage1) }, \
         { "voltage2", NULL, MAVLINK_TYPE_UINT16_T, 0, 16, offsetof(mavlink_kirkwood_battery_status_t, voltage2) }, \
         { "voltage3", NULL, MAVLINK_TYPE_UINT16_T, 0, 18, offsetof(mavlink_kirkwood_battery_status_t, voltage3) }, \
         { "voltage4", NULL, MAVLINK_TYPE_UINT16_T, 0, 20, offsetof(mavlink_kirkwood_battery_status_t, voltage4) }, \
         { "bat_time_to_empty", NULL, MAVLINK_TYPE_UINT16_T, 0, 22, offsetof(mavlink_kirkwood_battery_status_t, bat_time_to_empty) }, \
         { "bat_soh", NULL, MAVLINK_TYPE_UINT16_T, 0, 24, offsetof(mavlink_kirkwood_battery_status_t, bat_soh) }, \
         { "bat_cycle_count", NULL, MAVLINK_TYPE_UINT16_T, 0, 26, offsetof(mavlink_kirkwood_battery_status_t, bat_cycle_count) }, \
         { "id", NULL, MAVLINK_TYPE_UINT8_T, 0, 28, offsetof(mavlink_kirkwood_battery_status_t, id) }, \
         { "battery_function", NULL, MAVLINK_TYPE_UINT8_T, 0, 29, offsetof(mavlink_kirkwood_battery_status_t, battery_function) }, \
         { "type", NULL, MAVLINK_TYPE_UINT8_T, 0, 30, offsetof(mavlink_kirkwood_battery_status_t, type) }, \
         { "battery_remaining", NULL, MAVLINK_TYPE_INT8_T, 0, 31, offsetof(mavlink_kirkwood_battery_status_t, battery_remaining) }, \
         } \
}


/**
 * @brief Pack a kirkwood_battery_status message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param id Battery ID
 * @param battery_function Function of the battery
 * @param type Type of battery
 * @param temperature Temperature of the battery in centi-degrees celcius. INT16_MAX for unknown temperature
 * @param voltage1 Voltage of cell 1, in millivolts (1 = 1 millivolt)
 * @param voltage2 Voltage of cell 2, in millivolts (1 = 1 millivolt)
 * @param voltage3 Voltage of cell 3, in millivolts (1 = 1 millivolt)
 * @param voltage4 Voltage of cell 4, in millivolts (1 = 1 millivolt)
 * @param current_battery Battery current, in 10*millamperes (1 = 10 milliampere), -1: autopilot does not measure the current
 * @param current_consumed Consumed charge, in milliampere hours (1 = 1 mAh), -1: autopilot does not provide mAh consumption estimate
 * @param energy_consumed Consumed energy, in 100*Joules (integrated U*I*dt) (1 = 100 Joule), -1: autopilot doesn not provide energy consumption estimate
 * @param battery_remaining Remaining battery energy: (0%: 0, 100%: 100), -1: autopilot does not estimate the remaining battery
 * @param bat_time_to_empty ,Remaining time (minutes) before battery energy becomes zero -1: autopilot does not estimate the remaining battery time
 * @param bat_soh Current Percentage of design capacity (State of Health): (0%: 0, 100%: 100), -1: autopilot does not estimate battery state of health
 * @param bat_cycle_count Number of discharge cycles the battery has experienced -1: autopilot does not estimate discharge cycles 
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_kirkwood_battery_status_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
						       uint8_t id, uint8_t battery_function, uint8_t type, int16_t temperature, uint16_t voltage1, uint16_t voltage2, uint16_t voltage3, uint16_t voltage4, int32_t current_battery, uint32_t current_consumed, int32_t energy_consumed, int8_t battery_remaining, uint16_t bat_time_to_empty, uint16_t bat_soh, uint16_t bat_cycle_count)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS_LEN];
	_mav_put_int32_t(buf, 0, current_battery);
	_mav_put_uint32_t(buf, 4, current_consumed);
	_mav_put_int32_t(buf, 8, energy_consumed);
	_mav_put_int16_t(buf, 12, temperature);
	_mav_put_uint16_t(buf, 14, voltage1);
	_mav_put_uint16_t(buf, 16, voltage2);
	_mav_put_uint16_t(buf, 18, voltage3);
	_mav_put_uint16_t(buf, 20, voltage4);
	_mav_put_uint16_t(buf, 22, bat_time_to_empty);
	_mav_put_uint16_t(buf, 24, bat_soh);
	_mav_put_uint16_t(buf, 26, bat_cycle_count);
	_mav_put_uint8_t(buf, 28, id);
	_mav_put_uint8_t(buf, 29, battery_function);
	_mav_put_uint8_t(buf, 30, type);
	_mav_put_int8_t(buf, 31, battery_remaining);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS_LEN);
#elif MAVLINK_C2000
		mav_put_int32_t_c2000(&(msg->payload64[0]), 0, current_battery);
		mav_put_uint32_t_c2000(&(msg->payload64[0]), 4, current_consumed);
		mav_put_int32_t_c2000(&(msg->payload64[0]), 8, energy_consumed);
		mav_put_int16_t_c2000(&(msg->payload64[0]), 12, temperature);
		mav_put_uint16_t_c2000(&(msg->payload64[0]), 14, voltage1);
		mav_put_uint16_t_c2000(&(msg->payload64[0]), 16, voltage2);
		mav_put_uint16_t_c2000(&(msg->payload64[0]), 18, voltage3);
		mav_put_uint16_t_c2000(&(msg->payload64[0]), 20, voltage4);
		mav_put_uint16_t_c2000(&(msg->payload64[0]), 22, bat_time_to_empty);
		mav_put_uint16_t_c2000(&(msg->payload64[0]), 24, bat_soh);
		mav_put_uint16_t_c2000(&(msg->payload64[0]), 26, bat_cycle_count);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 28, id);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 29, battery_function);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 30, type);
		mav_put_int8_t_c2000(&(msg->payload64[0]), 31, battery_remaining);
	
	
#else
	mavlink_kirkwood_battery_status_t packet;
	packet.current_battery = current_battery;
	packet.current_consumed = current_consumed;
	packet.energy_consumed = energy_consumed;
	packet.temperature = temperature;
	packet.voltage1 = voltage1;
	packet.voltage2 = voltage2;
	packet.voltage3 = voltage3;
	packet.voltage4 = voltage4;
	packet.bat_time_to_empty = bat_time_to_empty;
	packet.bat_soh = bat_soh;
	packet.bat_cycle_count = bat_cycle_count;
	packet.id = id;
	packet.battery_function = battery_function;
	packet.type = type;
	packet.battery_remaining = battery_remaining;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS_LEN, MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS_CRC);
#else
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS_LEN);
#endif
}

/**
 * @brief Pack a kirkwood_battery_status message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param id Battery ID
 * @param battery_function Function of the battery
 * @param type Type of battery
 * @param temperature Temperature of the battery in centi-degrees celcius. INT16_MAX for unknown temperature
 * @param voltage1 Voltage of cell 1, in millivolts (1 = 1 millivolt)
 * @param voltage2 Voltage of cell 2, in millivolts (1 = 1 millivolt)
 * @param voltage3 Voltage of cell 3, in millivolts (1 = 1 millivolt)
 * @param voltage4 Voltage of cell 4, in millivolts (1 = 1 millivolt)
 * @param current_battery Battery current, in 10*millamperes (1 = 10 milliampere), -1: autopilot does not measure the current
 * @param current_consumed Consumed charge, in milliampere hours (1 = 1 mAh), -1: autopilot does not provide mAh consumption estimate
 * @param energy_consumed Consumed energy, in 100*Joules (integrated U*I*dt) (1 = 100 Joule), -1: autopilot doesn not provide energy consumption estimate
 * @param battery_remaining Remaining battery energy: (0%: 0, 100%: 100), -1: autopilot does not estimate the remaining battery
 * @param bat_time_to_empty ,Remaining time (minutes) before battery energy becomes zero -1: autopilot does not estimate the remaining battery time
 * @param bat_soh Current Percentage of design capacity (State of Health): (0%: 0, 100%: 100), -1: autopilot does not estimate battery state of health
 * @param bat_cycle_count Number of discharge cycles the battery has experienced -1: autopilot does not estimate discharge cycles 
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_kirkwood_battery_status_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
							   mavlink_message_t* msg,
						           uint8_t id,uint8_t battery_function,uint8_t type,int16_t temperature,uint16_t voltage1,uint16_t voltage2,uint16_t voltage3,uint16_t voltage4,int32_t current_battery,uint32_t current_consumed,int32_t energy_consumed,int8_t battery_remaining,uint16_t bat_time_to_empty,uint16_t bat_soh,uint16_t bat_cycle_count)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS_LEN];
	_mav_put_int32_t(buf, 0, current_battery);
	_mav_put_uint32_t(buf, 4, current_consumed);
	_mav_put_int32_t(buf, 8, energy_consumed);
	_mav_put_int16_t(buf, 12, temperature);
	_mav_put_uint16_t(buf, 14, voltage1);
	_mav_put_uint16_t(buf, 16, voltage2);
	_mav_put_uint16_t(buf, 18, voltage3);
	_mav_put_uint16_t(buf, 20, voltage4);
	_mav_put_uint16_t(buf, 22, bat_time_to_empty);
	_mav_put_uint16_t(buf, 24, bat_soh);
	_mav_put_uint16_t(buf, 26, bat_cycle_count);
	_mav_put_uint8_t(buf, 28, id);
	_mav_put_uint8_t(buf, 29, battery_function);
	_mav_put_uint8_t(buf, 30, type);
	_mav_put_int8_t(buf, 31, battery_remaining);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS_LEN);
#else
	mavlink_kirkwood_battery_status_t packet;
	packet.current_battery = current_battery;
	packet.current_consumed = current_consumed;
	packet.energy_consumed = energy_consumed;
	packet.temperature = temperature;
	packet.voltage1 = voltage1;
	packet.voltage2 = voltage2;
	packet.voltage3 = voltage3;
	packet.voltage4 = voltage4;
	packet.bat_time_to_empty = bat_time_to_empty;
	packet.bat_soh = bat_soh;
	packet.bat_cycle_count = bat_cycle_count;
	packet.id = id;
	packet.battery_function = battery_function;
	packet.type = type;
	packet.battery_remaining = battery_remaining;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS_LEN, MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS_CRC);
#else
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS_LEN);
#endif
}

/**
 * @brief Encode a kirkwood_battery_status struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param kirkwood_battery_status C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_kirkwood_battery_status_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_kirkwood_battery_status_t* kirkwood_battery_status)
{
	return mavlink_msg_kirkwood_battery_status_pack(system_id, component_id, msg, kirkwood_battery_status->id, kirkwood_battery_status->battery_function, kirkwood_battery_status->type, kirkwood_battery_status->temperature, kirkwood_battery_status->voltage1, kirkwood_battery_status->voltage2, kirkwood_battery_status->voltage3, kirkwood_battery_status->voltage4, kirkwood_battery_status->current_battery, kirkwood_battery_status->current_consumed, kirkwood_battery_status->energy_consumed, kirkwood_battery_status->battery_remaining, kirkwood_battery_status->bat_time_to_empty, kirkwood_battery_status->bat_soh, kirkwood_battery_status->bat_cycle_count);
}

/**
 * @brief Encode a kirkwood_battery_status struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param kirkwood_battery_status C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_kirkwood_battery_status_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_kirkwood_battery_status_t* kirkwood_battery_status)
{
	return mavlink_msg_kirkwood_battery_status_pack_chan(system_id, component_id, chan, msg, kirkwood_battery_status->id, kirkwood_battery_status->battery_function, kirkwood_battery_status->type, kirkwood_battery_status->temperature, kirkwood_battery_status->voltage1, kirkwood_battery_status->voltage2, kirkwood_battery_status->voltage3, kirkwood_battery_status->voltage4, kirkwood_battery_status->current_battery, kirkwood_battery_status->current_consumed, kirkwood_battery_status->energy_consumed, kirkwood_battery_status->battery_remaining, kirkwood_battery_status->bat_time_to_empty, kirkwood_battery_status->bat_soh, kirkwood_battery_status->bat_cycle_count);
}

/**
 * @brief Send a kirkwood_battery_status message
 * @param chan MAVLink channel to send the message
 *
 * @param id Battery ID
 * @param battery_function Function of the battery
 * @param type Type of battery
 * @param temperature Temperature of the battery in centi-degrees celcius. INT16_MAX for unknown temperature
 * @param voltage1 Voltage of cell 1, in millivolts (1 = 1 millivolt)
 * @param voltage2 Voltage of cell 2, in millivolts (1 = 1 millivolt)
 * @param voltage3 Voltage of cell 3, in millivolts (1 = 1 millivolt)
 * @param voltage4 Voltage of cell 4, in millivolts (1 = 1 millivolt)
 * @param current_battery Battery current, in 10*millamperes (1 = 10 milliampere), -1: autopilot does not measure the current
 * @param current_consumed Consumed charge, in milliampere hours (1 = 1 mAh), -1: autopilot does not provide mAh consumption estimate
 * @param energy_consumed Consumed energy, in 100*Joules (integrated U*I*dt) (1 = 100 Joule), -1: autopilot doesn not provide energy consumption estimate
 * @param battery_remaining Remaining battery energy: (0%: 0, 100%: 100), -1: autopilot does not estimate the remaining battery
 * @param bat_time_to_empty ,Remaining time (minutes) before battery energy becomes zero -1: autopilot does not estimate the remaining battery time
 * @param bat_soh Current Percentage of design capacity (State of Health): (0%: 0, 100%: 100), -1: autopilot does not estimate battery state of health
 * @param bat_cycle_count Number of discharge cycles the battery has experienced -1: autopilot does not estimate discharge cycles 
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_kirkwood_battery_status_send(mavlink_channel_t chan, uint8_t id, uint8_t battery_function, uint8_t type, int16_t temperature, uint16_t voltage1, uint16_t voltage2, uint16_t voltage3, uint16_t voltage4, int32_t current_battery, uint32_t current_consumed, int32_t energy_consumed, int8_t battery_remaining, uint16_t bat_time_to_empty, uint16_t bat_soh, uint16_t bat_cycle_count)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS_LEN];
	_mav_put_int32_t(buf, 0, current_battery);
	_mav_put_uint32_t(buf, 4, current_consumed);
	_mav_put_int32_t(buf, 8, energy_consumed);
	_mav_put_int16_t(buf, 12, temperature);
	_mav_put_uint16_t(buf, 14, voltage1);
	_mav_put_uint16_t(buf, 16, voltage2);
	_mav_put_uint16_t(buf, 18, voltage3);
	_mav_put_uint16_t(buf, 20, voltage4);
	_mav_put_uint16_t(buf, 22, bat_time_to_empty);
	_mav_put_uint16_t(buf, 24, bat_soh);
	_mav_put_uint16_t(buf, 26, bat_cycle_count);
	_mav_put_uint8_t(buf, 28, id);
	_mav_put_uint8_t(buf, 29, battery_function);
	_mav_put_uint8_t(buf, 30, type);
	_mav_put_int8_t(buf, 31, battery_remaining);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS, buf, MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS_LEN, MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS, buf, MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS_LEN);
#endif
#else
	mavlink_kirkwood_battery_status_t packet;
	packet.current_battery = current_battery;
	packet.current_consumed = current_consumed;
	packet.energy_consumed = energy_consumed;
	packet.temperature = temperature;
	packet.voltage1 = voltage1;
	packet.voltage2 = voltage2;
	packet.voltage3 = voltage3;
	packet.voltage4 = voltage4;
	packet.bat_time_to_empty = bat_time_to_empty;
	packet.bat_soh = bat_soh;
	packet.bat_cycle_count = bat_cycle_count;
	packet.id = id;
	packet.battery_function = battery_function;
	packet.type = type;
	packet.battery_remaining = battery_remaining;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS, (const char *)&packet, MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS_LEN, MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS, (const char *)&packet, MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS_LEN);
#endif
#endif
}

#if MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_kirkwood_battery_status_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint8_t id, uint8_t battery_function, uint8_t type, int16_t temperature, uint16_t voltage1, uint16_t voltage2, uint16_t voltage3, uint16_t voltage4, int32_t current_battery, uint32_t current_consumed, int32_t energy_consumed, int8_t battery_remaining, uint16_t bat_time_to_empty, uint16_t bat_soh, uint16_t bat_cycle_count)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char *buf = (char *)msgbuf;
	_mav_put_int32_t(buf, 0, current_battery);
	_mav_put_uint32_t(buf, 4, current_consumed);
	_mav_put_int32_t(buf, 8, energy_consumed);
	_mav_put_int16_t(buf, 12, temperature);
	_mav_put_uint16_t(buf, 14, voltage1);
	_mav_put_uint16_t(buf, 16, voltage2);
	_mav_put_uint16_t(buf, 18, voltage3);
	_mav_put_uint16_t(buf, 20, voltage4);
	_mav_put_uint16_t(buf, 22, bat_time_to_empty);
	_mav_put_uint16_t(buf, 24, bat_soh);
	_mav_put_uint16_t(buf, 26, bat_cycle_count);
	_mav_put_uint8_t(buf, 28, id);
	_mav_put_uint8_t(buf, 29, battery_function);
	_mav_put_uint8_t(buf, 30, type);
	_mav_put_int8_t(buf, 31, battery_remaining);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS, buf, MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS_LEN, MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS, buf, MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS_LEN);
#endif
#else
	mavlink_kirkwood_battery_status_t *packet = (mavlink_kirkwood_battery_status_t *)msgbuf;
	packet->current_battery = current_battery;
	packet->current_consumed = current_consumed;
	packet->energy_consumed = energy_consumed;
	packet->temperature = temperature;
	packet->voltage1 = voltage1;
	packet->voltage2 = voltage2;
	packet->voltage3 = voltage3;
	packet->voltage4 = voltage4;
	packet->bat_time_to_empty = bat_time_to_empty;
	packet->bat_soh = bat_soh;
	packet->bat_cycle_count = bat_cycle_count;
	packet->id = id;
	packet->battery_function = battery_function;
	packet->type = type;
	packet->battery_remaining = battery_remaining;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS, (const char *)packet, MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS_LEN, MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS, (const char *)packet, MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS_LEN);
#endif
#endif
}
#endif

#endif

// MESSAGE KIRKWOOD_BATTERY_STATUS UNPACKING


/**
 * @brief Get field id from kirkwood_battery_status message
 *
 * @return Battery ID
 */
static inline uint8_t mavlink_msg_kirkwood_battery_status_get_id(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  28);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  28);
#endif
}

/**
 * @brief Get field battery_function from kirkwood_battery_status message
 *
 * @return Function of the battery
 */
static inline uint8_t mavlink_msg_kirkwood_battery_status_get_battery_function(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  29);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  29);
#endif
}

/**
 * @brief Get field type from kirkwood_battery_status message
 *
 * @return Type of battery
 */
static inline uint8_t mavlink_msg_kirkwood_battery_status_get_type(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  30);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  30);
#endif
}

/**
 * @brief Get field temperature from kirkwood_battery_status message
 *
 * @return Temperature of the battery in centi-degrees celcius. INT16_MAX for unknown temperature
 */
static inline int16_t mavlink_msg_kirkwood_battery_status_get_temperature(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_int16_t(msg,  12);
#else
	return mav_get_int16_t_c2000(&(msg->payload64[0]),  12);
#endif
}

/**
 * @brief Get field voltage1 from kirkwood_battery_status message
 *
 * @return Voltage of cell 1, in millivolts (1 = 1 millivolt)
 */
static inline uint16_t mavlink_msg_kirkwood_battery_status_get_voltage1(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint16_t(msg,  14);
#else
	return mav_get_uint16_t_c2000(&(msg->payload64[0]),  14);
#endif
}

/**
 * @brief Get field voltage2 from kirkwood_battery_status message
 *
 * @return Voltage of cell 2, in millivolts (1 = 1 millivolt)
 */
static inline uint16_t mavlink_msg_kirkwood_battery_status_get_voltage2(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint16_t(msg,  16);
#else
	return mav_get_uint16_t_c2000(&(msg->payload64[0]),  16);
#endif
}

/**
 * @brief Get field voltage3 from kirkwood_battery_status message
 *
 * @return Voltage of cell 3, in millivolts (1 = 1 millivolt)
 */
static inline uint16_t mavlink_msg_kirkwood_battery_status_get_voltage3(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint16_t(msg,  18);
#else
	return mav_get_uint16_t_c2000(&(msg->payload64[0]),  18);
#endif
}

/**
 * @brief Get field voltage4 from kirkwood_battery_status message
 *
 * @return Voltage of cell 4, in millivolts (1 = 1 millivolt)
 */
static inline uint16_t mavlink_msg_kirkwood_battery_status_get_voltage4(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint16_t(msg,  20);
#else
	return mav_get_uint16_t_c2000(&(msg->payload64[0]),  20);
#endif
}

/**
 * @brief Get field current_battery from kirkwood_battery_status message
 *
 * @return Battery current, in 10*millamperes (1 = 10 milliampere), -1: autopilot does not measure the current
 */
static inline int32_t mavlink_msg_kirkwood_battery_status_get_current_battery(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_int32_t(msg,  0);
#else
	return mav_get_int32_t_c2000(&(msg->payload64[0]),  0);
#endif
}

/**
 * @brief Get field current_consumed from kirkwood_battery_status message
 *
 * @return Consumed charge, in milliampere hours (1 = 1 mAh), -1: autopilot does not provide mAh consumption estimate
 */
static inline uint32_t mavlink_msg_kirkwood_battery_status_get_current_consumed(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint32_t(msg,  4);
#else
	return mav_get_uint32_t_c2000(&(msg->payload64[0]),  4);
#endif
}

/**
 * @brief Get field energy_consumed from kirkwood_battery_status message
 *
 * @return Consumed energy, in 100*Joules (integrated U*I*dt) (1 = 100 Joule), -1: autopilot doesn not provide energy consumption estimate
 */
static inline int32_t mavlink_msg_kirkwood_battery_status_get_energy_consumed(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_int32_t(msg,  8);
#else
	return mav_get_int32_t_c2000(&(msg->payload64[0]),  8);
#endif
}

/**
 * @brief Get field battery_remaining from kirkwood_battery_status message
 *
 * @return Remaining battery energy: (0%: 0, 100%: 100), -1: autopilot does not estimate the remaining battery
 */
static inline int8_t mavlink_msg_kirkwood_battery_status_get_battery_remaining(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_int8_t(msg,  31);
#else
	return mav_get_int8_t_c2000(&(msg->payload64[0]),  31);
#endif
}

/**
 * @brief Get field bat_time_to_empty from kirkwood_battery_status message
 *
 * @return ,Remaining time (minutes) before battery energy becomes zero -1: autopilot does not estimate the remaining battery time
 */
static inline uint16_t mavlink_msg_kirkwood_battery_status_get_bat_time_to_empty(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint16_t(msg,  22);
#else
	return mav_get_uint16_t_c2000(&(msg->payload64[0]),  22);
#endif
}

/**
 * @brief Get field bat_soh from kirkwood_battery_status message
 *
 * @return Current Percentage of design capacity (State of Health): (0%: 0, 100%: 100), -1: autopilot does not estimate battery state of health
 */
static inline uint16_t mavlink_msg_kirkwood_battery_status_get_bat_soh(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint16_t(msg,  24);
#else
	return mav_get_uint16_t_c2000(&(msg->payload64[0]),  24);
#endif
}

/**
 * @brief Get field bat_cycle_count from kirkwood_battery_status message
 *
 * @return Number of discharge cycles the battery has experienced -1: autopilot does not estimate discharge cycles 
 */
static inline uint16_t mavlink_msg_kirkwood_battery_status_get_bat_cycle_count(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint16_t(msg,  26);
#else
	return mav_get_uint16_t_c2000(&(msg->payload64[0]),  26);
#endif
}

/**
 * @brief Decode a kirkwood_battery_status message into a struct
 *
 * @param msg The message to decode
 * @param kirkwood_battery_status C-struct to decode the message contents into
 */
static inline void mavlink_msg_kirkwood_battery_status_decode(const mavlink_message_t* msg, mavlink_kirkwood_battery_status_t* kirkwood_battery_status)
{
#if MAVLINK_NEED_BYTE_SWAP || MAVLINK_C2000
	kirkwood_battery_status->current_battery = mavlink_msg_kirkwood_battery_status_get_current_battery(msg);
	kirkwood_battery_status->current_consumed = mavlink_msg_kirkwood_battery_status_get_current_consumed(msg);
	kirkwood_battery_status->energy_consumed = mavlink_msg_kirkwood_battery_status_get_energy_consumed(msg);
	kirkwood_battery_status->temperature = mavlink_msg_kirkwood_battery_status_get_temperature(msg);
	kirkwood_battery_status->voltage1 = mavlink_msg_kirkwood_battery_status_get_voltage1(msg);
	kirkwood_battery_status->voltage2 = mavlink_msg_kirkwood_battery_status_get_voltage2(msg);
	kirkwood_battery_status->voltage3 = mavlink_msg_kirkwood_battery_status_get_voltage3(msg);
	kirkwood_battery_status->voltage4 = mavlink_msg_kirkwood_battery_status_get_voltage4(msg);
	kirkwood_battery_status->bat_time_to_empty = mavlink_msg_kirkwood_battery_status_get_bat_time_to_empty(msg);
	kirkwood_battery_status->bat_soh = mavlink_msg_kirkwood_battery_status_get_bat_soh(msg);
	kirkwood_battery_status->bat_cycle_count = mavlink_msg_kirkwood_battery_status_get_bat_cycle_count(msg);
	kirkwood_battery_status->id = mavlink_msg_kirkwood_battery_status_get_id(msg);
	kirkwood_battery_status->battery_function = mavlink_msg_kirkwood_battery_status_get_battery_function(msg);
	kirkwood_battery_status->type = mavlink_msg_kirkwood_battery_status_get_type(msg);
	kirkwood_battery_status->battery_remaining = mavlink_msg_kirkwood_battery_status_get_battery_remaining(msg);
#else
	memcpy(kirkwood_battery_status, _MAV_PAYLOAD(msg), MAVLINK_MSG_ID_KIRKWOOD_BATTERY_STATUS_LEN);
#endif
}
