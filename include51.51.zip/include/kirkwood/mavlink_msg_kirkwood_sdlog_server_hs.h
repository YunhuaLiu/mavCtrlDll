// MESSAGE KIRKWOOD_SDLOG_SERVER_HS PACKING

#if MAVLINK_C2000
#include "../protocol_c2000.h"
#endif

#define MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS 167

typedef struct __mavlink_kirkwood_sdlog_server_hs_t
{
 uint32_t size; /*< Contains the data for the operation*/
 uint32_t current_sequence; /*< Contains the current sequence*/
 uint8_t opcode; /*< See KIRKWOOD_SDLOG_HS_SERVER_OPCODE**/
 char payload[200]; /*< Contains the data for the operation*/
 uint8_t reset_sequence; /*< Contains the data for the operation*/
} mavlink_kirkwood_sdlog_server_hs_t;

#define MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS_LEN 210
#define MAVLINK_MSG_ID_167_LEN 210

#define MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS_CRC 191
#define MAVLINK_MSG_ID_167_CRC 191

#define MAVLINK_MSG_KIRKWOOD_SDLOG_SERVER_HS_FIELD_PAYLOAD_LEN 200

#define MAVLINK_MESSAGE_INFO_KIRKWOOD_SDLOG_SERVER_HS { \
	"KIRKWOOD_SDLOG_SERVER_HS", \
	5, \
	{  { "size", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_kirkwood_sdlog_server_hs_t, size) }, \
         { "current_sequence", NULL, MAVLINK_TYPE_UINT32_T, 0, 4, offsetof(mavlink_kirkwood_sdlog_server_hs_t, current_sequence) }, \
         { "opcode", NULL, MAVLINK_TYPE_UINT8_T, 0, 8, offsetof(mavlink_kirkwood_sdlog_server_hs_t, opcode) }, \
         { "payload", NULL, MAVLINK_TYPE_CHAR, 200, 9, offsetof(mavlink_kirkwood_sdlog_server_hs_t, payload) }, \
         { "reset_sequence", NULL, MAVLINK_TYPE_UINT8_T, 0, 209, offsetof(mavlink_kirkwood_sdlog_server_hs_t, reset_sequence) }, \
         } \
}


/**
 * @brief Pack a kirkwood_sdlog_server_hs message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param opcode See KIRKWOOD_SDLOG_HS_SERVER_OPCODE*
 * @param payload Contains the data for the operation
 * @param size Contains the data for the operation
 * @param reset_sequence Contains the data for the operation
 * @param current_sequence Contains the current sequence
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_kirkwood_sdlog_server_hs_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
						       uint8_t opcode, const char *payload, uint32_t size, uint8_t reset_sequence, uint32_t current_sequence)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS_LEN];
	_mav_put_uint32_t(buf, 0, size);
	_mav_put_uint32_t(buf, 4, current_sequence);
	_mav_put_uint8_t(buf, 8, opcode);
	_mav_put_uint8_t(buf, 209, reset_sequence);
	_mav_put_char_array(buf, 9, payload, 200);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS_LEN);
#elif MAVLINK_C2000
		mav_put_uint32_t_c2000(&(msg->payload64[0]), 0, size);
		mav_put_uint32_t_c2000(&(msg->payload64[0]), 4, current_sequence);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 8, opcode);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 209, reset_sequence);
	
		mav_put_char_array_c2000(&(msg->payload64[0]), payload, 9, 200);
	
#else
	mavlink_kirkwood_sdlog_server_hs_t packet;
	packet.size = size;
	packet.current_sequence = current_sequence;
	packet.opcode = opcode;
	packet.reset_sequence = reset_sequence;
	mav_array_memcpy(packet.payload, payload, sizeof(char)*200);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS_LEN, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS_CRC);
#else
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS_LEN);
#endif
}

/**
 * @brief Pack a kirkwood_sdlog_server_hs message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param opcode See KIRKWOOD_SDLOG_HS_SERVER_OPCODE*
 * @param payload Contains the data for the operation
 * @param size Contains the data for the operation
 * @param reset_sequence Contains the data for the operation
 * @param current_sequence Contains the current sequence
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_kirkwood_sdlog_server_hs_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
							   mavlink_message_t* msg,
						           uint8_t opcode,const char *payload,uint32_t size,uint8_t reset_sequence,uint32_t current_sequence)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS_LEN];
	_mav_put_uint32_t(buf, 0, size);
	_mav_put_uint32_t(buf, 4, current_sequence);
	_mav_put_uint8_t(buf, 8, opcode);
	_mav_put_uint8_t(buf, 209, reset_sequence);
	_mav_put_char_array(buf, 9, payload, 200);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS_LEN);
#else
	mavlink_kirkwood_sdlog_server_hs_t packet;
	packet.size = size;
	packet.current_sequence = current_sequence;
	packet.opcode = opcode;
	packet.reset_sequence = reset_sequence;
	mav_array_memcpy(packet.payload, payload, sizeof(char)*200);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS_LEN, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS_CRC);
#else
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS_LEN);
#endif
}

/**
 * @brief Encode a kirkwood_sdlog_server_hs struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param kirkwood_sdlog_server_hs C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_kirkwood_sdlog_server_hs_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_kirkwood_sdlog_server_hs_t* kirkwood_sdlog_server_hs)
{
	return mavlink_msg_kirkwood_sdlog_server_hs_pack(system_id, component_id, msg, kirkwood_sdlog_server_hs->opcode, kirkwood_sdlog_server_hs->payload, kirkwood_sdlog_server_hs->size, kirkwood_sdlog_server_hs->reset_sequence, kirkwood_sdlog_server_hs->current_sequence);
}

/**
 * @brief Encode a kirkwood_sdlog_server_hs struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param kirkwood_sdlog_server_hs C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_kirkwood_sdlog_server_hs_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_kirkwood_sdlog_server_hs_t* kirkwood_sdlog_server_hs)
{
	return mavlink_msg_kirkwood_sdlog_server_hs_pack_chan(system_id, component_id, chan, msg, kirkwood_sdlog_server_hs->opcode, kirkwood_sdlog_server_hs->payload, kirkwood_sdlog_server_hs->size, kirkwood_sdlog_server_hs->reset_sequence, kirkwood_sdlog_server_hs->current_sequence);
}

/**
 * @brief Send a kirkwood_sdlog_server_hs message
 * @param chan MAVLink channel to send the message
 *
 * @param opcode See KIRKWOOD_SDLOG_HS_SERVER_OPCODE*
 * @param payload Contains the data for the operation
 * @param size Contains the data for the operation
 * @param reset_sequence Contains the data for the operation
 * @param current_sequence Contains the current sequence
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_kirkwood_sdlog_server_hs_send(mavlink_channel_t chan, uint8_t opcode, const char *payload, uint32_t size, uint8_t reset_sequence, uint32_t current_sequence)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS_LEN];
	_mav_put_uint32_t(buf, 0, size);
	_mav_put_uint32_t(buf, 4, current_sequence);
	_mav_put_uint8_t(buf, 8, opcode);
	_mav_put_uint8_t(buf, 209, reset_sequence);
	_mav_put_char_array(buf, 9, payload, 200);
#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS, buf, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS_LEN, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS, buf, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS_LEN);
#endif
#else
	mavlink_kirkwood_sdlog_server_hs_t packet;
	packet.size = size;
	packet.current_sequence = current_sequence;
	packet.opcode = opcode;
	packet.reset_sequence = reset_sequence;
	mav_array_memcpy(packet.payload, payload, sizeof(char)*200);
#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS, (const char *)&packet, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS_LEN, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS, (const char *)&packet, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS_LEN);
#endif
#endif
}

#if MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_kirkwood_sdlog_server_hs_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint8_t opcode, const char *payload, uint32_t size, uint8_t reset_sequence, uint32_t current_sequence)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char *buf = (char *)msgbuf;
	_mav_put_uint32_t(buf, 0, size);
	_mav_put_uint32_t(buf, 4, current_sequence);
	_mav_put_uint8_t(buf, 8, opcode);
	_mav_put_uint8_t(buf, 209, reset_sequence);
	_mav_put_char_array(buf, 9, payload, 200);
#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS, buf, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS_LEN, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS, buf, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS_LEN);
#endif
#else
	mavlink_kirkwood_sdlog_server_hs_t *packet = (mavlink_kirkwood_sdlog_server_hs_t *)msgbuf;
	packet->size = size;
	packet->current_sequence = current_sequence;
	packet->opcode = opcode;
	packet->reset_sequence = reset_sequence;
	mav_array_memcpy(packet->payload, payload, sizeof(char)*200);
#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS, (const char *)packet, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS_LEN, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS, (const char *)packet, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS_LEN);
#endif
#endif
}
#endif

#endif

// MESSAGE KIRKWOOD_SDLOG_SERVER_HS UNPACKING


/**
 * @brief Get field opcode from kirkwood_sdlog_server_hs message
 *
 * @return See KIRKWOOD_SDLOG_HS_SERVER_OPCODE*
 */
static inline uint8_t mavlink_msg_kirkwood_sdlog_server_hs_get_opcode(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  8);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  8);
#endif
}

/**
 * @brief Get field payload from kirkwood_sdlog_server_hs message
 *
 * @return Contains the data for the operation
 */
static inline uint16_t mavlink_msg_kirkwood_sdlog_server_hs_get_payload(const mavlink_message_t* msg, char *payload)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_char_array(msg, payload, 200,  9);
#else
	return mav_get_char_array_c2000(&(msg->payload64[0]), payload, 200,  9);
#endif
}

/**
 * @brief Get field size from kirkwood_sdlog_server_hs message
 *
 * @return Contains the data for the operation
 */
static inline uint32_t mavlink_msg_kirkwood_sdlog_server_hs_get_size(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint32_t(msg,  0);
#else
	return mav_get_uint32_t_c2000(&(msg->payload64[0]),  0);
#endif
}

/**
 * @brief Get field reset_sequence from kirkwood_sdlog_server_hs message
 *
 * @return Contains the data for the operation
 */
static inline uint8_t mavlink_msg_kirkwood_sdlog_server_hs_get_reset_sequence(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  209);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  209);
#endif
}

/**
 * @brief Get field current_sequence from kirkwood_sdlog_server_hs message
 *
 * @return Contains the current sequence
 */
static inline uint32_t mavlink_msg_kirkwood_sdlog_server_hs_get_current_sequence(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint32_t(msg,  4);
#else
	return mav_get_uint32_t_c2000(&(msg->payload64[0]),  4);
#endif
}

/**
 * @brief Decode a kirkwood_sdlog_server_hs message into a struct
 *
 * @param msg The message to decode
 * @param kirkwood_sdlog_server_hs C-struct to decode the message contents into
 */
static inline void mavlink_msg_kirkwood_sdlog_server_hs_decode(const mavlink_message_t* msg, mavlink_kirkwood_sdlog_server_hs_t* kirkwood_sdlog_server_hs)
{
#if MAVLINK_NEED_BYTE_SWAP || MAVLINK_C2000
	kirkwood_sdlog_server_hs->size = mavlink_msg_kirkwood_sdlog_server_hs_get_size(msg);
	kirkwood_sdlog_server_hs->current_sequence = mavlink_msg_kirkwood_sdlog_server_hs_get_current_sequence(msg);
	kirkwood_sdlog_server_hs->opcode = mavlink_msg_kirkwood_sdlog_server_hs_get_opcode(msg);
	mavlink_msg_kirkwood_sdlog_server_hs_get_payload(msg, kirkwood_sdlog_server_hs->payload);
	kirkwood_sdlog_server_hs->reset_sequence = mavlink_msg_kirkwood_sdlog_server_hs_get_reset_sequence(msg);
#else
	memcpy(kirkwood_sdlog_server_hs, _MAV_PAYLOAD(msg), MAVLINK_MSG_ID_KIRKWOOD_SDLOG_SERVER_HS_LEN);
#endif
}
