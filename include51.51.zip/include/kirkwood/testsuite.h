/** @file
 *	@brief MAVLink comm protocol testsuite generated from kirkwood.xml
 *	@see http://qgroundcontrol.org/mavlink/
 */
#ifndef KIRKWOOD_TESTSUITE_H
#define KIRKWOOD_TESTSUITE_H

#ifdef __cplusplus
extern "C" {
#endif

#ifndef MAVLINK_TEST_ALL
#define MAVLINK_TEST_ALL
static void mavlink_test_common(uint8_t, uint8_t, mavlink_message_t *last_msg);
static void mavlink_test_bootloader(uint8_t, uint8_t, mavlink_message_t *last_msg);
static void mavlink_test_kirkwood_component_id(uint8_t, uint8_t, mavlink_message_t *last_msg);
static void mavlink_test_kw_debug(uint8_t, uint8_t, mavlink_message_t *last_msg);
static void mavlink_test_kirkwood(uint8_t, uint8_t, mavlink_message_t *last_msg);

static void mavlink_test_all(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
	mavlink_test_common(system_id, component_id, last_msg);
	mavlink_test_bootloader(system_id, component_id, last_msg);
	mavlink_test_kirkwood_component_id(system_id, component_id, last_msg);
	mavlink_test_kw_debug(system_id, component_id, last_msg);
	mavlink_test_kirkwood(system_id, component_id, last_msg);
}
#endif

#include "../common/testsuite.h"
#include "../bootloader/testsuite.h"
#include "../kirkwood_component_id/testsuite.h"
#include "../kw_debug/testsuite.h"


static void mavlink_test_kirkwood_event(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
	mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
	mavlink_kirkwood_event_t packet_in = {
		93372036854775807ULL,963497880
    };
	mavlink_kirkwood_event_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        	packet1.timestamp = packet_in.timestamp;
        	packet1.event = packet_in.event;
        
        

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_event_encode(system_id, component_id, &msg, &packet1);
	mavlink_msg_kirkwood_event_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_event_pack(system_id, component_id, &msg , packet1.event , packet1.timestamp );
	mavlink_msg_kirkwood_event_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_event_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.event , packet1.timestamp );
	mavlink_msg_kirkwood_event_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
        	comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
	mavlink_msg_kirkwood_event_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_event_send(MAVLINK_COMM_1 , packet1.event , packet1.timestamp );
	mavlink_msg_kirkwood_event_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
}

static void mavlink_test_kirkwood_position(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
	mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
	mavlink_kirkwood_position_t packet_in = {
		93372036854775807ULL,963497880,963498088,963498296,157.0,185.0,213.0,241.0,269.0,19315,19419
    };
	mavlink_kirkwood_position_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        	packet1.time_usec = packet_in.time_usec;
        	packet1.lat = packet_in.lat;
        	packet1.lon = packet_in.lon;
        	packet1.alt = packet_in.alt;
        	packet1.heading = packet_in.heading;
        	packet1.camera_pitch = packet_in.camera_pitch;
        	packet1.relx = packet_in.relx;
        	packet1.rely = packet_in.rely;
        	packet1.relz = packet_in.relz;
        	packet1.type = packet_in.type;
        	packet1.id = packet_in.id;
        
        

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_position_encode(system_id, component_id, &msg, &packet1);
	mavlink_msg_kirkwood_position_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_position_pack(system_id, component_id, &msg , packet1.time_usec , packet1.type , packet1.id , packet1.lat , packet1.lon , packet1.alt , packet1.heading , packet1.camera_pitch , packet1.relx , packet1.rely , packet1.relz );
	mavlink_msg_kirkwood_position_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_position_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.time_usec , packet1.type , packet1.id , packet1.lat , packet1.lon , packet1.alt , packet1.heading , packet1.camera_pitch , packet1.relx , packet1.rely , packet1.relz );
	mavlink_msg_kirkwood_position_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
        	comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
	mavlink_msg_kirkwood_position_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_position_send(MAVLINK_COMM_1 , packet1.time_usec , packet1.type , packet1.id , packet1.lat , packet1.lon , packet1.alt , packet1.heading , packet1.camera_pitch , packet1.relx , packet1.rely , packet1.relz );
	mavlink_msg_kirkwood_position_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
}

static void mavlink_test_kirkwood_maneuver_status(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
	mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
	mavlink_kirkwood_maneuver_status_t packet_in = {
		17235,17339,17443,151,218
    };
	mavlink_kirkwood_maneuver_status_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        	packet1.type = packet_in.type;
        	packet1.state = packet_in.state;
        	packet1.trigger = packet_in.trigger;
        	packet1.progress = packet_in.progress;
        	packet1.status = packet_in.status;
        
        

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_maneuver_status_encode(system_id, component_id, &msg, &packet1);
	mavlink_msg_kirkwood_maneuver_status_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_maneuver_status_pack(system_id, component_id, &msg , packet1.type , packet1.state , packet1.progress , packet1.status , packet1.trigger );
	mavlink_msg_kirkwood_maneuver_status_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_maneuver_status_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.type , packet1.state , packet1.progress , packet1.status , packet1.trigger );
	mavlink_msg_kirkwood_maneuver_status_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
        	comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
	mavlink_msg_kirkwood_maneuver_status_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_maneuver_status_send(MAVLINK_COMM_1 , packet1.type , packet1.state , packet1.progress , packet1.status , packet1.trigger );
	mavlink_msg_kirkwood_maneuver_status_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
}

static void mavlink_test_kirkwood_esc_status(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
	mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
	mavlink_kirkwood_esc_status_t packet_in = {
		93372036854775807ULL,{ 17651, 17652, 17653, 17654 },{ 18067, 18068, 18069, 18070 },{ 18483, 18484, 18485, 18486 },{ 18899, 18900, 18901, 18902 },{ 19315, 19316, 19317, 19318 },{ 19731, 19732, 19733, 19734 },{ 20147, 20148, 20149, 20150 },197
    };
	mavlink_kirkwood_esc_status_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        	packet1.timestamp = packet_in.timestamp;
        	packet1.state = packet_in.state;
        
        	mav_array_memcpy(packet1.motor_speed_actual, packet_in.motor_speed_actual, sizeof(uint16_t)*4);
        	mav_array_memcpy(packet1.motor_speed_request, packet_in.motor_speed_request, sizeof(uint16_t)*4);
        	mav_array_memcpy(packet1.esc_temparature, packet_in.esc_temparature, sizeof(int16_t)*4);
        	mav_array_memcpy(packet1.esc_voltage, packet_in.esc_voltage, sizeof(uint16_t)*4);
        	mav_array_memcpy(packet1.esc_current, packet_in.esc_current, sizeof(uint16_t)*4);
        	mav_array_memcpy(packet1.esc_state, packet_in.esc_state, sizeof(uint16_t)*4);
        	mav_array_memcpy(packet1.esc_cmd_fault, packet_in.esc_cmd_fault, sizeof(uint16_t)*4);
        

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_esc_status_encode(system_id, component_id, &msg, &packet1);
	mavlink_msg_kirkwood_esc_status_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_esc_status_pack(system_id, component_id, &msg , packet1.timestamp , packet1.motor_speed_actual , packet1.motor_speed_request , packet1.esc_temparature , packet1.esc_voltage , packet1.esc_current , packet1.esc_state , packet1.esc_cmd_fault , packet1.state );
	mavlink_msg_kirkwood_esc_status_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_esc_status_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.timestamp , packet1.motor_speed_actual , packet1.motor_speed_request , packet1.esc_temparature , packet1.esc_voltage , packet1.esc_current , packet1.esc_state , packet1.esc_cmd_fault , packet1.state );
	mavlink_msg_kirkwood_esc_status_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
        	comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
	mavlink_msg_kirkwood_esc_status_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_esc_status_send(MAVLINK_COMM_1 , packet1.timestamp , packet1.motor_speed_actual , packet1.motor_speed_request , packet1.esc_temparature , packet1.esc_voltage , packet1.esc_current , packet1.esc_state , packet1.esc_cmd_fault , packet1.state );
	mavlink_msg_kirkwood_esc_status_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
}

static void mavlink_test_kirkwood_vehicle_attitude_setpoint(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
	mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
	mavlink_kirkwood_vehicle_attitude_setpoint_t packet_in = {
		93372036854775807ULL,73.0,101.0,129.0,157.0
    };
	mavlink_kirkwood_vehicle_attitude_setpoint_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        	packet1.timestamp = packet_in.timestamp;
        	packet1.roll = packet_in.roll;
        	packet1.pitch = packet_in.pitch;
        	packet1.yaw = packet_in.yaw;
        	packet1.thrust = packet_in.thrust;
        
        

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_vehicle_attitude_setpoint_encode(system_id, component_id, &msg, &packet1);
	mavlink_msg_kirkwood_vehicle_attitude_setpoint_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_vehicle_attitude_setpoint_pack(system_id, component_id, &msg , packet1.timestamp , packet1.roll , packet1.pitch , packet1.yaw , packet1.thrust );
	mavlink_msg_kirkwood_vehicle_attitude_setpoint_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_vehicle_attitude_setpoint_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.timestamp , packet1.roll , packet1.pitch , packet1.yaw , packet1.thrust );
	mavlink_msg_kirkwood_vehicle_attitude_setpoint_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
        	comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
	mavlink_msg_kirkwood_vehicle_attitude_setpoint_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_vehicle_attitude_setpoint_send(MAVLINK_COMM_1 , packet1.timestamp , packet1.roll , packet1.pitch , packet1.yaw , packet1.thrust );
	mavlink_msg_kirkwood_vehicle_attitude_setpoint_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
}

static void mavlink_test_kirkwood_sdlog_client_hs(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
	mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
	mavlink_kirkwood_sdlog_client_hs_t packet_in = {
		963497464,963497672,29
    };
	mavlink_kirkwood_sdlog_client_hs_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        	packet1.index_start = packet_in.index_start;
        	packet1.index_end = packet_in.index_end;
        	packet1.opcode = packet_in.opcode;
        
        

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_sdlog_client_hs_encode(system_id, component_id, &msg, &packet1);
	mavlink_msg_kirkwood_sdlog_client_hs_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_sdlog_client_hs_pack(system_id, component_id, &msg , packet1.opcode , packet1.index_start , packet1.index_end );
	mavlink_msg_kirkwood_sdlog_client_hs_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_sdlog_client_hs_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.opcode , packet1.index_start , packet1.index_end );
	mavlink_msg_kirkwood_sdlog_client_hs_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
        	comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
	mavlink_msg_kirkwood_sdlog_client_hs_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_sdlog_client_hs_send(MAVLINK_COMM_1 , packet1.opcode , packet1.index_start , packet1.index_end );
	mavlink_msg_kirkwood_sdlog_client_hs_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
}

static void mavlink_test_kirkwood_sdlog_server_hs(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
	mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
	mavlink_kirkwood_sdlog_server_hs_t packet_in = {
		963497464,963497672,29,"JKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZ",184
    };
	mavlink_kirkwood_sdlog_server_hs_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        	packet1.size = packet_in.size;
        	packet1.current_sequence = packet_in.current_sequence;
        	packet1.opcode = packet_in.opcode;
        	packet1.reset_sequence = packet_in.reset_sequence;
        
        	mav_array_memcpy(packet1.payload, packet_in.payload, sizeof(char)*200);
        

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_sdlog_server_hs_encode(system_id, component_id, &msg, &packet1);
	mavlink_msg_kirkwood_sdlog_server_hs_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_sdlog_server_hs_pack(system_id, component_id, &msg , packet1.opcode , packet1.payload , packet1.size , packet1.reset_sequence , packet1.current_sequence );
	mavlink_msg_kirkwood_sdlog_server_hs_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_sdlog_server_hs_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.opcode , packet1.payload , packet1.size , packet1.reset_sequence , packet1.current_sequence );
	mavlink_msg_kirkwood_sdlog_server_hs_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
        	comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
	mavlink_msg_kirkwood_sdlog_server_hs_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_sdlog_server_hs_send(MAVLINK_COMM_1 , packet1.opcode , packet1.payload , packet1.size , packet1.reset_sequence , packet1.current_sequence );
	mavlink_msg_kirkwood_sdlog_server_hs_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
}

static void mavlink_test_kirkwood_battery_status(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
	mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
	mavlink_kirkwood_battery_status_t packet_in = {
		963497464,963497672,963497880,17859,17963,18067,18171,18275,18379,18483,18587,89,156,223,34
    };
	mavlink_kirkwood_battery_status_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        	packet1.current_battery = packet_in.current_battery;
        	packet1.current_consumed = packet_in.current_consumed;
        	packet1.energy_consumed = packet_in.energy_consumed;
        	packet1.temperature = packet_in.temperature;
        	packet1.voltage1 = packet_in.voltage1;
        	packet1.voltage2 = packet_in.voltage2;
        	packet1.voltage3 = packet_in.voltage3;
        	packet1.voltage4 = packet_in.voltage4;
        	packet1.bat_time_to_empty = packet_in.bat_time_to_empty;
        	packet1.bat_soh = packet_in.bat_soh;
        	packet1.bat_cycle_count = packet_in.bat_cycle_count;
        	packet1.id = packet_in.id;
        	packet1.battery_function = packet_in.battery_function;
        	packet1.type = packet_in.type;
        	packet1.battery_remaining = packet_in.battery_remaining;
        
        

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_battery_status_encode(system_id, component_id, &msg, &packet1);
	mavlink_msg_kirkwood_battery_status_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_battery_status_pack(system_id, component_id, &msg , packet1.id , packet1.battery_function , packet1.type , packet1.temperature , packet1.voltage1 , packet1.voltage2 , packet1.voltage3 , packet1.voltage4 , packet1.current_battery , packet1.current_consumed , packet1.energy_consumed , packet1.battery_remaining , packet1.bat_time_to_empty , packet1.bat_soh , packet1.bat_cycle_count );
	mavlink_msg_kirkwood_battery_status_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_battery_status_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.id , packet1.battery_function , packet1.type , packet1.temperature , packet1.voltage1 , packet1.voltage2 , packet1.voltage3 , packet1.voltage4 , packet1.current_battery , packet1.current_consumed , packet1.energy_consumed , packet1.battery_remaining , packet1.bat_time_to_empty , packet1.bat_soh , packet1.bat_cycle_count );
	mavlink_msg_kirkwood_battery_status_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
        	comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
	mavlink_msg_kirkwood_battery_status_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_battery_status_send(MAVLINK_COMM_1 , packet1.id , packet1.battery_function , packet1.type , packet1.temperature , packet1.voltage1 , packet1.voltage2 , packet1.voltage3 , packet1.voltage4 , packet1.current_battery , packet1.current_consumed , packet1.energy_consumed , packet1.battery_remaining , packet1.bat_time_to_empty , packet1.bat_soh , packet1.bat_cycle_count );
	mavlink_msg_kirkwood_battery_status_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
}

static void mavlink_test_kirkwood_nfz_cmd(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
	mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
	mavlink_kirkwood_nfz_cmd_t packet_in = {
		5
    };
	mavlink_kirkwood_nfz_cmd_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        	packet1.command = packet_in.command;
        
        

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_nfz_cmd_encode(system_id, component_id, &msg, &packet1);
	mavlink_msg_kirkwood_nfz_cmd_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_nfz_cmd_pack(system_id, component_id, &msg , packet1.command );
	mavlink_msg_kirkwood_nfz_cmd_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_nfz_cmd_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.command );
	mavlink_msg_kirkwood_nfz_cmd_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
        	comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
	mavlink_msg_kirkwood_nfz_cmd_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_nfz_cmd_send(MAVLINK_COMM_1 , packet1.command );
	mavlink_msg_kirkwood_nfz_cmd_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
}

static void mavlink_test_kirkwood_raw_mag(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
	mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
	mavlink_kirkwood_raw_mag_t packet_in = {
		93372036854775807ULL,73.0,101.0,18067,18171,18275,199,10
    };
	mavlink_kirkwood_raw_mag_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        	packet1.time_usec = packet_in.time_usec;
        	packet1.range_ga = packet_in.range_ga;
        	packet1.temperature = packet_in.temperature;
        	packet1.x_raw = packet_in.x_raw;
        	packet1.y_raw = packet_in.y_raw;
        	packet1.z_raw = packet_in.z_raw;
        	packet1.id = packet_in.id;
        	packet1.flatline = packet_in.flatline;
        
        

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_raw_mag_encode(system_id, component_id, &msg, &packet1);
	mavlink_msg_kirkwood_raw_mag_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_raw_mag_pack(system_id, component_id, &msg , packet1.time_usec , packet1.id , packet1.x_raw , packet1.y_raw , packet1.z_raw , packet1.range_ga , packet1.temperature , packet1.flatline );
	mavlink_msg_kirkwood_raw_mag_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_raw_mag_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.time_usec , packet1.id , packet1.x_raw , packet1.y_raw , packet1.z_raw , packet1.range_ga , packet1.temperature , packet1.flatline );
	mavlink_msg_kirkwood_raw_mag_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
        	comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
	mavlink_msg_kirkwood_raw_mag_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_raw_mag_send(MAVLINK_COMM_1 , packet1.time_usec , packet1.id , packet1.x_raw , packet1.y_raw , packet1.z_raw , packet1.range_ga , packet1.temperature , packet1.flatline );
	mavlink_msg_kirkwood_raw_mag_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
}

static void mavlink_test_kirkwood_raw_acc(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
	mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
	mavlink_kirkwood_raw_acc_t packet_in = {
		93372036854775807ULL,73.0,101.0,129.0,157.0,185.0,18691,18795,18899,235,46
    };
	mavlink_kirkwood_raw_acc_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        	packet1.time_usec = packet_in.time_usec;
        	packet1.x = packet_in.x;
        	packet1.y = packet_in.y;
        	packet1.z = packet_in.z;
        	packet1.range_m_s2 = packet_in.range_m_s2;
        	packet1.temperature = packet_in.temperature;
        	packet1.x_raw = packet_in.x_raw;
        	packet1.y_raw = packet_in.y_raw;
        	packet1.z_raw = packet_in.z_raw;
        	packet1.id = packet_in.id;
        	packet1.flatline = packet_in.flatline;
        
        

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_raw_acc_encode(system_id, component_id, &msg, &packet1);
	mavlink_msg_kirkwood_raw_acc_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_raw_acc_pack(system_id, component_id, &msg , packet1.time_usec , packet1.id , packet1.x_raw , packet1.y_raw , packet1.z_raw , packet1.x , packet1.y , packet1.z , packet1.range_m_s2 , packet1.temperature , packet1.flatline );
	mavlink_msg_kirkwood_raw_acc_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_raw_acc_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.time_usec , packet1.id , packet1.x_raw , packet1.y_raw , packet1.z_raw , packet1.x , packet1.y , packet1.z , packet1.range_m_s2 , packet1.temperature , packet1.flatline );
	mavlink_msg_kirkwood_raw_acc_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
        	comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
	mavlink_msg_kirkwood_raw_acc_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_raw_acc_send(MAVLINK_COMM_1 , packet1.time_usec , packet1.id , packet1.x_raw , packet1.y_raw , packet1.z_raw , packet1.x , packet1.y , packet1.z , packet1.range_m_s2 , packet1.temperature , packet1.flatline );
	mavlink_msg_kirkwood_raw_acc_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
}

static void mavlink_test_coyote_status(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
	mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
	mavlink_coyote_status_t packet_in = {
		963497464,963497672,963497880,{ 101.0, 102.0, 103.0 }
    };
	mavlink_coyote_status_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        	packet1.time_boot_ms = packet_in.time_boot_ms;
        	packet1.state = packet_in.state;
        	packet1.mode = packet_in.mode;
        
        	mav_array_memcpy(packet1.axis_angle, packet_in.axis_angle, sizeof(float)*3);
        

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_coyote_status_encode(system_id, component_id, &msg, &packet1);
	mavlink_msg_coyote_status_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_coyote_status_pack(system_id, component_id, &msg , packet1.time_boot_ms , packet1.state , packet1.mode , packet1.axis_angle );
	mavlink_msg_coyote_status_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_coyote_status_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.time_boot_ms , packet1.state , packet1.mode , packet1.axis_angle );
	mavlink_msg_coyote_status_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
        	comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
	mavlink_msg_coyote_status_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_coyote_status_send(MAVLINK_COMM_1 , packet1.time_boot_ms , packet1.state , packet1.mode , packet1.axis_angle );
	mavlink_msg_coyote_status_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
}

static void mavlink_test_coyote_sense(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
	mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
	mavlink_coyote_sense_t packet_in = {
		963497464,{ 45.0, 46.0, 47.0 },{ 129.0, 130.0, 131.0 },{ 213.0, 214.0, 215.0 }
    };
	mavlink_coyote_sense_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        	packet1.time_boot_ms = packet_in.time_boot_ms;
        
        	mav_array_memcpy(packet1.gyro, packet_in.gyro, sizeof(float)*3);
        	mav_array_memcpy(packet1.accel, packet_in.accel, sizeof(float)*3);
        	mav_array_memcpy(packet1.encoder, packet_in.encoder, sizeof(float)*3);
        

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_coyote_sense_encode(system_id, component_id, &msg, &packet1);
	mavlink_msg_coyote_sense_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_coyote_sense_pack(system_id, component_id, &msg , packet1.time_boot_ms , packet1.gyro , packet1.accel , packet1.encoder );
	mavlink_msg_coyote_sense_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_coyote_sense_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.time_boot_ms , packet1.gyro , packet1.accel , packet1.encoder );
	mavlink_msg_coyote_sense_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
        	comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
	mavlink_msg_coyote_sense_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_coyote_sense_send(MAVLINK_COMM_1 , packet1.time_boot_ms , packet1.gyro , packet1.accel , packet1.encoder );
	mavlink_msg_coyote_sense_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
}

static void mavlink_test_coyote_probe(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
	mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
	mavlink_coyote_probe_t packet_in = {
		963497464,{ 17443, 17444, 17445 },{ 17755, 17756, 17757 },{ 18067, 18068, 18069 },{ 18379, 18380, 18381 }
    };
	mavlink_coyote_probe_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        	packet1.time_boot_ms = packet_in.time_boot_ms;
        
        	mav_array_memcpy(packet1.rail_voltage, packet_in.rail_voltage, sizeof(uint16_t)*3);
        	mav_array_memcpy(packet1.temperature, packet_in.temperature, sizeof(int16_t)*3);
        	mav_array_memcpy(packet1.motor_current_rms, packet_in.motor_current_rms, sizeof(uint16_t)*3);
        	mav_array_memcpy(packet1.motor_current_peak, packet_in.motor_current_peak, sizeof(int16_t)*3);
        

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_coyote_probe_encode(system_id, component_id, &msg, &packet1);
	mavlink_msg_coyote_probe_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_coyote_probe_pack(system_id, component_id, &msg , packet1.time_boot_ms , packet1.rail_voltage , packet1.temperature , packet1.motor_current_rms , packet1.motor_current_peak );
	mavlink_msg_coyote_probe_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_coyote_probe_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.time_boot_ms , packet1.rail_voltage , packet1.temperature , packet1.motor_current_rms , packet1.motor_current_peak );
	mavlink_msg_coyote_probe_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
        	comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
	mavlink_msg_coyote_probe_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_coyote_probe_send(MAVLINK_COMM_1 , packet1.time_boot_ms , packet1.rail_voltage , packet1.temperature , packet1.motor_current_rms , packet1.motor_current_peak );
	mavlink_msg_coyote_probe_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
}

static void mavlink_test_coyote_debug(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
	mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
	mavlink_coyote_debug_t packet_in = {
		963497464,{ 45.0, 46.0, 47.0, 48.0, 49.0, 50.0 },18691
    };
	mavlink_coyote_debug_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        	packet1.time_boot_ms = packet_in.time_boot_ms;
        	packet1.type = packet_in.type;
        
        	mav_array_memcpy(packet1.data, packet_in.data, sizeof(float)*6);
        

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_coyote_debug_encode(system_id, component_id, &msg, &packet1);
	mavlink_msg_coyote_debug_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_coyote_debug_pack(system_id, component_id, &msg , packet1.time_boot_ms , packet1.type , packet1.data );
	mavlink_msg_coyote_debug_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_coyote_debug_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.time_boot_ms , packet1.type , packet1.data );
	mavlink_msg_coyote_debug_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
        	comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
	mavlink_msg_coyote_debug_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_coyote_debug_send(MAVLINK_COMM_1 , packet1.time_boot_ms , packet1.type , packet1.data );
	mavlink_msg_coyote_debug_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
}

static void mavlink_test_coyote_cal_params(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
	mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
	mavlink_coyote_cal_params_t packet_in = {
		963497464,{ 45.0, 46.0, 47.0, 48.0, 49.0, 50.0, 51.0, 52.0, 53.0 },{ 297.0, 298.0, 299.0 },{ 381.0, 382.0, 383.0 }
    };
	mavlink_coyote_cal_params_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        	packet1.id = packet_in.id;
        
        	mav_array_memcpy(packet1.rotation, packet_in.rotation, sizeof(float)*9);
        	mav_array_memcpy(packet1.offset, packet_in.offset, sizeof(float)*3);
        	mav_array_memcpy(packet1.scale, packet_in.scale, sizeof(float)*3);
        

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_coyote_cal_params_encode(system_id, component_id, &msg, &packet1);
	mavlink_msg_coyote_cal_params_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_coyote_cal_params_pack(system_id, component_id, &msg , packet1.id , packet1.rotation , packet1.offset , packet1.scale );
	mavlink_msg_coyote_cal_params_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_coyote_cal_params_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.id , packet1.rotation , packet1.offset , packet1.scale );
	mavlink_msg_coyote_cal_params_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
        	comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
	mavlink_msg_coyote_cal_params_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_coyote_cal_params_send(MAVLINK_COMM_1 , packet1.id , packet1.rotation , packet1.offset , packet1.scale );
	mavlink_msg_coyote_cal_params_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
}

static void mavlink_test_kirkwood_test(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
	mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
	mavlink_kirkwood_test_t packet_in = {
		963497464,17,84,151,"HIJKLMNOPQRSTUVWXYZ","BCDEFGHIJKLMNOPQRST","VWXYZABCDEFGHIJKLMN","PQRSTUVWXYZABCDEFGH","JKLMNOPQRSTUVWXYZAB","DEFGHIJKLMNOPQRSTUV","XYZABCDEFGHIJKLMNOP"
    };
	mavlink_kirkwood_test_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        	packet1.device = packet_in.device;
        	packet1.status = packet_in.status;
        	packet1.verbose = packet_in.verbose;
        	packet1.argc = packet_in.argc;
        
        	mav_array_memcpy(packet1.arg0, packet_in.arg0, sizeof(char)*20);
        	mav_array_memcpy(packet1.arg1, packet_in.arg1, sizeof(char)*20);
        	mav_array_memcpy(packet1.arg2, packet_in.arg2, sizeof(char)*20);
        	mav_array_memcpy(packet1.arg3, packet_in.arg3, sizeof(char)*20);
        	mav_array_memcpy(packet1.arg4, packet_in.arg4, sizeof(char)*20);
        	mav_array_memcpy(packet1.arg5, packet_in.arg5, sizeof(char)*20);
        	mav_array_memcpy(packet1.arg6, packet_in.arg6, sizeof(char)*20);
        

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_test_encode(system_id, component_id, &msg, &packet1);
	mavlink_msg_kirkwood_test_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_test_pack(system_id, component_id, &msg , packet1.device , packet1.status , packet1.verbose , packet1.argc , packet1.arg0 , packet1.arg1 , packet1.arg2 , packet1.arg3 , packet1.arg4 , packet1.arg5 , packet1.arg6 );
	mavlink_msg_kirkwood_test_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_test_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.device , packet1.status , packet1.verbose , packet1.argc , packet1.arg0 , packet1.arg1 , packet1.arg2 , packet1.arg3 , packet1.arg4 , packet1.arg5 , packet1.arg6 );
	mavlink_msg_kirkwood_test_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
        	comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
	mavlink_msg_kirkwood_test_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_test_send(MAVLINK_COMM_1 , packet1.device , packet1.status , packet1.verbose , packet1.argc , packet1.arg0 , packet1.arg1 , packet1.arg2 , packet1.arg3 , packet1.arg4 , packet1.arg5 , packet1.arg6 );
	mavlink_msg_kirkwood_test_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
}

static void mavlink_test_kirkwood_system_health(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
	mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
	mavlink_kirkwood_system_health_t packet_in = {
		5,72,139,206,17,84,151,218,29,96,163,230,41,108,175,242,53,120
    };
	mavlink_kirkwood_system_health_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        	packet1.accel = packet_in.accel;
        	packet1.mag = packet_in.mag;
        	packet1.gyro = packet_in.gyro;
        	packet1.baro = packet_in.baro;
        	packet1.gps = packet_in.gps;
        	packet1.rc = packet_in.rc;
        	packet1.rc_override = packet_in.rc_override;
        	packet1.battery = packet_in.battery;
        	packet1.gimbal = packet_in.gimbal;
        	packet1.esc = packet_in.esc;
        	packet1.global_pos = packet_in.global_pos;
        	packet1.local_pos = packet_in.local_pos;
        	packet1.gps_pos = packet_in.gps_pos;
        	packet1.home_pos = packet_in.home_pos;
        	packet1.arms_deployed = packet_in.arms_deployed;
        	packet1.landing_gear_deployed = packet_in.landing_gear_deployed;
        	packet1.upright = packet_in.upright;
        	packet1.nfz = packet_in.nfz;
        
        

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_system_health_encode(system_id, component_id, &msg, &packet1);
	mavlink_msg_kirkwood_system_health_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_system_health_pack(system_id, component_id, &msg , packet1.accel , packet1.mag , packet1.gyro , packet1.baro , packet1.gps , packet1.rc , packet1.rc_override , packet1.battery , packet1.gimbal , packet1.esc , packet1.global_pos , packet1.local_pos , packet1.gps_pos , packet1.home_pos , packet1.arms_deployed , packet1.landing_gear_deployed , packet1.upright , packet1.nfz );
	mavlink_msg_kirkwood_system_health_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_system_health_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.accel , packet1.mag , packet1.gyro , packet1.baro , packet1.gps , packet1.rc , packet1.rc_override , packet1.battery , packet1.gimbal , packet1.esc , packet1.global_pos , packet1.local_pos , packet1.gps_pos , packet1.home_pos , packet1.arms_deployed , packet1.landing_gear_deployed , packet1.upright , packet1.nfz );
	mavlink_msg_kirkwood_system_health_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
        	comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
	mavlink_msg_kirkwood_system_health_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_system_health_send(MAVLINK_COMM_1 , packet1.accel , packet1.mag , packet1.gyro , packet1.baro , packet1.gps , packet1.rc , packet1.rc_override , packet1.battery , packet1.gimbal , packet1.esc , packet1.global_pos , packet1.local_pos , packet1.gps_pos , packet1.home_pos , packet1.arms_deployed , packet1.landing_gear_deployed , packet1.upright , packet1.nfz );
	mavlink_msg_kirkwood_system_health_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
}

static void mavlink_test_flight_status(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
	mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
	mavlink_flight_status_t packet_in = {
		963497464,963497672,963497880,41,108
    };
	mavlink_flight_status_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        	packet1.flight_mode = packet_in.flight_mode;
        	packet1.flight_mode_state = packet_in.flight_mode_state;
        	packet1.flight_control_mode = packet_in.flight_control_mode;
        	packet1.armed = packet_in.armed;
        	packet1.preflight_check_passed = packet_in.preflight_check_passed;
        
        

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_flight_status_encode(system_id, component_id, &msg, &packet1);
	mavlink_msg_flight_status_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_flight_status_pack(system_id, component_id, &msg , packet1.flight_mode , packet1.flight_mode_state , packet1.flight_control_mode , packet1.armed , packet1.preflight_check_passed );
	mavlink_msg_flight_status_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_flight_status_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.flight_mode , packet1.flight_mode_state , packet1.flight_control_mode , packet1.armed , packet1.preflight_check_passed );
	mavlink_msg_flight_status_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
        	comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
	mavlink_msg_flight_status_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_flight_status_send(MAVLINK_COMM_1 , packet1.flight_mode , packet1.flight_mode_state , packet1.flight_control_mode , packet1.armed , packet1.preflight_check_passed );
	mavlink_msg_flight_status_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
}

static void mavlink_test_kirkwood_calib_result(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
	mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
	mavlink_kirkwood_calib_result_t packet_in = {
		{ 17.0, 18.0, 19.0 },{ 101.0, 102.0, 103.0 },77,144
    };
	mavlink_kirkwood_calib_result_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        	packet1.result = packet_in.result;
        	packet1.device_type = packet_in.device_type;
        
        	mav_array_memcpy(packet1.offset, packet_in.offset, sizeof(float)*3);
        	mav_array_memcpy(packet1.scale, packet_in.scale, sizeof(float)*3);
        

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_calib_result_encode(system_id, component_id, &msg, &packet1);
	mavlink_msg_kirkwood_calib_result_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_calib_result_pack(system_id, component_id, &msg , packet1.result , packet1.device_type , packet1.offset , packet1.scale );
	mavlink_msg_kirkwood_calib_result_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_calib_result_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.result , packet1.device_type , packet1.offset , packet1.scale );
	mavlink_msg_kirkwood_calib_result_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
        	comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
	mavlink_msg_kirkwood_calib_result_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_kirkwood_calib_result_send(MAVLINK_COMM_1 , packet1.result , packet1.device_type , packet1.offset , packet1.scale );
	mavlink_msg_kirkwood_calib_result_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
}

static void mavlink_test_kirkwood(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
	mavlink_test_kirkwood_event(system_id, component_id, last_msg);
	mavlink_test_kirkwood_position(system_id, component_id, last_msg);
	mavlink_test_kirkwood_maneuver_status(system_id, component_id, last_msg);
	mavlink_test_kirkwood_esc_status(system_id, component_id, last_msg);
	mavlink_test_kirkwood_vehicle_attitude_setpoint(system_id, component_id, last_msg);
	mavlink_test_kirkwood_sdlog_client_hs(system_id, component_id, last_msg);
	mavlink_test_kirkwood_sdlog_server_hs(system_id, component_id, last_msg);
	mavlink_test_kirkwood_battery_status(system_id, component_id, last_msg);
	mavlink_test_kirkwood_nfz_cmd(system_id, component_id, last_msg);
	mavlink_test_kirkwood_raw_mag(system_id, component_id, last_msg);
	mavlink_test_kirkwood_raw_acc(system_id, component_id, last_msg);
	mavlink_test_coyote_status(system_id, component_id, last_msg);
	mavlink_test_coyote_sense(system_id, component_id, last_msg);
	mavlink_test_coyote_probe(system_id, component_id, last_msg);
	mavlink_test_coyote_debug(system_id, component_id, last_msg);
	mavlink_test_coyote_cal_params(system_id, component_id, last_msg);
	mavlink_test_kirkwood_test(system_id, component_id, last_msg);
	mavlink_test_kirkwood_system_health(system_id, component_id, last_msg);
	mavlink_test_flight_status(system_id, component_id, last_msg);
	mavlink_test_kirkwood_calib_result(system_id, component_id, last_msg);
}

#ifdef __cplusplus
}
#endif // __cplusplus
#endif // KIRKWOOD_TESTSUITE_H
