// MESSAGE KIRKWOOD_POSITION PACKING

#if MAVLINK_C2000
#include "../protocol_c2000.h"
#endif

#define MAVLINK_MSG_ID_KIRKWOOD_POSITION 161

typedef struct __mavlink_kirkwood_position_t
{
 uint64_t time_usec; /*< Timestamp (microseconds since UNIX epoch or microseconds since system boot)*/
 int32_t lat; /*< Latitude, expressed as * 1E7*/
 int32_t lon; /*< Longitude, expressed as * 1E7*/
 int32_t alt; /*< Altitude in meters, expressed as * 1000 (millimeters), above MSL*/
 float heading; /*< Compass heading -180 to 180 in degrees*/
 float camera_pitch; /*< Camera pitch -180 to 180 in degrees*/
 float relx; /*< Relative position, rate, distance depending on type in meters or m/s in NED so x == N*/
 float rely; /*< Relative position, rate, distance depending on type in meters or m/s in NED so y == E*/
 float relz; /*< Relative position, rate, distance depending on type in meters or m/s in NED so z == D*/
 uint16_t type; /*< Point type. See KW_POSE_TYPE in kw_types.h **/
 uint16_t id; /*< Additional info about the point depending on point type (i.e. waypoint number)*/
} mavlink_kirkwood_position_t;

#define MAVLINK_MSG_ID_KIRKWOOD_POSITION_LEN 44
#define MAVLINK_MSG_ID_161_LEN 44

#define MAVLINK_MSG_ID_KIRKWOOD_POSITION_CRC 141
#define MAVLINK_MSG_ID_161_CRC 141



#define MAVLINK_MESSAGE_INFO_KIRKWOOD_POSITION { \
	"KIRKWOOD_POSITION", \
	11, \
	{  { "time_usec", NULL, MAVLINK_TYPE_UINT64_T, 0, 0, offsetof(mavlink_kirkwood_position_t, time_usec) }, \
         { "lat", NULL, MAVLINK_TYPE_INT32_T, 0, 8, offsetof(mavlink_kirkwood_position_t, lat) }, \
         { "lon", NULL, MAVLINK_TYPE_INT32_T, 0, 12, offsetof(mavlink_kirkwood_position_t, lon) }, \
         { "alt", NULL, MAVLINK_TYPE_INT32_T, 0, 16, offsetof(mavlink_kirkwood_position_t, alt) }, \
         { "heading", NULL, MAVLINK_TYPE_FLOAT, 0, 20, offsetof(mavlink_kirkwood_position_t, heading) }, \
         { "camera_pitch", NULL, MAVLINK_TYPE_FLOAT, 0, 24, offsetof(mavlink_kirkwood_position_t, camera_pitch) }, \
         { "relx", NULL, MAVLINK_TYPE_FLOAT, 0, 28, offsetof(mavlink_kirkwood_position_t, relx) }, \
         { "rely", NULL, MAVLINK_TYPE_FLOAT, 0, 32, offsetof(mavlink_kirkwood_position_t, rely) }, \
         { "relz", NULL, MAVLINK_TYPE_FLOAT, 0, 36, offsetof(mavlink_kirkwood_position_t, relz) }, \
         { "type", NULL, MAVLINK_TYPE_UINT16_T, 0, 40, offsetof(mavlink_kirkwood_position_t, type) }, \
         { "id", NULL, MAVLINK_TYPE_UINT16_T, 0, 42, offsetof(mavlink_kirkwood_position_t, id) }, \
         } \
}


/**
 * @brief Pack a kirkwood_position message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param time_usec Timestamp (microseconds since UNIX epoch or microseconds since system boot)
 * @param type Point type. See KW_POSE_TYPE in kw_types.h *
 * @param id Additional info about the point depending on point type (i.e. waypoint number)
 * @param lat Latitude, expressed as * 1E7
 * @param lon Longitude, expressed as * 1E7
 * @param alt Altitude in meters, expressed as * 1000 (millimeters), above MSL
 * @param heading Compass heading -180 to 180 in degrees
 * @param camera_pitch Camera pitch -180 to 180 in degrees
 * @param relx Relative position, rate, distance depending on type in meters or m/s in NED so x == N
 * @param rely Relative position, rate, distance depending on type in meters or m/s in NED so y == E
 * @param relz Relative position, rate, distance depending on type in meters or m/s in NED so z == D
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_kirkwood_position_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
						       uint64_t time_usec, uint16_t type, uint16_t id, int32_t lat, int32_t lon, int32_t alt, float heading, float camera_pitch, float relx, float rely, float relz)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_POSITION_LEN];
	_mav_put_uint64_t(buf, 0, time_usec);
	_mav_put_int32_t(buf, 8, lat);
	_mav_put_int32_t(buf, 12, lon);
	_mav_put_int32_t(buf, 16, alt);
	_mav_put_float(buf, 20, heading);
	_mav_put_float(buf, 24, camera_pitch);
	_mav_put_float(buf, 28, relx);
	_mav_put_float(buf, 32, rely);
	_mav_put_float(buf, 36, relz);
	_mav_put_uint16_t(buf, 40, type);
	_mav_put_uint16_t(buf, 42, id);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_KIRKWOOD_POSITION_LEN);
#elif MAVLINK_C2000
		mav_put_uint64_t_c2000(&(msg->payload64[0]), 0, time_usec);
		mav_put_int32_t_c2000(&(msg->payload64[0]), 8, lat);
		mav_put_int32_t_c2000(&(msg->payload64[0]), 12, lon);
		mav_put_int32_t_c2000(&(msg->payload64[0]), 16, alt);
		mav_put_float_c2000(&(msg->payload64[0]), 20, heading);
		mav_put_float_c2000(&(msg->payload64[0]), 24, camera_pitch);
		mav_put_float_c2000(&(msg->payload64[0]), 28, relx);
		mav_put_float_c2000(&(msg->payload64[0]), 32, rely);
		mav_put_float_c2000(&(msg->payload64[0]), 36, relz);
		mav_put_uint16_t_c2000(&(msg->payload64[0]), 40, type);
		mav_put_uint16_t_c2000(&(msg->payload64[0]), 42, id);
	
	
#else
	mavlink_kirkwood_position_t packet;
	packet.time_usec = time_usec;
	packet.lat = lat;
	packet.lon = lon;
	packet.alt = alt;
	packet.heading = heading;
	packet.camera_pitch = camera_pitch;
	packet.relx = relx;
	packet.rely = rely;
	packet.relz = relz;
	packet.type = type;
	packet.id = id;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_KIRKWOOD_POSITION_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_KIRKWOOD_POSITION;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_KIRKWOOD_POSITION_LEN, MAVLINK_MSG_ID_KIRKWOOD_POSITION_CRC);
#else
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_KIRKWOOD_POSITION_LEN);
#endif
}

/**
 * @brief Pack a kirkwood_position message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param time_usec Timestamp (microseconds since UNIX epoch or microseconds since system boot)
 * @param type Point type. See KW_POSE_TYPE in kw_types.h *
 * @param id Additional info about the point depending on point type (i.e. waypoint number)
 * @param lat Latitude, expressed as * 1E7
 * @param lon Longitude, expressed as * 1E7
 * @param alt Altitude in meters, expressed as * 1000 (millimeters), above MSL
 * @param heading Compass heading -180 to 180 in degrees
 * @param camera_pitch Camera pitch -180 to 180 in degrees
 * @param relx Relative position, rate, distance depending on type in meters or m/s in NED so x == N
 * @param rely Relative position, rate, distance depending on type in meters or m/s in NED so y == E
 * @param relz Relative position, rate, distance depending on type in meters or m/s in NED so z == D
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_kirkwood_position_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
							   mavlink_message_t* msg,
						           uint64_t time_usec,uint16_t type,uint16_t id,int32_t lat,int32_t lon,int32_t alt,float heading,float camera_pitch,float relx,float rely,float relz)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_POSITION_LEN];
	_mav_put_uint64_t(buf, 0, time_usec);
	_mav_put_int32_t(buf, 8, lat);
	_mav_put_int32_t(buf, 12, lon);
	_mav_put_int32_t(buf, 16, alt);
	_mav_put_float(buf, 20, heading);
	_mav_put_float(buf, 24, camera_pitch);
	_mav_put_float(buf, 28, relx);
	_mav_put_float(buf, 32, rely);
	_mav_put_float(buf, 36, relz);
	_mav_put_uint16_t(buf, 40, type);
	_mav_put_uint16_t(buf, 42, id);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_KIRKWOOD_POSITION_LEN);
#else
	mavlink_kirkwood_position_t packet;
	packet.time_usec = time_usec;
	packet.lat = lat;
	packet.lon = lon;
	packet.alt = alt;
	packet.heading = heading;
	packet.camera_pitch = camera_pitch;
	packet.relx = relx;
	packet.rely = rely;
	packet.relz = relz;
	packet.type = type;
	packet.id = id;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_KIRKWOOD_POSITION_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_KIRKWOOD_POSITION;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_KIRKWOOD_POSITION_LEN, MAVLINK_MSG_ID_KIRKWOOD_POSITION_CRC);
#else
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_KIRKWOOD_POSITION_LEN);
#endif
}

/**
 * @brief Encode a kirkwood_position struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param kirkwood_position C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_kirkwood_position_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_kirkwood_position_t* kirkwood_position)
{
	return mavlink_msg_kirkwood_position_pack(system_id, component_id, msg, kirkwood_position->time_usec, kirkwood_position->type, kirkwood_position->id, kirkwood_position->lat, kirkwood_position->lon, kirkwood_position->alt, kirkwood_position->heading, kirkwood_position->camera_pitch, kirkwood_position->relx, kirkwood_position->rely, kirkwood_position->relz);
}

/**
 * @brief Encode a kirkwood_position struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param kirkwood_position C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_kirkwood_position_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_kirkwood_position_t* kirkwood_position)
{
	return mavlink_msg_kirkwood_position_pack_chan(system_id, component_id, chan, msg, kirkwood_position->time_usec, kirkwood_position->type, kirkwood_position->id, kirkwood_position->lat, kirkwood_position->lon, kirkwood_position->alt, kirkwood_position->heading, kirkwood_position->camera_pitch, kirkwood_position->relx, kirkwood_position->rely, kirkwood_position->relz);
}

/**
 * @brief Send a kirkwood_position message
 * @param chan MAVLink channel to send the message
 *
 * @param time_usec Timestamp (microseconds since UNIX epoch or microseconds since system boot)
 * @param type Point type. See KW_POSE_TYPE in kw_types.h *
 * @param id Additional info about the point depending on point type (i.e. waypoint number)
 * @param lat Latitude, expressed as * 1E7
 * @param lon Longitude, expressed as * 1E7
 * @param alt Altitude in meters, expressed as * 1000 (millimeters), above MSL
 * @param heading Compass heading -180 to 180 in degrees
 * @param camera_pitch Camera pitch -180 to 180 in degrees
 * @param relx Relative position, rate, distance depending on type in meters or m/s in NED so x == N
 * @param rely Relative position, rate, distance depending on type in meters or m/s in NED so y == E
 * @param relz Relative position, rate, distance depending on type in meters or m/s in NED so z == D
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_kirkwood_position_send(mavlink_channel_t chan, uint64_t time_usec, uint16_t type, uint16_t id, int32_t lat, int32_t lon, int32_t alt, float heading, float camera_pitch, float relx, float rely, float relz)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_POSITION_LEN];
	_mav_put_uint64_t(buf, 0, time_usec);
	_mav_put_int32_t(buf, 8, lat);
	_mav_put_int32_t(buf, 12, lon);
	_mav_put_int32_t(buf, 16, alt);
	_mav_put_float(buf, 20, heading);
	_mav_put_float(buf, 24, camera_pitch);
	_mav_put_float(buf, 28, relx);
	_mav_put_float(buf, 32, rely);
	_mav_put_float(buf, 36, relz);
	_mav_put_uint16_t(buf, 40, type);
	_mav_put_uint16_t(buf, 42, id);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_POSITION, buf, MAVLINK_MSG_ID_KIRKWOOD_POSITION_LEN, MAVLINK_MSG_ID_KIRKWOOD_POSITION_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_POSITION, buf, MAVLINK_MSG_ID_KIRKWOOD_POSITION_LEN);
#endif
#else
	mavlink_kirkwood_position_t packet;
	packet.time_usec = time_usec;
	packet.lat = lat;
	packet.lon = lon;
	packet.alt = alt;
	packet.heading = heading;
	packet.camera_pitch = camera_pitch;
	packet.relx = relx;
	packet.rely = rely;
	packet.relz = relz;
	packet.type = type;
	packet.id = id;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_POSITION, (const char *)&packet, MAVLINK_MSG_ID_KIRKWOOD_POSITION_LEN, MAVLINK_MSG_ID_KIRKWOOD_POSITION_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_POSITION, (const char *)&packet, MAVLINK_MSG_ID_KIRKWOOD_POSITION_LEN);
#endif
#endif
}

#if MAVLINK_MSG_ID_KIRKWOOD_POSITION_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_kirkwood_position_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint64_t time_usec, uint16_t type, uint16_t id, int32_t lat, int32_t lon, int32_t alt, float heading, float camera_pitch, float relx, float rely, float relz)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char *buf = (char *)msgbuf;
	_mav_put_uint64_t(buf, 0, time_usec);
	_mav_put_int32_t(buf, 8, lat);
	_mav_put_int32_t(buf, 12, lon);
	_mav_put_int32_t(buf, 16, alt);
	_mav_put_float(buf, 20, heading);
	_mav_put_float(buf, 24, camera_pitch);
	_mav_put_float(buf, 28, relx);
	_mav_put_float(buf, 32, rely);
	_mav_put_float(buf, 36, relz);
	_mav_put_uint16_t(buf, 40, type);
	_mav_put_uint16_t(buf, 42, id);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_POSITION, buf, MAVLINK_MSG_ID_KIRKWOOD_POSITION_LEN, MAVLINK_MSG_ID_KIRKWOOD_POSITION_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_POSITION, buf, MAVLINK_MSG_ID_KIRKWOOD_POSITION_LEN);
#endif
#else
	mavlink_kirkwood_position_t *packet = (mavlink_kirkwood_position_t *)msgbuf;
	packet->time_usec = time_usec;
	packet->lat = lat;
	packet->lon = lon;
	packet->alt = alt;
	packet->heading = heading;
	packet->camera_pitch = camera_pitch;
	packet->relx = relx;
	packet->rely = rely;
	packet->relz = relz;
	packet->type = type;
	packet->id = id;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_POSITION, (const char *)packet, MAVLINK_MSG_ID_KIRKWOOD_POSITION_LEN, MAVLINK_MSG_ID_KIRKWOOD_POSITION_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_POSITION, (const char *)packet, MAVLINK_MSG_ID_KIRKWOOD_POSITION_LEN);
#endif
#endif
}
#endif

#endif

// MESSAGE KIRKWOOD_POSITION UNPACKING


/**
 * @brief Get field time_usec from kirkwood_position message
 *
 * @return Timestamp (microseconds since UNIX epoch or microseconds since system boot)
 */
static inline uint64_t mavlink_msg_kirkwood_position_get_time_usec(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint64_t(msg,  0);
#else
	return mav_get_uint64_t_c2000(&(msg->payload64[0]),  0);
#endif
}

/**
 * @brief Get field type from kirkwood_position message
 *
 * @return Point type. See KW_POSE_TYPE in kw_types.h *
 */
static inline uint16_t mavlink_msg_kirkwood_position_get_type(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint16_t(msg,  40);
#else
	return mav_get_uint16_t_c2000(&(msg->payload64[0]),  40);
#endif
}

/**
 * @brief Get field id from kirkwood_position message
 *
 * @return Additional info about the point depending on point type (i.e. waypoint number)
 */
static inline uint16_t mavlink_msg_kirkwood_position_get_id(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint16_t(msg,  42);
#else
	return mav_get_uint16_t_c2000(&(msg->payload64[0]),  42);
#endif
}

/**
 * @brief Get field lat from kirkwood_position message
 *
 * @return Latitude, expressed as * 1E7
 */
static inline int32_t mavlink_msg_kirkwood_position_get_lat(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_int32_t(msg,  8);
#else
	return mav_get_int32_t_c2000(&(msg->payload64[0]),  8);
#endif
}

/**
 * @brief Get field lon from kirkwood_position message
 *
 * @return Longitude, expressed as * 1E7
 */
static inline int32_t mavlink_msg_kirkwood_position_get_lon(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_int32_t(msg,  12);
#else
	return mav_get_int32_t_c2000(&(msg->payload64[0]),  12);
#endif
}

/**
 * @brief Get field alt from kirkwood_position message
 *
 * @return Altitude in meters, expressed as * 1000 (millimeters), above MSL
 */
static inline int32_t mavlink_msg_kirkwood_position_get_alt(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_int32_t(msg,  16);
#else
	return mav_get_int32_t_c2000(&(msg->payload64[0]),  16);
#endif
}

/**
 * @brief Get field heading from kirkwood_position message
 *
 * @return Compass heading -180 to 180 in degrees
 */
static inline float mavlink_msg_kirkwood_position_get_heading(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  20);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  20);
#endif
}

/**
 * @brief Get field camera_pitch from kirkwood_position message
 *
 * @return Camera pitch -180 to 180 in degrees
 */
static inline float mavlink_msg_kirkwood_position_get_camera_pitch(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  24);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  24);
#endif
}

/**
 * @brief Get field relx from kirkwood_position message
 *
 * @return Relative position, rate, distance depending on type in meters or m/s in NED so x == N
 */
static inline float mavlink_msg_kirkwood_position_get_relx(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  28);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  28);
#endif
}

/**
 * @brief Get field rely from kirkwood_position message
 *
 * @return Relative position, rate, distance depending on type in meters or m/s in NED so y == E
 */
static inline float mavlink_msg_kirkwood_position_get_rely(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  32);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  32);
#endif
}

/**
 * @brief Get field relz from kirkwood_position message
 *
 * @return Relative position, rate, distance depending on type in meters or m/s in NED so z == D
 */
static inline float mavlink_msg_kirkwood_position_get_relz(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  36);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  36);
#endif
}

/**
 * @brief Decode a kirkwood_position message into a struct
 *
 * @param msg The message to decode
 * @param kirkwood_position C-struct to decode the message contents into
 */
static inline void mavlink_msg_kirkwood_position_decode(const mavlink_message_t* msg, mavlink_kirkwood_position_t* kirkwood_position)
{
#if MAVLINK_NEED_BYTE_SWAP || MAVLINK_C2000
	kirkwood_position->time_usec = mavlink_msg_kirkwood_position_get_time_usec(msg);
	kirkwood_position->lat = mavlink_msg_kirkwood_position_get_lat(msg);
	kirkwood_position->lon = mavlink_msg_kirkwood_position_get_lon(msg);
	kirkwood_position->alt = mavlink_msg_kirkwood_position_get_alt(msg);
	kirkwood_position->heading = mavlink_msg_kirkwood_position_get_heading(msg);
	kirkwood_position->camera_pitch = mavlink_msg_kirkwood_position_get_camera_pitch(msg);
	kirkwood_position->relx = mavlink_msg_kirkwood_position_get_relx(msg);
	kirkwood_position->rely = mavlink_msg_kirkwood_position_get_rely(msg);
	kirkwood_position->relz = mavlink_msg_kirkwood_position_get_relz(msg);
	kirkwood_position->type = mavlink_msg_kirkwood_position_get_type(msg);
	kirkwood_position->id = mavlink_msg_kirkwood_position_get_id(msg);
#else
	memcpy(kirkwood_position, _MAV_PAYLOAD(msg), MAVLINK_MSG_ID_KIRKWOOD_POSITION_LEN);
#endif
}
