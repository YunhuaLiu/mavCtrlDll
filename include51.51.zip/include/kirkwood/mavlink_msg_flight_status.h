// MESSAGE FLIGHT_STATUS PACKING

#if MAVLINK_C2000
#include "../protocol_c2000.h"
#endif

#define MAVLINK_MSG_ID_FLIGHT_STATUS 184

typedef struct __mavlink_flight_status_t
{
 uint32_t flight_mode; /*< flight mode*/
 uint32_t flight_mode_state; /*< flight mode state*/
 uint32_t flight_control_mode; /*< flight control mode*/
 uint8_t armed; /*< armed state*/
 uint8_t preflight_check_passed; /*< status of pre flight check*/
} mavlink_flight_status_t;

#define MAVLINK_MSG_ID_FLIGHT_STATUS_LEN 14
#define MAVLINK_MSG_ID_184_LEN 14

#define MAVLINK_MSG_ID_FLIGHT_STATUS_CRC 159
#define MAVLINK_MSG_ID_184_CRC 159



#define MAVLINK_MESSAGE_INFO_FLIGHT_STATUS { \
	"FLIGHT_STATUS", \
	5, \
	{  { "flight_mode", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_flight_status_t, flight_mode) }, \
         { "flight_mode_state", NULL, MAVLINK_TYPE_UINT32_T, 0, 4, offsetof(mavlink_flight_status_t, flight_mode_state) }, \
         { "flight_control_mode", NULL, MAVLINK_TYPE_UINT32_T, 0, 8, offsetof(mavlink_flight_status_t, flight_control_mode) }, \
         { "armed", NULL, MAVLINK_TYPE_UINT8_T, 0, 12, offsetof(mavlink_flight_status_t, armed) }, \
         { "preflight_check_passed", NULL, MAVLINK_TYPE_UINT8_T, 0, 13, offsetof(mavlink_flight_status_t, preflight_check_passed) }, \
         } \
}


/**
 * @brief Pack a flight_status message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param flight_mode flight mode
 * @param flight_mode_state flight mode state
 * @param flight_control_mode flight control mode
 * @param armed armed state
 * @param preflight_check_passed status of pre flight check
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_flight_status_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
						       uint32_t flight_mode, uint32_t flight_mode_state, uint32_t flight_control_mode, uint8_t armed, uint8_t preflight_check_passed)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_FLIGHT_STATUS_LEN];
	_mav_put_uint32_t(buf, 0, flight_mode);
	_mav_put_uint32_t(buf, 4, flight_mode_state);
	_mav_put_uint32_t(buf, 8, flight_control_mode);
	_mav_put_uint8_t(buf, 12, armed);
	_mav_put_uint8_t(buf, 13, preflight_check_passed);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_FLIGHT_STATUS_LEN);
#elif MAVLINK_C2000
		mav_put_uint32_t_c2000(&(msg->payload64[0]), 0, flight_mode);
		mav_put_uint32_t_c2000(&(msg->payload64[0]), 4, flight_mode_state);
		mav_put_uint32_t_c2000(&(msg->payload64[0]), 8, flight_control_mode);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 12, armed);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 13, preflight_check_passed);
	
	
#else
	mavlink_flight_status_t packet;
	packet.flight_mode = flight_mode;
	packet.flight_mode_state = flight_mode_state;
	packet.flight_control_mode = flight_control_mode;
	packet.armed = armed;
	packet.preflight_check_passed = preflight_check_passed;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_FLIGHT_STATUS_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_FLIGHT_STATUS;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_FLIGHT_STATUS_LEN, MAVLINK_MSG_ID_FLIGHT_STATUS_CRC);
#else
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_FLIGHT_STATUS_LEN);
#endif
}

/**
 * @brief Pack a flight_status message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param flight_mode flight mode
 * @param flight_mode_state flight mode state
 * @param flight_control_mode flight control mode
 * @param armed armed state
 * @param preflight_check_passed status of pre flight check
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_flight_status_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
							   mavlink_message_t* msg,
						           uint32_t flight_mode,uint32_t flight_mode_state,uint32_t flight_control_mode,uint8_t armed,uint8_t preflight_check_passed)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_FLIGHT_STATUS_LEN];
	_mav_put_uint32_t(buf, 0, flight_mode);
	_mav_put_uint32_t(buf, 4, flight_mode_state);
	_mav_put_uint32_t(buf, 8, flight_control_mode);
	_mav_put_uint8_t(buf, 12, armed);
	_mav_put_uint8_t(buf, 13, preflight_check_passed);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_FLIGHT_STATUS_LEN);
#else
	mavlink_flight_status_t packet;
	packet.flight_mode = flight_mode;
	packet.flight_mode_state = flight_mode_state;
	packet.flight_control_mode = flight_control_mode;
	packet.armed = armed;
	packet.preflight_check_passed = preflight_check_passed;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_FLIGHT_STATUS_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_FLIGHT_STATUS;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_FLIGHT_STATUS_LEN, MAVLINK_MSG_ID_FLIGHT_STATUS_CRC);
#else
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_FLIGHT_STATUS_LEN);
#endif
}

/**
 * @brief Encode a flight_status struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param flight_status C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_flight_status_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_flight_status_t* flight_status)
{
	return mavlink_msg_flight_status_pack(system_id, component_id, msg, flight_status->flight_mode, flight_status->flight_mode_state, flight_status->flight_control_mode, flight_status->armed, flight_status->preflight_check_passed);
}

/**
 * @brief Encode a flight_status struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param flight_status C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_flight_status_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_flight_status_t* flight_status)
{
	return mavlink_msg_flight_status_pack_chan(system_id, component_id, chan, msg, flight_status->flight_mode, flight_status->flight_mode_state, flight_status->flight_control_mode, flight_status->armed, flight_status->preflight_check_passed);
}

/**
 * @brief Send a flight_status message
 * @param chan MAVLink channel to send the message
 *
 * @param flight_mode flight mode
 * @param flight_mode_state flight mode state
 * @param flight_control_mode flight control mode
 * @param armed armed state
 * @param preflight_check_passed status of pre flight check
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_flight_status_send(mavlink_channel_t chan, uint32_t flight_mode, uint32_t flight_mode_state, uint32_t flight_control_mode, uint8_t armed, uint8_t preflight_check_passed)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_FLIGHT_STATUS_LEN];
	_mav_put_uint32_t(buf, 0, flight_mode);
	_mav_put_uint32_t(buf, 4, flight_mode_state);
	_mav_put_uint32_t(buf, 8, flight_control_mode);
	_mav_put_uint8_t(buf, 12, armed);
	_mav_put_uint8_t(buf, 13, preflight_check_passed);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FLIGHT_STATUS, buf, MAVLINK_MSG_ID_FLIGHT_STATUS_LEN, MAVLINK_MSG_ID_FLIGHT_STATUS_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FLIGHT_STATUS, buf, MAVLINK_MSG_ID_FLIGHT_STATUS_LEN);
#endif
#else
	mavlink_flight_status_t packet;
	packet.flight_mode = flight_mode;
	packet.flight_mode_state = flight_mode_state;
	packet.flight_control_mode = flight_control_mode;
	packet.armed = armed;
	packet.preflight_check_passed = preflight_check_passed;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FLIGHT_STATUS, (const char *)&packet, MAVLINK_MSG_ID_FLIGHT_STATUS_LEN, MAVLINK_MSG_ID_FLIGHT_STATUS_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FLIGHT_STATUS, (const char *)&packet, MAVLINK_MSG_ID_FLIGHT_STATUS_LEN);
#endif
#endif
}

#if MAVLINK_MSG_ID_FLIGHT_STATUS_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_flight_status_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint32_t flight_mode, uint32_t flight_mode_state, uint32_t flight_control_mode, uint8_t armed, uint8_t preflight_check_passed)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char *buf = (char *)msgbuf;
	_mav_put_uint32_t(buf, 0, flight_mode);
	_mav_put_uint32_t(buf, 4, flight_mode_state);
	_mav_put_uint32_t(buf, 8, flight_control_mode);
	_mav_put_uint8_t(buf, 12, armed);
	_mav_put_uint8_t(buf, 13, preflight_check_passed);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FLIGHT_STATUS, buf, MAVLINK_MSG_ID_FLIGHT_STATUS_LEN, MAVLINK_MSG_ID_FLIGHT_STATUS_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FLIGHT_STATUS, buf, MAVLINK_MSG_ID_FLIGHT_STATUS_LEN);
#endif
#else
	mavlink_flight_status_t *packet = (mavlink_flight_status_t *)msgbuf;
	packet->flight_mode = flight_mode;
	packet->flight_mode_state = flight_mode_state;
	packet->flight_control_mode = flight_control_mode;
	packet->armed = armed;
	packet->preflight_check_passed = preflight_check_passed;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FLIGHT_STATUS, (const char *)packet, MAVLINK_MSG_ID_FLIGHT_STATUS_LEN, MAVLINK_MSG_ID_FLIGHT_STATUS_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FLIGHT_STATUS, (const char *)packet, MAVLINK_MSG_ID_FLIGHT_STATUS_LEN);
#endif
#endif
}
#endif

#endif

// MESSAGE FLIGHT_STATUS UNPACKING


/**
 * @brief Get field flight_mode from flight_status message
 *
 * @return flight mode
 */
static inline uint32_t mavlink_msg_flight_status_get_flight_mode(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint32_t(msg,  0);
#else
	return mav_get_uint32_t_c2000(&(msg->payload64[0]),  0);
#endif
}

/**
 * @brief Get field flight_mode_state from flight_status message
 *
 * @return flight mode state
 */
static inline uint32_t mavlink_msg_flight_status_get_flight_mode_state(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint32_t(msg,  4);
#else
	return mav_get_uint32_t_c2000(&(msg->payload64[0]),  4);
#endif
}

/**
 * @brief Get field flight_control_mode from flight_status message
 *
 * @return flight control mode
 */
static inline uint32_t mavlink_msg_flight_status_get_flight_control_mode(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint32_t(msg,  8);
#else
	return mav_get_uint32_t_c2000(&(msg->payload64[0]),  8);
#endif
}

/**
 * @brief Get field armed from flight_status message
 *
 * @return armed state
 */
static inline uint8_t mavlink_msg_flight_status_get_armed(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  12);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  12);
#endif
}

/**
 * @brief Get field preflight_check_passed from flight_status message
 *
 * @return status of pre flight check
 */
static inline uint8_t mavlink_msg_flight_status_get_preflight_check_passed(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  13);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  13);
#endif
}

/**
 * @brief Decode a flight_status message into a struct
 *
 * @param msg The message to decode
 * @param flight_status C-struct to decode the message contents into
 */
static inline void mavlink_msg_flight_status_decode(const mavlink_message_t* msg, mavlink_flight_status_t* flight_status)
{
#if MAVLINK_NEED_BYTE_SWAP || MAVLINK_C2000
	flight_status->flight_mode = mavlink_msg_flight_status_get_flight_mode(msg);
	flight_status->flight_mode_state = mavlink_msg_flight_status_get_flight_mode_state(msg);
	flight_status->flight_control_mode = mavlink_msg_flight_status_get_flight_control_mode(msg);
	flight_status->armed = mavlink_msg_flight_status_get_armed(msg);
	flight_status->preflight_check_passed = mavlink_msg_flight_status_get_preflight_check_passed(msg);
#else
	memcpy(flight_status, _MAV_PAYLOAD(msg), MAVLINK_MSG_ID_FLIGHT_STATUS_LEN);
#endif
}
