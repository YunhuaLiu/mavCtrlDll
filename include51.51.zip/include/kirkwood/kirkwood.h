/** @file
 *	@brief MAVLink comm protocol generated from kirkwood.xml
 *	@see http://mavlink.org
 */
#ifndef MAVLINK_KIRKWOOD_H
#define MAVLINK_KIRKWOOD_H

#ifndef MAVLINK_H
    #error Wrong include order: MAVLINK_KIRKWOOD.H MUST NOT BE DIRECTLY USED. Include mavlink.h from the same directory instead or set ALL AND EVERY defines from MAVLINK.H manually accordingly, including the #define MAVLINK_H call.
#endif

#ifdef __cplusplus
extern "C" {
#endif

// MESSAGE LENGTHS AND CRCS

#ifndef MAVLINK_MESSAGE_LENGTHS
#define MAVLINK_MESSAGE_LENGTHS {15, 31, 16, 0, 14, 28, 3, 32, 0, 0, 0, 6, 0, 0, 0, 0, 0, 0, 0, 0, 20, 2, 25, 23, 30, 101, 22, 26, 16, 14, 29, 32, 28, 28, 22, 22, 21, 6, 6, 37, 4, 4, 2, 2, 4, 2, 2, 3, 13, 12, 37, 0, 0, 0, 27, 25, 0, 0, 0, 0, 0, 68, 26, 185, 229, 42, 6, 4, 0, 13, 18, 0, 0, 37, 20, 35, 33, 3, 0, 0, 0, 22, 39, 49, 53, 51, 53, 51, 0, 28, 56, 42, 33, 0, 0, 0, 0, 0, 0, 0, 26, 32, 32, 20, 32, 66, 44, 72, 84, 9, 254, 16, 12, 36, 44, 64, 22, 6, 14, 12, 97, 2, 2, 113, 35, 6, 79, 35, 35, 22, 13, 255, 14, 18, 43, 8, 22, 14, 48, 43, 41, 24, 243, 0, 0, 0, 100, 36, 60, 30, 66, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12, 44, 0, 8, 65, 24, 9, 210, 32, 1, 12, 6, 252, 24, 36, 24, 40, 28, 30, 64, 0, 147, 0, 18, 14, 26, 0, 0, 0, 0, 184, 102, 24, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 32, 52, 53, 6, 1, 0, 0, 254, 36, 30, 18, 18, 51, 9, 0}
#endif

#ifndef MAVLINK_MESSAGE_CRCS
#define MAVLINK_MESSAGE_CRCS {49, 124, 200, 0, 237, 217, 104, 119, 0, 0, 0, 89, 0, 0, 0, 0, 0, 0, 0, 0, 214, 159, 220, 168, 24, 23, 170, 144, 67, 115, 177, 246, 185, 104, 237, 244, 222, 212, 9, 254, 230, 28, 28, 132, 221, 232, 11, 153, 41, 39, 78, 0, 0, 0, 15, 3, 0, 0, 0, 0, 0, 153, 183, 51, 59, 118, 148, 21, 0, 217, 124, 0, 0, 38, 20, 158, 152, 143, 0, 0, 0, 106, 49, 138, 143, 140, 5, 150, 0, 231, 183, 63, 54, 0, 0, 0, 0, 0, 0, 0, 175, 102, 158, 208, 56, 214, 138, 67, 32, 185, 84, 34, 174, 124, 237, 4, 76, 128, 56, 116, 134, 237, 203, 250, 87, 203, 220, 25, 226, 46, 29, 223, 85, 6, 229, 203, 1, 195, 115, 168, 181, 148, 72, 0, 0, 0, 103, 154, 178, 200, 210, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12, 141, 0, 113, 36, 166, 177, 191, 132, 201, 24, 232, 227, 118, 220, 109, 157, 186, 217, 104, 0, 38, 0, 182, 159, 5, 0, 0, 0, 0, 120, 245, 107, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 90, 104, 85, 95, 83, 0, 0, 8, 204, 49, 170, 44, 83, 46, 0}
#endif

#ifndef MAVLINK_MESSAGE_INFO
#define MAVLINK_MESSAGE_INFO {MAVLINK_MESSAGE_INFO_HEARTBEAT, MAVLINK_MESSAGE_INFO_SYS_STATUS, MAVLINK_MESSAGE_INFO_SYSTEM_TIME, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, MAVLINK_MESSAGE_INFO_PING, MAVLINK_MESSAGE_INFO_CHANGE_OPERATOR_CONTROL, MAVLINK_MESSAGE_INFO_CHANGE_OPERATOR_CONTROL_ACK, MAVLINK_MESSAGE_INFO_AUTH_KEY, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, MAVLINK_MESSAGE_INFO_SET_MODE, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, MAVLINK_MESSAGE_INFO_PARAM_REQUEST_READ, MAVLINK_MESSAGE_INFO_PARAM_REQUEST_LIST, MAVLINK_MESSAGE_INFO_PARAM_VALUE, MAVLINK_MESSAGE_INFO_PARAM_SET, MAVLINK_MESSAGE_INFO_GPS_RAW_INT, MAVLINK_MESSAGE_INFO_GPS_STATUS, MAVLINK_MESSAGE_INFO_SCALED_IMU, MAVLINK_MESSAGE_INFO_RAW_IMU, MAVLINK_MESSAGE_INFO_RAW_PRESSURE, MAVLINK_MESSAGE_INFO_SCALED_PRESSURE, MAVLINK_MESSAGE_INFO_ATTITUDE, MAVLINK_MESSAGE_INFO_ATTITUDE_QUATERNION, MAVLINK_MESSAGE_INFO_LOCAL_POSITION_NED, MAVLINK_MESSAGE_INFO_GLOBAL_POSITION_INT, MAVLINK_MESSAGE_INFO_RC_CHANNELS_SCALED, MAVLINK_MESSAGE_INFO_RC_CHANNELS_RAW, MAVLINK_MESSAGE_INFO_SERVO_OUTPUT_RAW, MAVLINK_MESSAGE_INFO_MISSION_REQUEST_PARTIAL_LIST, MAVLINK_MESSAGE_INFO_MISSION_WRITE_PARTIAL_LIST, MAVLINK_MESSAGE_INFO_MISSION_ITEM, MAVLINK_MESSAGE_INFO_MISSION_REQUEST, MAVLINK_MESSAGE_INFO_MISSION_SET_CURRENT, MAVLINK_MESSAGE_INFO_MISSION_CURRENT, MAVLINK_MESSAGE_INFO_MISSION_REQUEST_LIST, MAVLINK_MESSAGE_INFO_MISSION_COUNT, MAVLINK_MESSAGE_INFO_MISSION_CLEAR_ALL, MAVLINK_MESSAGE_INFO_MISSION_ITEM_REACHED, MAVLINK_MESSAGE_INFO_MISSION_ACK, MAVLINK_MESSAGE_INFO_SET_GPS_GLOBAL_ORIGIN, MAVLINK_MESSAGE_INFO_GPS_GLOBAL_ORIGIN, MAVLINK_MESSAGE_INFO_PARAM_MAP_RC, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, MAVLINK_MESSAGE_INFO_SAFETY_SET_ALLOWED_AREA, MAVLINK_MESSAGE_INFO_SAFETY_ALLOWED_AREA, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, MAVLINK_MESSAGE_INFO_ATTITUDE_QUATERNION_COV, MAVLINK_MESSAGE_INFO_NAV_CONTROLLER_OUTPUT, MAVLINK_MESSAGE_INFO_GLOBAL_POSITION_INT_COV, MAVLINK_MESSAGE_INFO_LOCAL_POSITION_NED_COV, MAVLINK_MESSAGE_INFO_RC_CHANNELS, MAVLINK_MESSAGE_INFO_REQUEST_DATA_STREAM, MAVLINK_MESSAGE_INFO_DATA_STREAM, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, MAVLINK_MESSAGE_INFO_MANUAL_CONTROL, MAVLINK_MESSAGE_INFO_RC_CHANNELS_OVERRIDE, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, MAVLINK_MESSAGE_INFO_MISSION_ITEM_INT, MAVLINK_MESSAGE_INFO_VFR_HUD, MAVLINK_MESSAGE_INFO_COMMAND_INT, MAVLINK_MESSAGE_INFO_COMMAND_LONG, MAVLINK_MESSAGE_INFO_COMMAND_ACK, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, MAVLINK_MESSAGE_INFO_MANUAL_SETPOINT, MAVLINK_MESSAGE_INFO_SET_ATTITUDE_TARGET, MAVLINK_MESSAGE_INFO_ATTITUDE_TARGET, MAVLINK_MESSAGE_INFO_SET_POSITION_TARGET_LOCAL_NED, MAVLINK_MESSAGE_INFO_POSITION_TARGET_LOCAL_NED, MAVLINK_MESSAGE_INFO_SET_POSITION_TARGET_GLOBAL_INT, MAVLINK_MESSAGE_INFO_POSITION_TARGET_GLOBAL_INT, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, MAVLINK_MESSAGE_INFO_LOCAL_POSITION_NED_SYSTEM_GLOBAL_OFFSET, MAVLINK_MESSAGE_INFO_HIL_STATE, MAVLINK_MESSAGE_INFO_HIL_CONTROLS, MAVLINK_MESSAGE_INFO_HIL_RC_INPUTS_RAW, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, MAVLINK_MESSAGE_INFO_OPTICAL_FLOW, MAVLINK_MESSAGE_INFO_GLOBAL_VISION_POSITION_ESTIMATE, MAVLINK_MESSAGE_INFO_VISION_POSITION_ESTIMATE, MAVLINK_MESSAGE_INFO_VISION_SPEED_ESTIMATE, MAVLINK_MESSAGE_INFO_VICON_POSITION_ESTIMATE, MAVLINK_MESSAGE_INFO_HIGHRES_IMU, MAVLINK_MESSAGE_INFO_OPTICAL_FLOW_RAD, MAVLINK_MESSAGE_INFO_HIL_SENSOR, MAVLINK_MESSAGE_INFO_SIM_STATE, MAVLINK_MESSAGE_INFO_RADIO_STATUS, MAVLINK_MESSAGE_INFO_FILE_TRANSFER_PROTOCOL, MAVLINK_MESSAGE_INFO_TIMESYNC, MAVLINK_MESSAGE_INFO_CAMERA_TRIGGER, MAVLINK_MESSAGE_INFO_HIL_GPS, MAVLINK_MESSAGE_INFO_HIL_OPTICAL_FLOW, MAVLINK_MESSAGE_INFO_HIL_STATE_QUATERNION, MAVLINK_MESSAGE_INFO_SCALED_IMU2, MAVLINK_MESSAGE_INFO_LOG_REQUEST_LIST, MAVLINK_MESSAGE_INFO_LOG_ENTRY, MAVLINK_MESSAGE_INFO_LOG_REQUEST_DATA, MAVLINK_MESSAGE_INFO_LOG_DATA, MAVLINK_MESSAGE_INFO_LOG_ERASE, MAVLINK_MESSAGE_INFO_LOG_REQUEST_END, MAVLINK_MESSAGE_INFO_GPS_INJECT_DATA, MAVLINK_MESSAGE_INFO_GPS2_RAW, MAVLINK_MESSAGE_INFO_POWER_STATUS, MAVLINK_MESSAGE_INFO_SERIAL_CONTROL, MAVLINK_MESSAGE_INFO_GPS_RTK, MAVLINK_MESSAGE_INFO_GPS2_RTK, MAVLINK_MESSAGE_INFO_SCALED_IMU3, MAVLINK_MESSAGE_INFO_DATA_TRANSMISSION_HANDSHAKE, MAVLINK_MESSAGE_INFO_ENCAPSULATED_DATA, MAVLINK_MESSAGE_INFO_DISTANCE_SENSOR, MAVLINK_MESSAGE_INFO_TERRAIN_REQUEST, MAVLINK_MESSAGE_INFO_TERRAIN_DATA, MAVLINK_MESSAGE_INFO_TERRAIN_CHECK, MAVLINK_MESSAGE_INFO_TERRAIN_REPORT, MAVLINK_MESSAGE_INFO_SCALED_PRESSURE2, MAVLINK_MESSAGE_INFO_ATT_POS_MOCAP, MAVLINK_MESSAGE_INFO_SET_ACTUATOR_CONTROL_TARGET, MAVLINK_MESSAGE_INFO_ACTUATOR_CONTROL_TARGET, MAVLINK_MESSAGE_INFO_ALTITUDE, MAVLINK_MESSAGE_INFO_RESOURCE_REQUEST, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, MAVLINK_MESSAGE_INFO_CONTROL_SYSTEM_STATE, MAVLINK_MESSAGE_INFO_BATTERY_STATUS, MAVLINK_MESSAGE_INFO_AUTOPILOT_VERSION, MAVLINK_MESSAGE_INFO_LANDING_TARGET, MAVLINK_MESSAGE_INFO_HIGHRES_IMU1, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, MAVLINK_MESSAGE_INFO_KIRKWOOD_EVENT, MAVLINK_MESSAGE_INFO_KIRKWOOD_POSITION, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, MAVLINK_MESSAGE_INFO_KIRKWOOD_MANEUVER_STATUS, MAVLINK_MESSAGE_INFO_KIRKWOOD_ESC_STATUS, MAVLINK_MESSAGE_INFO_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT, MAVLINK_MESSAGE_INFO_KIRKWOOD_SDLOG_CLIENT_HS, MAVLINK_MESSAGE_INFO_KIRKWOOD_SDLOG_SERVER_HS, MAVLINK_MESSAGE_INFO_KIRKWOOD_BATTERY_STATUS, MAVLINK_MESSAGE_INFO_KIRKWOOD_NFZ_CMD, MAVLINK_MESSAGE_INFO_BOOTLOADER_HANDSHAKE, MAVLINK_MESSAGE_INFO_BOOTLOADER_CMD, MAVLINK_MESSAGE_INFO_BOOTLOADER_DATA, MAVLINK_MESSAGE_INFO_KIRKWOOD_RAW_MAG, MAVLINK_MESSAGE_INFO_KIRKWOOD_RAW_ACC, MAVLINK_MESSAGE_INFO_COYOTE_STATUS, MAVLINK_MESSAGE_INFO_COYOTE_SENSE, MAVLINK_MESSAGE_INFO_COYOTE_PROBE, MAVLINK_MESSAGE_INFO_COYOTE_DEBUG, MAVLINK_MESSAGE_INFO_COYOTE_CAL_PARAMS, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, MAVLINK_MESSAGE_INFO_KIRKWOOD_TEST, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, MAVLINK_MESSAGE_INFO_KIRKWOOD_SYSTEM_HEALTH, MAVLINK_MESSAGE_INFO_FLIGHT_STATUS, MAVLINK_MESSAGE_INFO_KIRKWOOD_CALIB_RESULT, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, MAVLINK_MESSAGE_INFO_EKF_STATE, MAVLINK_MESSAGE_INFO_EKF_INNOV, MAVLINK_MESSAGE_INFO_BARO2, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, MAVLINK_MESSAGE_INFO_VIBRATION, MAVLINK_MESSAGE_INFO_HOME_POSITION, MAVLINK_MESSAGE_INFO_SET_HOME_POSITION, MAVLINK_MESSAGE_INFO_MESSAGE_INTERVAL, MAVLINK_MESSAGE_INFO_VTOL_STATE, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}, MAVLINK_MESSAGE_INFO_V2_EXTENSION, MAVLINK_MESSAGE_INFO_MEMORY_VECT, MAVLINK_MESSAGE_INFO_DEBUG_VECT, MAVLINK_MESSAGE_INFO_NAMED_VALUE_FLOAT, MAVLINK_MESSAGE_INFO_NAMED_VALUE_INT, MAVLINK_MESSAGE_INFO_STATUSTEXT, MAVLINK_MESSAGE_INFO_DEBUG, {"EMPTY",0,{{"","",MAVLINK_TYPE_CHAR,0,0,0}}}}
#endif

#include "../protocol.h"

#define MAVLINK_ENABLED_KIRKWOOD

// ENUM DEFINITIONS


/** @brief  */
#ifndef HAVE_ENUM_KIRKWOOD_CMD
#define HAVE_ENUM_KIRKWOOD_CMD
typedef enum KIRKWOOD_CMD
{
	KIRKWOOD_CMD_PAIR_START=20001, /* Sent by GPX to indicate that the user requested to pairing | */
	KIRKWOOD_CMD_PAIR_ACCEPT=20002, /* Sent by GPX to indicate that the user has accepted the pairing | */
	KIRKWOOD_CMD_PAIR_READY=20003, /* Sent by the VEnc to indicate that the pairing is ready. | */
	KIRKWOOD_CMD_PAIR_DONE=20004, /* Sent by the VEnc to indicate that the pairing process is complete. | */
	KIRKWOOD_CMD_NFZ_QUERY=20010, /* Sent by the VEnc to query whether NFZs have been loaded | */
	KIRKWOOD_CMD_NFZ_START_UPLOAD=20011, /* Sent by the VEnc to indicate an NFZ upload is beginning |Integer. Number of cylinders to be uploaded| Integer. Number of polygons to be uploaded|  */
	KIRKWOOD_CMD_NFZ_CYLINDER=20012, /* Sent by the VEnc to carry a cylindrical NFZ |Integer. ID. Ordered. Starting at 1. 0 is invalid| Integer. Latitude, expressed as * 1E7| Integer. Longitude, expressed as * 1E7| Float. Radius in m| Float. Warning radius in m|  */
	KIRKWOOD_CMD_NFZ_POLYGON_START=20013, /* Sent by the VEnc to indicate the beginning of a polygon transmission |Integer. ID. Ordered. Starting at 1. 0 is invalid| Integer. Number of points in polygon| Float. Warning distance in m|  */
	KIRKWOOD_CMD_NFZ_POLYGON_POINT=20014, /* Sent by the VEnc to carry a single point of a polygon |Integer. ID. Ordered. Starting at 1. 0 is invalid| Integer. Latitude, expressed as * 1E7| Integer. Longitude, expressed as * 1E7|  */
	KIRKWOOD_CMD_GEOFENCE_SET_MAX_ALTITUDE=20015, /* Sent by the VEnc to set maximum altitude for current flight |Float. Altitude in m|  */
	KIRKWOOD_CMD_GEOFENCE_SET_MAX_RADIUS=20016, /* Sent by the VEnc to set maximum distance (as radius) for current flight |Float. Radius in m|  */
	KIRKWOOD_CMD_GEOFENCE_UPDATE_REF_POS=20017, /* Sent by the VEnc to update the Geofence reference point based on current buckhorn position |Integer. Update Geofence flag. Non zero if updated|  */
	KIRKWOOD_CMD_ARM_WITHOUT_GPS=20020, /* Controls if GPX should arm without GPS signal. Arm command will be issued again separately |Integer. 0==no, 1==yes|  */
	KIRKWOOD_CMD_LED=20021, /* Controls if front LED is on or off |Integer. Front on off| Integer. Rear on off| Integer. High power front| Integer. High power rear|  */
	KIRKWOOD_CMD_START_SHUTDOWN=20022, /* Flight controller sends to video encoder after power button press | */
	KIRKWOOD_CMD_READY_TO_SHUTDOWN=20023, /* Video encoder sends back to flight controller when ready to shutdown | */
	KIRKWOOD_CMD_SET_FLIGHT_MODE=20024, /* Sent by Video encoder to set flight controller mode  |Integer. flight mode, see KIRKWOOD_FLIGHT_MODES|  */
	KIRKWOOD_CMD_SET_EASY_MODE=20025, /* Sent by Video encoder to set flight controller mode  |Integer. 0/1 easy mode enable|  */
	KIRKWOOD_CMD_UPDATE_START=20030, /* Video encoder sends to flight controller when ready to FW update | */
	KIRKWOOD_CMD_UPDATE_COMPLETE=20031, /* Video encoder sends to flight controller when FW update complete  | */
	KIRKWOOD_CMD_SCRIPTED_MANEUVER=20040, /* Tells GPX to listen for KIRKWOOD_SCRIPTED_MANEUVER message |Integer. see KW_MANEUVER in kw_types.h*| Integer. see KW_MANEUVER_CMD in kw_types.h*| Integer. speed 0 - 1000 [0 - default, 1 - slowest, 1000 - fastest]| Integer. see KW_MANEUVER_TRIGGER_TYPE in kw_types.h*|  */
	KIRKWOOD_CMD_TELEMETRY_ENABLE=20045, /* Controls if GPX should be streaming telemetry or not over mavlink |Integer. 0==no, 1==yes|  */
	KIRKWOOD_CMD_GP_CAL=20050, /* Tells GPX to start device calibration |Integer. 0==NONE, 1==GYRO, 2==MAG, 3==RES, 4==RC, 5==ACCEL, 6==GP_MAG, 7==GP_ACCEL| Integer. 0==STOP, 1==START, 2==CANCEL| Integer. Auxiliary parameter based on param1|  */
	KIRKWOOD_CMD_CAL_PROGRESS=20051, /* Sent to Video Encoder during Calibration process |Integer. 0==NONE, 1==GYRO, 2==MAG, 3==RES, 4==RC, 5==ACCEL, 6==GP_MAG, 7==GP_ACCEL| Integer. 0==STOPPED 1==WAITING 2==COLLECTING 3==CANCEL 4=SUCCESS 5=FAIL| Float. %age of completion for raw data collection| Integer. Axis Z=0 X=1 Y=1 |  */
	KIRKWOOD_CMD_RTH_MODE=20055, /* Sent by video encoder to set the RTH mode |Integer. see KW_RTH_MODE in kw_types.h|  */
	KIRKWOOD_CMD_RTH_ALTITUDE=20056, /* Sent by video encoder to set the return altitude in RTH |Float. Altitude in meters 0: default altitude|  */
	KIRKWOOD_CMD_COYOTE_CONTROL=20070, /* Sent by coyote interface to set who is currently controlling coyote |Integer. 0 kw_cmdr, 1 coyote_interface|  */
	KIRKWOOD_CMD_ENUM_END=20071, /*  | */
} KIRKWOOD_CMD;
#endif

/** @brief  */
#ifndef HAVE_ENUM_KIRKWOOD_FLIGHT_MODES
#define HAVE_ENUM_KIRKWOOD_FLIGHT_MODES
typedef enum KIRKWOOD_FLIGHT_MODES
{
	KIRKWOOD_FLIGHT_MODE_MANUAL=0, /* Manual mode | */
	KIRKWOOD_FLIGHT_MODE_STANDARD=2, /* Position hold, Standard mode | */
	KIRKWOOD_FLIGHT_MODE_SPORT=3, /* position hold, Sport mode | */
	KIRKWOOD_FLIGHT_MODE_CIRCLE=4, /* Circle maneuver (CW) | */
	KIRKWOOD_FLIGHT_MODE_REVERSE_CIRCLE=5, /* Reverse circle maneuver (CCW)  | */
	KIRKWOOD_FLIGHT_MODE_DRONIE=6, /* Dronie | */
	KIRKWOOD_FLIGHT_MODE_HORIZON_REVEAL=7, /* Horizon reveal | */
	KIRKWOOD_FLIGHT_MODE_DOLLY=8, /* Dolly | */
	KIRKWOOD_FLIGHT_MODE_MONEY=9, /* Money | */
	KIRKWOOD_FLIGHT_MODE_FACE=10, /* Face the user | */
	KIRKWOOD_FLIGHT_MODE_RTH=11, /* Return to Home mode | */
	KIRKWOOD_FLIGHT_MODE_TAKEOFF=12, /* Auto takeoff | */
	KIRKWOOD_FLIGHT_MODE_LAND=13, /* Auto land | */
	KIRKWOOD_FLIGHT_MODE_DEBUG1=14, /* DEBUG1 based on RC_MODE_SW* | */
	KIRKWOOD_FLIGHT_MODE_DEBUG2=15, /* DEBUG2 based on RC_MODE_SW* | */
	KIRKWOOD_FLIGHT_MODE_DEBUG3=16, /* DEBUG3 based on RC_MODE_SW* | */
	KIRKWOOD_FLIGHT_MODES_ENUM_END=17, /*  | */
} KIRKWOOD_FLIGHT_MODES;
#endif

/** @brief  */
#ifndef HAVE_ENUM_KIRKWOOD_ESC_ID
#define HAVE_ENUM_KIRKWOOD_ESC_ID
typedef enum KIRKWOOD_ESC_ID
{
	KIRKWOOD_ESC_ID_FL=0, /* Front left motor | */
	KIRKWOOD_ESC_ID_FR=1, /* Front right motor | */
	KIRKWOOD_ESC_ID_RR=2, /* Rear right motor | */
	KIRKWOOD_ESC_ID_RL=3, /* Rear left motor | */
	KIRKWOOD_ESC_ID_ENUM_END=4, /*  | */
} KIRKWOOD_ESC_ID;
#endif

/** @brief  */
#ifndef HAVE_ENUM_KIRKWOOD_SDLOG_HS_STATUS
#define HAVE_ENUM_KIRKWOOD_SDLOG_HS_STATUS
typedef enum KIRKWOOD_SDLOG_HS_STATUS
{
	KIRKWOOD_SDLOG_HS_GET_FILE=0, /* Get files request. Will be followed by data | */
	KIRKWOOD_SDLOG_HS_GET_INTERVAL=1, /* Ack for every data packet | */
	KIRKWOOD_SDLOG_HS_GET_LIST=2, /* End of file | */
	KIRKWOOD_SDLOG_HS_IDLE=3, /* Ack end of file | */
	KIRKWOOD_SDLOG_HS_STATUS_ENUM_END=4, /*  | */
} KIRKWOOD_SDLOG_HS_STATUS;
#endif

/** @brief  */
#ifndef HAVE_ENUM_KIRKWOOD_SDLOG_SERVER_HS_OPCODE
#define HAVE_ENUM_KIRKWOOD_SDLOG_SERVER_HS_OPCODE
typedef enum KIRKWOOD_SDLOG_SERVER_HS_OPCODE
{
	KIRKWOOD_SDLOG_HS_FILE_VAL=0, /* Send a file portion | */
	KIRKWOOD_SDLOG_HS_LIST_VAL=1, /* Send a list element | */
	KIRKWOOD_SDLOG_HS_INTV_VAL=2, /* Send an interval element | */
	KIRKWOOD_SDLOG_HS_EOT_VAL=3, /* Send EOT status | */
	KIRKWOOD_SDLOG_HS_EOF_VAL=4, /* Send EOF status | */
	KIRKWOOD_SDLOG_SERVER_HS_OPCODE_ENUM_END=5, /*  | */
} KIRKWOOD_SDLOG_SERVER_HS_OPCODE;
#endif

/** @brief  */
#ifndef HAVE_ENUM_KIRKWOOD_SDLOG_CLIENT_HS_OPCODE
#define HAVE_ENUM_KIRKWOOD_SDLOG_CLIENT_HS_OPCODE
typedef enum KIRKWOOD_SDLOG_CLIENT_HS_OPCODE
{
	KIRKWOOD_SDLOG_HS_FILE_REQ=0, /* Request a file | */
	KIRKWOOD_SDLOG_HS_LIST_REQ=1, /* Request a list | */
	KIRKWOOD_SDLOG_HS_INTV_REQ=2, /* Request an interval | */
	KIRKWOOD_SDLOG_HS_NACK=3, /* Indicate that sequence is off | */
	KIRKWOOD_SDLOG_HS_EOT_ACK=4, /* Acknowledge EOT status | */
	KIRKWOOD_SDLOG_HS_EOF_ACK=5, /* Acknowledge EOF status | */
	KIRKWOOD_SDLOG_CLIENT_HS_OPCODE_ENUM_END=6, /*  | */
} KIRKWOOD_SDLOG_CLIENT_HS_OPCODE;
#endif

/** @brief  */
#ifndef HAVE_ENUM_COYOTE_CMD_ENUM
#define HAVE_ENUM_COYOTE_CMD_ENUM
typedef enum COYOTE_CMD_ENUM
{
	COYOTE_CMD_NONE=0, /* Should never happen | */
	COYOTE_CMD_POSITION_LOCK=1, /* A 'COMMAND_LONG' command. Lock or unlock the roll and/or pitch axes positions to the current stabilization position (see the 'COYOTE_CMD_POSITION_SET' command). |Non-zero if the roll axis should become locked; zero if the roll axis should become unlocked.| Non-zero if the pitch axis should become locked; zero if the pitch axis should become unlocked.|  */
	COYOTE_CMD_POSITION_RESET=2, /* A 'COMMAND_LONG' command. Reset roll, pitch, and/or yaw stabilization position; the roll, pitch, and/or yaw stabilization position will be reset if 'COMMAND_LONG' message parameters 1, 2, and/or 3, respectively, is/are non-zero. | */
	COYOTE_CMD_POSITION_SET=3, /* A 'COMMAND_LONG' command. Set the roll, pitch, and/or yaw stabilization position to the specified radian values; after execution of this command, stabilization will occur about this new roll, pitch, and yaw position. |Desired roll stabilization position in radians| Desired pitch stabilization position in radians| Desired yaw stabilization position in radians|  */
	COYOTE_CMD_RATE_SET=4, /* A 'COMMAND_LONG' command. Set roll, pitch, and/or yaw manual rate to the radian/sec value specified in the 'COMMAND_LONG' paramters 1, 2, and 3, respectively. |Desired roll manual rate in radians/sec| Desired pitch manual rate in radians/sec| Desired yaw manual rate in radians/sec|  */
	COYOTE_CMD_SET_SEN_MODE=5, /* A 'COMMAND_LONG' command. Update coyote parameters/behavior based on mode |Desired mode 0 = dafault, 1 = calibration|  */
	COYOTE_CMD_TESTMODE_SET=100, /* A 'COMMAND_LONG' command. Transition the gimbal into "test mode". |Non-zero to enable test mode; zero to disable test mode and transition to 'COYOTE_MODE_NOLOCK' with position and manual rate zeroed.|  */
	COYOTE_CMD_DATA_COLLECTION=110, /* SDLC data to be dumped to sdlog |Unused| COYOTE_CMD_DATA_COLLECTION| COYO_RAW_LOG1 bitfield| COYO_RAW_LOG2 bitfield| COYO_RAW_LOG3 bitfield| COYO_RAW_LOG4 bitfield| COYO_RAW_LOG5 bitfield|  */
	COYOTE_CMD_ENUM_ENUM_END=111, /*  | */
} COYOTE_CMD_ENUM;
#endif

/** @brief  */
#ifndef HAVE_ENUM_COYOTE_SEN_MODE_ENUM
#define HAVE_ENUM_COYOTE_SEN_MODE_ENUM
typedef enum COYOTE_SEN_MODE_ENUM
{
	COYOTE_SEN_MODE_DEFAULT=0, /* Default params | */
	COYOTE_SEN_MODE_SEN_CAL_GYRO=1, /* Params to use while sen is calibrating gyro | */
	COYOTE_SEN_MODE_SEN_CAL_ACCEL=2, /* Params to use while sen is calibrating accel | */
	COYOTE_SEN_MODE_SEN_CAL_MAG=3, /* Params to use while sen is calibrating mag | */
	COYOTE_SEN_MODE_SEN_UPDATE=4, /* Params to use while sen is updating | */
	COYOTE_SEN_MODE_ENUM_ENUM_END=5, /*  | */
} COYOTE_SEN_MODE_ENUM;
#endif

/** @brief  */
#ifndef HAVE_ENUM_COYOTE_MODE_ENUM
#define HAVE_ENUM_COYOTE_MODE_ENUM
typedef enum COYOTE_MODE_ENUM
{
	COYOTE_MODE_NONE=0, /* Should never happen | */
	COYOTE_MODE_NOLOCK=65536, /* Roll, pitch, and yaw are all being stabilized. This is the normal/default operating mode. | */
	COYOTE_MODE_PLOCK=131072, /* Roll and yaw are being stabilized while pitch is "locked" at its current position. | */
	COYOTE_MODE_RLOCK=196608, /* Pitch and yaw are being stabilized while roll is "locked" at its current position. | */
	COYOTE_MODE_RPLOCK=262144, /* Yaw is being stabilized while pitch and roll are "locked" at their current positions. | */
	COYOTE_MODE_TESTMODE=327680, /* The gimbal is in "test mode." | */
	COYOTE_MODE_ENUM_ENUM_END=327681, /*  | */
} COYOTE_MODE_ENUM;
#endif

/** @brief  */
#ifndef HAVE_ENUM_COYOTE_STATE_ENUM
#define HAVE_ENUM_COYOTE_STATE_ENUM
typedef enum COYOTE_STATE_ENUM
{
	COYOTE_STATE_NONE=0, /* Should never happen | */
	COYOTE_STATE_INITIALIZING=1, /* Initializing | */
	COYOTE_STATE_READY=2, /* Stabilizing | */
	COYOTE_STATE_BROKEN=4, /* An error has occurred, system is not usable | */
	COYOTE_STATE_NOCOMM_INNER=8, /* No communication with inner axis | */
	COYOTE_STATE_NOCOMM_MID=16, /* No communication with mid axis | */
	COYOTE_STATE_BAD_IMU=32, /* IMU failure | */
	COYOTE_STATE_BAD_ENC_OUTER=64, /* Position encoder on outer axis failed | */
	COYOTE_STATE_BAD_ENC_INNER=128, /* Position encoder on inner axis failed | */
	COYOTE_STATE_BAD_ENC_MID=256, /* Position encoder on mid axis failed | */
	COYOTE_STATE_BAD_FB_OUTER=512, /* Motor feedback on outer axis failed | */
	COYOTE_STATE_BAD_FB_INNER=1024, /* Motor feedback on inner axis failed | */
	COYOTE_STATE_BAD_FB_MID=2048, /* Motor feedback on mid axis failed | */
	COYOTE_STATE_FAULT_OUTER=4096, /* Motor driver fault on outer axis | */
	COYOTE_STATE_FAULT_INNER=8192, /* Motor driver fault on inner axis | */
	COYOTE_STATE_FAULT_MID=16384, /* Motor driver fault on mid axis | */
	COYOTE_STATE_BLOCKED_OUTER=32768, /* Outer has been blocked (max drive) for more than 3 seconds, after 3 attempts | */
	COYOTE_STATE_BLOCKED_INNER=65536, /* Inner has been blocked (max drive) for more than 3 seconds, after 3 attempts | */
	COYOTE_STATE_BLOCKED_MID=131072, /* Middle has been blocked (max drive) for more than 3 seconds, after 3 attempts | */
	COYOTE_STATE_LIMITED_OUTER=262144, /* Outer is in limited (low drive strength) mode due to thermal overload | */
	COYOTE_STATE_LIMITED_INNER=524288, /* Inner is in limited (low drive strength) mode due to thermal overload | */
	COYOTE_STATE_LIMITED_MID=1048576, /* Middle is in limited (low drive strength) mode due to thermal overload | */
	COYOTE_STATE_MOTOR_OUTER=2097152, /* Outer motor fault, short-circuit or open-circuit, check motor connector | */
	COYOTE_STATE_MOTOR_INNER=4194304, /* Inner motor fault, short-circuit or open-circuit, check motor connector | */
	COYOTE_STATE_MOTOR_MID=8388608, /* Middle motor fault, short-circuit or open-circuit, check motor connector | */
	COYOTE_STATE_UNDERVOLT_OUTER=16777216, /* Outer motor fault, short-circuit or open-circuit, check motor connector | */
	COYOTE_STATE_UNDERVOLT_INNER=33554432, /* Inner motor fault, short-circuit or open-circuit, check motor connector | */
	COYOTE_STATE_UNDERVOLT_MID=67108864, /* Middle motor fault, short-circuit or open-circuit, check motor connector | */
	COYOTE_STATE_TRIPPED_OUTER=134217728, /* Outer Motor fault tripped PWM shutdown - check power-supply max current | */
	COYOTE_STATE_TRIPPED_INNER=268435456, /* Inner Motor fault tripped PWM shutdown - check power-supply max current | */
	COYOTE_STATE_TRIPPED_MID=536870912, /* Middle Motor fault tripped PWM shutdown - check power-supply max current | */
	COYOTE_STATE_ENUM_ENUM_END=536870913, /*  | */
} COYOTE_STATE_ENUM;
#endif

/** @brief  */
#ifndef HAVE_ENUM_COYOTE_SLED_STATE_ENUM
#define HAVE_ENUM_COYOTE_SLED_STATE_ENUM
typedef enum COYOTE_SLED_STATE_ENUM
{
	COYOTE_SLED_STATE_UNKNOWN=0, /* The sled state could not be accurately identified. | */
	COYOTE_SLED_STATE_NONE=1, /* No sled is connected. | */
	COYOTE_SLED_STATE_HERO3_HERO4=2, /* A HERO3/HERO3+/HERO4 sled is connected. | */
	COYOTE_SLED_STATE_HERO5=3, /* A HERO5 sled is connected. | */
	COYOTE_SLED_STATE_H4S_NOCAM=4, /* A HERO4 Session sled is connected but no camera is present inside of it. | */
	COYOTE_SLED_STATE_H4S_WCAM=5, /* A HERO4 Session sled is connected with a camera inside of it. | */
	COYOTE_SLED_STATE_MARGARET_RIVER=6, /* A Margaret River sled is connected. | */
	COYOTE_SLED_STATE_ENUM_ENUM_END=7, /*  | */
} COYOTE_SLED_STATE_ENUM;
#endif

/** @brief  */
#ifndef HAVE_ENUM_COYOTE_CAL_ID_ENUM
#define HAVE_ENUM_COYOTE_CAL_ID_ENUM
typedef enum COYOTE_CAL_ID_ENUM
{
	COYOTE_CAL_ID_NONE=0, /* Do not use | */
	COYOTE_CAL_ID_ACCEL_TO_SLED=1, /* Accel to sled calibration values | */
	COYOTE_CAL_ID_ACCEL_TO_GYRO=2, /* Accel to gyro calibration | */
	COYOTE_CAL_ID_ENCODER_OFFSET=3, /* Zero settings for encoders | */
	COYOTE_CAL_ID_GYRO_OFFSET=4, /* Gyro biases | */
	COYOTE_CAL_ID_ACCEL_OFFSET=5, /* Accel biases | */
	COYOTE_CAL_ID_MOTOR_INNER=6, /* Inner motor misalignment | */
	COYOTE_CAL_ID_MOTOR_MIDDLE=7, /* Middle motor misalignment | */
	COYOTE_CAL_ID_MOTOR_MAIN=8, /* Main board motor misalignment | */
	COYOTE_CAL_ID_ENUM_ENUM_END=9, /*  | */
} COYOTE_CAL_ID_ENUM;
#endif

/** @brief  */
#ifndef HAVE_ENUM_ESC_SW_FAULTS
#define HAVE_ENUM_ESC_SW_FAULTS
typedef enum ESC_SW_FAULTS
{
	ESC_SW_FAULTS_RESERVED_0=0, /* Must be zero always | */
	ESC_SW_FAULTS_RESERVED_1=1, /* Must be zero always | */
	ESC_SW_FAULTS_DC_BUS_OVERVOL=2, /* DC bus overvoltage fault | */
	ESC_SW_FAULTS_DC_BUS_UNDERVOL=3, /* DC bus undervoltage fault | */
	ESC_SW_FAULTS_FLUX_PLL=4, /* Flux PLL out of control fault | */
	ESC_SW_FAULTS_ZERO_SPEED=5, /* Zero speed fault | */
	ESC_SW_FAULTS_OVERTEMP=6, /* Overtemparature fault | */
	ESC_SW_FAULTS_ROTOR_LOCK=7, /* Rotor lock fault | */
	ESC_SW_FAULTS_RESERVED_8=8, /* Must be zero always | */
	ESC_SW_FAULTS_RESERVED_9=9, /* Must be zero always | */
	ESC_SW_FAULTS_MCE_EXEC=10, /* MCE execution fault | */
	ESC_SW_FAULTS_RESERVED_11=11, /* Must be zero always | */
	ESC_SW_FAULTS_PARAMETER_LOAD=12, /* Parameter load fault | */
	ESC_SW_FAULTS_UART=13, /* UART link break fault | */
	ESC_SW_FAULTS_RESERVED_14=14, /* Must be zero always | */
	ESC_SW_FAULTS_RESERVED_15=15, /* Must be zero always | */
	ESC_SW_FAULTS_ENUM_END=16, /*  | */
} ESC_SW_FAULTS;
#endif

/** @brief  */
#ifndef HAVE_ENUM_KIRKWOOD_CMD_TEST_DEV_ID
#define HAVE_ENUM_KIRKWOOD_CMD_TEST_DEV_ID
typedef enum KIRKWOOD_CMD_TEST_DEV_ID
{
	KIRKWOOD_CMD_FC_TEST=0, /* Test command that is designated for FC. See KIRKWOOD_CMD_FC_TEST_ID | */
	KIRKWOOD_CMD_ENC_TEST=1, /* Test command that is designamted for ENC. See KIRKWOOD_CMD_ENC_TEST_ID. | */
	KIRKWOOD_CMD_COY_TEST=2, /* Test command that is designamted for Coyote. See KIRKWOOD_CMD_COY_TEST_ID. | */
	KIRKWOOD_CMD_TEST_DEV_ID_ENUM_END=3, /*  | */
} KIRKWOOD_CMD_TEST_DEV_ID;
#endif

/** @brief  */
#ifndef HAVE_ENUM_KIRKWOOD_CMD_TEST_STATUS
#define HAVE_ENUM_KIRKWOOD_CMD_TEST_STATUS
typedef enum KIRKWOOD_CMD_TEST_STATUS
{
	KIRKWOOD_CMD_TEST_STATUS_START=0, /* Signifies to run a command | */
	KIRKWOOD_CMD_TEST_STATUS_OK=1, /* Command will be run | */
	KIRKWOOD_CMD_TEST_STATUS_ERR=2, /* Command will not be run - check data for error | */
	KIRKWOOD_CMD_TEST_STATUS_PASS=3, /* Test passed | */
	KIRKWOOD_CMD_TEST_STATUS_FAIL=4, /* Test failed | */
	KIRKWOOD_CMD_TEST_STATUS_INFO=5, /* Test failed | */
	KIRKWOOD_CMD_TEST_STATUS_ENUM_END=6, /*  | */
} KIRKWOOD_CMD_TEST_STATUS;
#endif

/** @brief  */
#ifndef HAVE_ENUM_KIRKWOOD_CMD_FC_TEST_ID
#define HAVE_ENUM_KIRKWOOD_CMD_FC_TEST_ID
typedef enum KIRKWOOD_CMD_FC_TEST_ID
{
	KIRKWOOD_CMD_FC_TEST_ID_ARM_LED=0, /* Tests functionality of fc arm LEDs | */
	KIRKWOOD_CMD_FC_TEST_ID_STAT_LED=1, /* Tests functionality of fc status LEDs | */
	KIRKWOOD_CMD_FC_TEST_ID_ARM_SWITCH=2, /* Tests functionality of fc arm switches | */
	KIRKWOOD_CMD_FC_TEST_ID_LEG_SWITCH=3, /* Tests functionality of fc leg switches | */
	KIRKWOOD_CMD_FC_TEST_ID_LEG_MAG=4, /* Tests functionality of fc leg magnetometer | */
	KIRKWOOD_CMD_FC_TEST_ID_LEG_ACCEL=5, /* Tests functionality of fc leg acclerometer | */
	KIRKWOOD_CMD_FC_TEST_ID_ESC_COMM=6, /* Tests functionality of fc ESC communication | */
	KIRKWOOD_CMD_FC_TEST_ID_ESC_SPIN=7, /* Tests functionality of fc ESC drive | */
	KIRKWOOD_CMD_FC_TEST_ID_ENUM_END=8, /*  | */
} KIRKWOOD_CMD_FC_TEST_ID;
#endif

/** @brief  */
#ifndef HAVE_ENUM_KIRKWOOD_CMD_ENC_TEST_ID
#define HAVE_ENUM_KIRKWOOD_CMD_ENC_TEST_ID
typedef enum KIRKWOOD_CMD_ENC_TEST_ID
{
	KIRKWOOD_CMD_ENC_TEST_ID_HDMI=0, /* Tests functionality of encoder hdmi passthrough | */
	KIRKWOOD_CMD_ENC_TEST_ID_WIFI=1, /* Tests functionality of encoder wifi | */
	KIRKWOOD_CMD_ENC_TEST_ID_USB=2, /* Tests functionality of encoder usb passthrough | */
	KIRKWOOD_CMD_ENC_TEST_ID_SD_CARD=3, /* Tests functionality of Sentinel ESC communication | */
	KIRKWOOD_CMD_ENC_TEST_ID_ENUM_END=4, /*  | */
} KIRKWOOD_CMD_ENC_TEST_ID;
#endif

/** @brief  */
#ifndef HAVE_ENUM_KIRKWOOD_CMD_COY_TEST_ID
#define HAVE_ENUM_KIRKWOOD_CMD_COY_TEST_ID
typedef enum KIRKWOOD_CMD_COY_TEST_ID
{
	KIRKWOOD_CMD_COY_TEST_ID_PLACE_HOLDER=0, /* Best Test ever! | */
	KIRKWOOD_CMD_COY_TEST_ID_ENUM_END=1, /*  | */
} KIRKWOOD_CMD_COY_TEST_ID;
#endif

/** @brief  */
#ifndef HAVE_ENUM_KIRKWOOD_CALIB_RESULT
#define HAVE_ENUM_KIRKWOOD_CALIB_RESULT
typedef enum KIRKWOOD_CALIB_RESULT
{
	KIRKWOOD_CALIB_RESULT_SUCCESS=0, /* Best calibration ever! | */
	KIRKWOOD_CALIB_RESULT_VALIDATION_FAILED=1, /* Final validation step failed. | */
	KIRKWOOD_CALIB_RESULT_GET_DEVICE_ID_FAILED=2, /* Unable to write the params on FC side. | */
	KIRKWOOD_CALIB_RESULT_WRITE_PARAMS_FAILED=3, /* Unable to fetch device ID from sensor driver. Restart of flight controller seems to resolve this. | */
	KIRKWOOD_CALIB_RESULT_TIME_OUT=4, /* User failed to complete the calibration in time. | */
	KIRKWOOD_CALIB_RESULT_ENUM_END=5, /*  | */
} KIRKWOOD_CALIB_RESULT;
#endif

#include "../common/common.h"
#include "../bootloader/bootloader.h"
#include "../kirkwood_component_id/kirkwood_component_id.h"
#include "../kw_debug/kw_debug.h"

// MAVLINK VERSION

#ifndef MAVLINK_VERSION
#define MAVLINK_VERSION 2
#endif

#if (MAVLINK_VERSION == 0)
#undef MAVLINK_VERSION
#define MAVLINK_VERSION 2
#endif

// MESSAGE DEFINITIONS
#include "./mavlink_msg_kirkwood_event.h"
#include "./mavlink_msg_kirkwood_position.h"
#include "./mavlink_msg_kirkwood_maneuver_status.h"
#include "./mavlink_msg_kirkwood_esc_status.h"
#include "./mavlink_msg_kirkwood_vehicle_attitude_setpoint.h"
#include "./mavlink_msg_kirkwood_sdlog_client_hs.h"
#include "./mavlink_msg_kirkwood_sdlog_server_hs.h"
#include "./mavlink_msg_kirkwood_battery_status.h"
#include "./mavlink_msg_kirkwood_nfz_cmd.h"
#include "./mavlink_msg_kirkwood_raw_mag.h"
#include "./mavlink_msg_kirkwood_raw_acc.h"
#include "./mavlink_msg_coyote_status.h"
#include "./mavlink_msg_coyote_sense.h"
#include "./mavlink_msg_coyote_probe.h"
#include "./mavlink_msg_coyote_debug.h"
#include "./mavlink_msg_coyote_cal_params.h"
#include "./mavlink_msg_kirkwood_test.h"
#include "./mavlink_msg_kirkwood_system_health.h"
#include "./mavlink_msg_flight_status.h"
#include "./mavlink_msg_kirkwood_calib_result.h"

#ifdef __cplusplus
}
#endif // __cplusplus
#endif // MAVLINK_KIRKWOOD_H
