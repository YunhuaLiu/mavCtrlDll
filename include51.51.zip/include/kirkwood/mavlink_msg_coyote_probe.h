// MESSAGE COYOTE_PROBE PACKING

#if MAVLINK_C2000
#include "../protocol_c2000.h"
#endif

#define MAVLINK_MSG_ID_COYOTE_PROBE 177

typedef struct __mavlink_coyote_probe_t
{
 uint32_t time_boot_ms; /*< Timestamp (milliseconds since system boot)*/
 uint16_t rail_voltage[3]; /*< */
 int16_t temperature[3]; /*< */
 uint16_t motor_current_rms[3]; /*< since last update*/
 int16_t motor_current_peak[3]; /*< since last update*/
} mavlink_coyote_probe_t;

#define MAVLINK_MSG_ID_COYOTE_PROBE_LEN 28
#define MAVLINK_MSG_ID_177_LEN 28

#define MAVLINK_MSG_ID_COYOTE_PROBE_CRC 186
#define MAVLINK_MSG_ID_177_CRC 186

#define MAVLINK_MSG_COYOTE_PROBE_FIELD_RAIL_VOLTAGE_LEN 3
#define MAVLINK_MSG_COYOTE_PROBE_FIELD_TEMPERATURE_LEN 3
#define MAVLINK_MSG_COYOTE_PROBE_FIELD_MOTOR_CURRENT_RMS_LEN 3
#define MAVLINK_MSG_COYOTE_PROBE_FIELD_MOTOR_CURRENT_PEAK_LEN 3

#define MAVLINK_MESSAGE_INFO_COYOTE_PROBE { \
	"COYOTE_PROBE", \
	5, \
	{  { "time_boot_ms", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_coyote_probe_t, time_boot_ms) }, \
         { "rail_voltage", NULL, MAVLINK_TYPE_UINT16_T, 3, 4, offsetof(mavlink_coyote_probe_t, rail_voltage) }, \
         { "temperature", NULL, MAVLINK_TYPE_INT16_T, 3, 10, offsetof(mavlink_coyote_probe_t, temperature) }, \
         { "motor_current_rms", NULL, MAVLINK_TYPE_UINT16_T, 3, 16, offsetof(mavlink_coyote_probe_t, motor_current_rms) }, \
         { "motor_current_peak", NULL, MAVLINK_TYPE_INT16_T, 3, 22, offsetof(mavlink_coyote_probe_t, motor_current_peak) }, \
         } \
}


/**
 * @brief Pack a coyote_probe message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param time_boot_ms Timestamp (milliseconds since system boot)
 * @param rail_voltage 
 * @param temperature 
 * @param motor_current_rms since last update
 * @param motor_current_peak since last update
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_coyote_probe_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
						       uint32_t time_boot_ms, const uint16_t *rail_voltage, const int16_t *temperature, const uint16_t *motor_current_rms, const int16_t *motor_current_peak)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_COYOTE_PROBE_LEN];
	_mav_put_uint32_t(buf, 0, time_boot_ms);
	_mav_put_uint16_t_array(buf, 4, rail_voltage, 3);
	_mav_put_int16_t_array(buf, 10, temperature, 3);
	_mav_put_uint16_t_array(buf, 16, motor_current_rms, 3);
	_mav_put_int16_t_array(buf, 22, motor_current_peak, 3);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_COYOTE_PROBE_LEN);
#elif MAVLINK_C2000
		mav_put_uint32_t_c2000(&(msg->payload64[0]), 0, time_boot_ms);
	
		mav_put_uint16_t_array_c2000(&(msg->payload64[0]), rail_voltage, 4, 3);
		mav_put_int16_t_array_c2000(&(msg->payload64[0]), temperature, 10, 3);
		mav_put_uint16_t_array_c2000(&(msg->payload64[0]), motor_current_rms, 16, 3);
		mav_put_int16_t_array_c2000(&(msg->payload64[0]), motor_current_peak, 22, 3);
	
#else
	mavlink_coyote_probe_t packet;
	packet.time_boot_ms = time_boot_ms;
	mav_array_memcpy(packet.rail_voltage, rail_voltage, sizeof(uint16_t)*3);
	mav_array_memcpy(packet.temperature, temperature, sizeof(int16_t)*3);
	mav_array_memcpy(packet.motor_current_rms, motor_current_rms, sizeof(uint16_t)*3);
	mav_array_memcpy(packet.motor_current_peak, motor_current_peak, sizeof(int16_t)*3);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_COYOTE_PROBE_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_COYOTE_PROBE;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_COYOTE_PROBE_LEN, MAVLINK_MSG_ID_COYOTE_PROBE_CRC);
#else
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_COYOTE_PROBE_LEN);
#endif
}

/**
 * @brief Pack a coyote_probe message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param time_boot_ms Timestamp (milliseconds since system boot)
 * @param rail_voltage 
 * @param temperature 
 * @param motor_current_rms since last update
 * @param motor_current_peak since last update
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_coyote_probe_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
							   mavlink_message_t* msg,
						           uint32_t time_boot_ms,const uint16_t *rail_voltage,const int16_t *temperature,const uint16_t *motor_current_rms,const int16_t *motor_current_peak)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_COYOTE_PROBE_LEN];
	_mav_put_uint32_t(buf, 0, time_boot_ms);
	_mav_put_uint16_t_array(buf, 4, rail_voltage, 3);
	_mav_put_int16_t_array(buf, 10, temperature, 3);
	_mav_put_uint16_t_array(buf, 16, motor_current_rms, 3);
	_mav_put_int16_t_array(buf, 22, motor_current_peak, 3);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_COYOTE_PROBE_LEN);
#else
	mavlink_coyote_probe_t packet;
	packet.time_boot_ms = time_boot_ms;
	mav_array_memcpy(packet.rail_voltage, rail_voltage, sizeof(uint16_t)*3);
	mav_array_memcpy(packet.temperature, temperature, sizeof(int16_t)*3);
	mav_array_memcpy(packet.motor_current_rms, motor_current_rms, sizeof(uint16_t)*3);
	mav_array_memcpy(packet.motor_current_peak, motor_current_peak, sizeof(int16_t)*3);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_COYOTE_PROBE_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_COYOTE_PROBE;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_COYOTE_PROBE_LEN, MAVLINK_MSG_ID_COYOTE_PROBE_CRC);
#else
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_COYOTE_PROBE_LEN);
#endif
}

/**
 * @brief Encode a coyote_probe struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param coyote_probe C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_coyote_probe_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_coyote_probe_t* coyote_probe)
{
	return mavlink_msg_coyote_probe_pack(system_id, component_id, msg, coyote_probe->time_boot_ms, coyote_probe->rail_voltage, coyote_probe->temperature, coyote_probe->motor_current_rms, coyote_probe->motor_current_peak);
}

/**
 * @brief Encode a coyote_probe struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param coyote_probe C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_coyote_probe_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_coyote_probe_t* coyote_probe)
{
	return mavlink_msg_coyote_probe_pack_chan(system_id, component_id, chan, msg, coyote_probe->time_boot_ms, coyote_probe->rail_voltage, coyote_probe->temperature, coyote_probe->motor_current_rms, coyote_probe->motor_current_peak);
}

/**
 * @brief Send a coyote_probe message
 * @param chan MAVLink channel to send the message
 *
 * @param time_boot_ms Timestamp (milliseconds since system boot)
 * @param rail_voltage 
 * @param temperature 
 * @param motor_current_rms since last update
 * @param motor_current_peak since last update
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_coyote_probe_send(mavlink_channel_t chan, uint32_t time_boot_ms, const uint16_t *rail_voltage, const int16_t *temperature, const uint16_t *motor_current_rms, const int16_t *motor_current_peak)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_COYOTE_PROBE_LEN];
	_mav_put_uint32_t(buf, 0, time_boot_ms);
	_mav_put_uint16_t_array(buf, 4, rail_voltage, 3);
	_mav_put_int16_t_array(buf, 10, temperature, 3);
	_mav_put_uint16_t_array(buf, 16, motor_current_rms, 3);
	_mav_put_int16_t_array(buf, 22, motor_current_peak, 3);
#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_COYOTE_PROBE, buf, MAVLINK_MSG_ID_COYOTE_PROBE_LEN, MAVLINK_MSG_ID_COYOTE_PROBE_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_COYOTE_PROBE, buf, MAVLINK_MSG_ID_COYOTE_PROBE_LEN);
#endif
#else
	mavlink_coyote_probe_t packet;
	packet.time_boot_ms = time_boot_ms;
	mav_array_memcpy(packet.rail_voltage, rail_voltage, sizeof(uint16_t)*3);
	mav_array_memcpy(packet.temperature, temperature, sizeof(int16_t)*3);
	mav_array_memcpy(packet.motor_current_rms, motor_current_rms, sizeof(uint16_t)*3);
	mav_array_memcpy(packet.motor_current_peak, motor_current_peak, sizeof(int16_t)*3);
#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_COYOTE_PROBE, (const char *)&packet, MAVLINK_MSG_ID_COYOTE_PROBE_LEN, MAVLINK_MSG_ID_COYOTE_PROBE_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_COYOTE_PROBE, (const char *)&packet, MAVLINK_MSG_ID_COYOTE_PROBE_LEN);
#endif
#endif
}

#if MAVLINK_MSG_ID_COYOTE_PROBE_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_coyote_probe_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint32_t time_boot_ms, const uint16_t *rail_voltage, const int16_t *temperature, const uint16_t *motor_current_rms, const int16_t *motor_current_peak)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char *buf = (char *)msgbuf;
	_mav_put_uint32_t(buf, 0, time_boot_ms);
	_mav_put_uint16_t_array(buf, 4, rail_voltage, 3);
	_mav_put_int16_t_array(buf, 10, temperature, 3);
	_mav_put_uint16_t_array(buf, 16, motor_current_rms, 3);
	_mav_put_int16_t_array(buf, 22, motor_current_peak, 3);
#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_COYOTE_PROBE, buf, MAVLINK_MSG_ID_COYOTE_PROBE_LEN, MAVLINK_MSG_ID_COYOTE_PROBE_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_COYOTE_PROBE, buf, MAVLINK_MSG_ID_COYOTE_PROBE_LEN);
#endif
#else
	mavlink_coyote_probe_t *packet = (mavlink_coyote_probe_t *)msgbuf;
	packet->time_boot_ms = time_boot_ms;
	mav_array_memcpy(packet->rail_voltage, rail_voltage, sizeof(uint16_t)*3);
	mav_array_memcpy(packet->temperature, temperature, sizeof(int16_t)*3);
	mav_array_memcpy(packet->motor_current_rms, motor_current_rms, sizeof(uint16_t)*3);
	mav_array_memcpy(packet->motor_current_peak, motor_current_peak, sizeof(int16_t)*3);
#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_COYOTE_PROBE, (const char *)packet, MAVLINK_MSG_ID_COYOTE_PROBE_LEN, MAVLINK_MSG_ID_COYOTE_PROBE_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_COYOTE_PROBE, (const char *)packet, MAVLINK_MSG_ID_COYOTE_PROBE_LEN);
#endif
#endif
}
#endif

#endif

// MESSAGE COYOTE_PROBE UNPACKING


/**
 * @brief Get field time_boot_ms from coyote_probe message
 *
 * @return Timestamp (milliseconds since system boot)
 */
static inline uint32_t mavlink_msg_coyote_probe_get_time_boot_ms(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint32_t(msg,  0);
#else
	return mav_get_uint32_t_c2000(&(msg->payload64[0]),  0);
#endif
}

/**
 * @brief Get field rail_voltage from coyote_probe message
 *
 * @return 
 */
static inline uint16_t mavlink_msg_coyote_probe_get_rail_voltage(const mavlink_message_t* msg, uint16_t *rail_voltage)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint16_t_array(msg, rail_voltage, 3,  4);
#else
	return mav_get_uint16_t_array_c2000(&(msg->payload64[0]), rail_voltage, 3,  4);
#endif
}

/**
 * @brief Get field temperature from coyote_probe message
 *
 * @return 
 */
static inline uint16_t mavlink_msg_coyote_probe_get_temperature(const mavlink_message_t* msg, int16_t *temperature)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_int16_t_array(msg, temperature, 3,  10);
#else
	return mav_get_int16_t_array_c2000(&(msg->payload64[0]), temperature, 3,  10);
#endif
}

/**
 * @brief Get field motor_current_rms from coyote_probe message
 *
 * @return since last update
 */
static inline uint16_t mavlink_msg_coyote_probe_get_motor_current_rms(const mavlink_message_t* msg, uint16_t *motor_current_rms)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint16_t_array(msg, motor_current_rms, 3,  16);
#else
	return mav_get_uint16_t_array_c2000(&(msg->payload64[0]), motor_current_rms, 3,  16);
#endif
}

/**
 * @brief Get field motor_current_peak from coyote_probe message
 *
 * @return since last update
 */
static inline uint16_t mavlink_msg_coyote_probe_get_motor_current_peak(const mavlink_message_t* msg, int16_t *motor_current_peak)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_int16_t_array(msg, motor_current_peak, 3,  22);
#else
	return mav_get_int16_t_array_c2000(&(msg->payload64[0]), motor_current_peak, 3,  22);
#endif
}

/**
 * @brief Decode a coyote_probe message into a struct
 *
 * @param msg The message to decode
 * @param coyote_probe C-struct to decode the message contents into
 */
static inline void mavlink_msg_coyote_probe_decode(const mavlink_message_t* msg, mavlink_coyote_probe_t* coyote_probe)
{
#if MAVLINK_NEED_BYTE_SWAP || MAVLINK_C2000
	coyote_probe->time_boot_ms = mavlink_msg_coyote_probe_get_time_boot_ms(msg);
	mavlink_msg_coyote_probe_get_rail_voltage(msg, coyote_probe->rail_voltage);
	mavlink_msg_coyote_probe_get_temperature(msg, coyote_probe->temperature);
	mavlink_msg_coyote_probe_get_motor_current_rms(msg, coyote_probe->motor_current_rms);
	mavlink_msg_coyote_probe_get_motor_current_peak(msg, coyote_probe->motor_current_peak);
#else
	memcpy(coyote_probe, _MAV_PAYLOAD(msg), MAVLINK_MSG_ID_COYOTE_PROBE_LEN);
#endif
}
