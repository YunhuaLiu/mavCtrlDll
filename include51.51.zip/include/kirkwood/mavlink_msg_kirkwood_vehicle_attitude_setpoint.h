// MESSAGE KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT PACKING

#if MAVLINK_C2000
#include "../protocol_c2000.h"
#endif

#define MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT 165

typedef struct __mavlink_kirkwood_vehicle_attitude_setpoint_t
{
 uint64_t timestamp; /*< Time since boot (microseconds)*/
 float roll; /*< Roll setpoint (rad)*/
 float pitch; /*< Pitch setpoint (rad)*/
 float yaw; /*< Yaw setpoint (rad)*/
 float thrust; /*< Normalized (0 to 1)*/
} mavlink_kirkwood_vehicle_attitude_setpoint_t;

#define MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT_LEN 24
#define MAVLINK_MSG_ID_165_LEN 24

#define MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT_CRC 166
#define MAVLINK_MSG_ID_165_CRC 166



#define MAVLINK_MESSAGE_INFO_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT { \
	"KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT", \
	5, \
	{  { "timestamp", NULL, MAVLINK_TYPE_UINT64_T, 0, 0, offsetof(mavlink_kirkwood_vehicle_attitude_setpoint_t, timestamp) }, \
         { "roll", NULL, MAVLINK_TYPE_FLOAT, 0, 8, offsetof(mavlink_kirkwood_vehicle_attitude_setpoint_t, roll) }, \
         { "pitch", NULL, MAVLINK_TYPE_FLOAT, 0, 12, offsetof(mavlink_kirkwood_vehicle_attitude_setpoint_t, pitch) }, \
         { "yaw", NULL, MAVLINK_TYPE_FLOAT, 0, 16, offsetof(mavlink_kirkwood_vehicle_attitude_setpoint_t, yaw) }, \
         { "thrust", NULL, MAVLINK_TYPE_FLOAT, 0, 20, offsetof(mavlink_kirkwood_vehicle_attitude_setpoint_t, thrust) }, \
         } \
}


/**
 * @brief Pack a kirkwood_vehicle_attitude_setpoint message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param timestamp Time since boot (microseconds)
 * @param roll Roll setpoint (rad)
 * @param pitch Pitch setpoint (rad)
 * @param yaw Yaw setpoint (rad)
 * @param thrust Normalized (0 to 1)
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_kirkwood_vehicle_attitude_setpoint_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
						       uint64_t timestamp, float roll, float pitch, float yaw, float thrust)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT_LEN];
	_mav_put_uint64_t(buf, 0, timestamp);
	_mav_put_float(buf, 8, roll);
	_mav_put_float(buf, 12, pitch);
	_mav_put_float(buf, 16, yaw);
	_mav_put_float(buf, 20, thrust);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT_LEN);
#elif MAVLINK_C2000
		mav_put_uint64_t_c2000(&(msg->payload64[0]), 0, timestamp);
		mav_put_float_c2000(&(msg->payload64[0]), 8, roll);
		mav_put_float_c2000(&(msg->payload64[0]), 12, pitch);
		mav_put_float_c2000(&(msg->payload64[0]), 16, yaw);
		mav_put_float_c2000(&(msg->payload64[0]), 20, thrust);
	
	
#else
	mavlink_kirkwood_vehicle_attitude_setpoint_t packet;
	packet.timestamp = timestamp;
	packet.roll = roll;
	packet.pitch = pitch;
	packet.yaw = yaw;
	packet.thrust = thrust;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT_LEN, MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT_CRC);
#else
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT_LEN);
#endif
}

/**
 * @brief Pack a kirkwood_vehicle_attitude_setpoint message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param timestamp Time since boot (microseconds)
 * @param roll Roll setpoint (rad)
 * @param pitch Pitch setpoint (rad)
 * @param yaw Yaw setpoint (rad)
 * @param thrust Normalized (0 to 1)
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_kirkwood_vehicle_attitude_setpoint_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
							   mavlink_message_t* msg,
						           uint64_t timestamp,float roll,float pitch,float yaw,float thrust)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT_LEN];
	_mav_put_uint64_t(buf, 0, timestamp);
	_mav_put_float(buf, 8, roll);
	_mav_put_float(buf, 12, pitch);
	_mav_put_float(buf, 16, yaw);
	_mav_put_float(buf, 20, thrust);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT_LEN);
#else
	mavlink_kirkwood_vehicle_attitude_setpoint_t packet;
	packet.timestamp = timestamp;
	packet.roll = roll;
	packet.pitch = pitch;
	packet.yaw = yaw;
	packet.thrust = thrust;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT_LEN, MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT_CRC);
#else
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT_LEN);
#endif
}

/**
 * @brief Encode a kirkwood_vehicle_attitude_setpoint struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param kirkwood_vehicle_attitude_setpoint C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_kirkwood_vehicle_attitude_setpoint_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_kirkwood_vehicle_attitude_setpoint_t* kirkwood_vehicle_attitude_setpoint)
{
	return mavlink_msg_kirkwood_vehicle_attitude_setpoint_pack(system_id, component_id, msg, kirkwood_vehicle_attitude_setpoint->timestamp, kirkwood_vehicle_attitude_setpoint->roll, kirkwood_vehicle_attitude_setpoint->pitch, kirkwood_vehicle_attitude_setpoint->yaw, kirkwood_vehicle_attitude_setpoint->thrust);
}

/**
 * @brief Encode a kirkwood_vehicle_attitude_setpoint struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param kirkwood_vehicle_attitude_setpoint C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_kirkwood_vehicle_attitude_setpoint_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_kirkwood_vehicle_attitude_setpoint_t* kirkwood_vehicle_attitude_setpoint)
{
	return mavlink_msg_kirkwood_vehicle_attitude_setpoint_pack_chan(system_id, component_id, chan, msg, kirkwood_vehicle_attitude_setpoint->timestamp, kirkwood_vehicle_attitude_setpoint->roll, kirkwood_vehicle_attitude_setpoint->pitch, kirkwood_vehicle_attitude_setpoint->yaw, kirkwood_vehicle_attitude_setpoint->thrust);
}

/**
 * @brief Send a kirkwood_vehicle_attitude_setpoint message
 * @param chan MAVLink channel to send the message
 *
 * @param timestamp Time since boot (microseconds)
 * @param roll Roll setpoint (rad)
 * @param pitch Pitch setpoint (rad)
 * @param yaw Yaw setpoint (rad)
 * @param thrust Normalized (0 to 1)
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_kirkwood_vehicle_attitude_setpoint_send(mavlink_channel_t chan, uint64_t timestamp, float roll, float pitch, float yaw, float thrust)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT_LEN];
	_mav_put_uint64_t(buf, 0, timestamp);
	_mav_put_float(buf, 8, roll);
	_mav_put_float(buf, 12, pitch);
	_mav_put_float(buf, 16, yaw);
	_mav_put_float(buf, 20, thrust);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT, buf, MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT_LEN, MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT, buf, MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT_LEN);
#endif
#else
	mavlink_kirkwood_vehicle_attitude_setpoint_t packet;
	packet.timestamp = timestamp;
	packet.roll = roll;
	packet.pitch = pitch;
	packet.yaw = yaw;
	packet.thrust = thrust;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT, (const char *)&packet, MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT_LEN, MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT, (const char *)&packet, MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT_LEN);
#endif
#endif
}

#if MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_kirkwood_vehicle_attitude_setpoint_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint64_t timestamp, float roll, float pitch, float yaw, float thrust)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char *buf = (char *)msgbuf;
	_mav_put_uint64_t(buf, 0, timestamp);
	_mav_put_float(buf, 8, roll);
	_mav_put_float(buf, 12, pitch);
	_mav_put_float(buf, 16, yaw);
	_mav_put_float(buf, 20, thrust);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT, buf, MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT_LEN, MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT, buf, MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT_LEN);
#endif
#else
	mavlink_kirkwood_vehicle_attitude_setpoint_t *packet = (mavlink_kirkwood_vehicle_attitude_setpoint_t *)msgbuf;
	packet->timestamp = timestamp;
	packet->roll = roll;
	packet->pitch = pitch;
	packet->yaw = yaw;
	packet->thrust = thrust;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT, (const char *)packet, MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT_LEN, MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT, (const char *)packet, MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT_LEN);
#endif
#endif
}
#endif

#endif

// MESSAGE KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT UNPACKING


/**
 * @brief Get field timestamp from kirkwood_vehicle_attitude_setpoint message
 *
 * @return Time since boot (microseconds)
 */
static inline uint64_t mavlink_msg_kirkwood_vehicle_attitude_setpoint_get_timestamp(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint64_t(msg,  0);
#else
	return mav_get_uint64_t_c2000(&(msg->payload64[0]),  0);
#endif
}

/**
 * @brief Get field roll from kirkwood_vehicle_attitude_setpoint message
 *
 * @return Roll setpoint (rad)
 */
static inline float mavlink_msg_kirkwood_vehicle_attitude_setpoint_get_roll(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  8);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  8);
#endif
}

/**
 * @brief Get field pitch from kirkwood_vehicle_attitude_setpoint message
 *
 * @return Pitch setpoint (rad)
 */
static inline float mavlink_msg_kirkwood_vehicle_attitude_setpoint_get_pitch(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  12);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  12);
#endif
}

/**
 * @brief Get field yaw from kirkwood_vehicle_attitude_setpoint message
 *
 * @return Yaw setpoint (rad)
 */
static inline float mavlink_msg_kirkwood_vehicle_attitude_setpoint_get_yaw(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  16);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  16);
#endif
}

/**
 * @brief Get field thrust from kirkwood_vehicle_attitude_setpoint message
 *
 * @return Normalized (0 to 1)
 */
static inline float mavlink_msg_kirkwood_vehicle_attitude_setpoint_get_thrust(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  20);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  20);
#endif
}

/**
 * @brief Decode a kirkwood_vehicle_attitude_setpoint message into a struct
 *
 * @param msg The message to decode
 * @param kirkwood_vehicle_attitude_setpoint C-struct to decode the message contents into
 */
static inline void mavlink_msg_kirkwood_vehicle_attitude_setpoint_decode(const mavlink_message_t* msg, mavlink_kirkwood_vehicle_attitude_setpoint_t* kirkwood_vehicle_attitude_setpoint)
{
#if MAVLINK_NEED_BYTE_SWAP || MAVLINK_C2000
	kirkwood_vehicle_attitude_setpoint->timestamp = mavlink_msg_kirkwood_vehicle_attitude_setpoint_get_timestamp(msg);
	kirkwood_vehicle_attitude_setpoint->roll = mavlink_msg_kirkwood_vehicle_attitude_setpoint_get_roll(msg);
	kirkwood_vehicle_attitude_setpoint->pitch = mavlink_msg_kirkwood_vehicle_attitude_setpoint_get_pitch(msg);
	kirkwood_vehicle_attitude_setpoint->yaw = mavlink_msg_kirkwood_vehicle_attitude_setpoint_get_yaw(msg);
	kirkwood_vehicle_attitude_setpoint->thrust = mavlink_msg_kirkwood_vehicle_attitude_setpoint_get_thrust(msg);
#else
	memcpy(kirkwood_vehicle_attitude_setpoint, _MAV_PAYLOAD(msg), MAVLINK_MSG_ID_KIRKWOOD_VEHICLE_ATTITUDE_SETPOINT_LEN);
#endif
}
