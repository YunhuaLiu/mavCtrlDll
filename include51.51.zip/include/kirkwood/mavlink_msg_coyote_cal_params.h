// MESSAGE COYOTE_CAL_PARAMS PACKING

#if MAVLINK_C2000
#include "../protocol_c2000.h"
#endif

#define MAVLINK_MSG_ID_COYOTE_CAL_PARAMS 179

typedef struct __mavlink_coyote_cal_params_t
{
 uint32_t id; /*< Data type see COYOTE_CAL_ID_ENUM*/
 float rotation[9]; /*< Rotation matrix (if needed)*/
 float offset[3]; /*< Translation offset (if needed)*/
 float scale[3]; /*< Scale (if needed)*/
} mavlink_coyote_cal_params_t;

#define MAVLINK_MSG_ID_COYOTE_CAL_PARAMS_LEN 64
#define MAVLINK_MSG_ID_179_LEN 64

#define MAVLINK_MSG_ID_COYOTE_CAL_PARAMS_CRC 104
#define MAVLINK_MSG_ID_179_CRC 104

#define MAVLINK_MSG_COYOTE_CAL_PARAMS_FIELD_ROTATION_LEN 9
#define MAVLINK_MSG_COYOTE_CAL_PARAMS_FIELD_OFFSET_LEN 3
#define MAVLINK_MSG_COYOTE_CAL_PARAMS_FIELD_SCALE_LEN 3

#define MAVLINK_MESSAGE_INFO_COYOTE_CAL_PARAMS { \
	"COYOTE_CAL_PARAMS", \
	4, \
	{  { "id", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_coyote_cal_params_t, id) }, \
         { "rotation", NULL, MAVLINK_TYPE_FLOAT, 9, 4, offsetof(mavlink_coyote_cal_params_t, rotation) }, \
         { "offset", NULL, MAVLINK_TYPE_FLOAT, 3, 40, offsetof(mavlink_coyote_cal_params_t, offset) }, \
         { "scale", NULL, MAVLINK_TYPE_FLOAT, 3, 52, offsetof(mavlink_coyote_cal_params_t, scale) }, \
         } \
}


/**
 * @brief Pack a coyote_cal_params message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param id Data type see COYOTE_CAL_ID_ENUM
 * @param rotation Rotation matrix (if needed)
 * @param offset Translation offset (if needed)
 * @param scale Scale (if needed)
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_coyote_cal_params_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
						       uint32_t id, const float *rotation, const float *offset, const float *scale)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_COYOTE_CAL_PARAMS_LEN];
	_mav_put_uint32_t(buf, 0, id);
	_mav_put_float_array(buf, 4, rotation, 9);
	_mav_put_float_array(buf, 40, offset, 3);
	_mav_put_float_array(buf, 52, scale, 3);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_COYOTE_CAL_PARAMS_LEN);
#elif MAVLINK_C2000
		mav_put_uint32_t_c2000(&(msg->payload64[0]), 0, id);
	
		mav_put_float_array_c2000(&(msg->payload64[0]), rotation, 4, 9);
		mav_put_float_array_c2000(&(msg->payload64[0]), offset, 40, 3);
		mav_put_float_array_c2000(&(msg->payload64[0]), scale, 52, 3);
	
#else
	mavlink_coyote_cal_params_t packet;
	packet.id = id;
	mav_array_memcpy(packet.rotation, rotation, sizeof(float)*9);
	mav_array_memcpy(packet.offset, offset, sizeof(float)*3);
	mav_array_memcpy(packet.scale, scale, sizeof(float)*3);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_COYOTE_CAL_PARAMS_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_COYOTE_CAL_PARAMS;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_COYOTE_CAL_PARAMS_LEN, MAVLINK_MSG_ID_COYOTE_CAL_PARAMS_CRC);
#else
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_COYOTE_CAL_PARAMS_LEN);
#endif
}

/**
 * @brief Pack a coyote_cal_params message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param id Data type see COYOTE_CAL_ID_ENUM
 * @param rotation Rotation matrix (if needed)
 * @param offset Translation offset (if needed)
 * @param scale Scale (if needed)
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_coyote_cal_params_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
							   mavlink_message_t* msg,
						           uint32_t id,const float *rotation,const float *offset,const float *scale)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_COYOTE_CAL_PARAMS_LEN];
	_mav_put_uint32_t(buf, 0, id);
	_mav_put_float_array(buf, 4, rotation, 9);
	_mav_put_float_array(buf, 40, offset, 3);
	_mav_put_float_array(buf, 52, scale, 3);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_COYOTE_CAL_PARAMS_LEN);
#else
	mavlink_coyote_cal_params_t packet;
	packet.id = id;
	mav_array_memcpy(packet.rotation, rotation, sizeof(float)*9);
	mav_array_memcpy(packet.offset, offset, sizeof(float)*3);
	mav_array_memcpy(packet.scale, scale, sizeof(float)*3);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_COYOTE_CAL_PARAMS_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_COYOTE_CAL_PARAMS;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_COYOTE_CAL_PARAMS_LEN, MAVLINK_MSG_ID_COYOTE_CAL_PARAMS_CRC);
#else
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_COYOTE_CAL_PARAMS_LEN);
#endif
}

/**
 * @brief Encode a coyote_cal_params struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param coyote_cal_params C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_coyote_cal_params_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_coyote_cal_params_t* coyote_cal_params)
{
	return mavlink_msg_coyote_cal_params_pack(system_id, component_id, msg, coyote_cal_params->id, coyote_cal_params->rotation, coyote_cal_params->offset, coyote_cal_params->scale);
}

/**
 * @brief Encode a coyote_cal_params struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param coyote_cal_params C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_coyote_cal_params_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_coyote_cal_params_t* coyote_cal_params)
{
	return mavlink_msg_coyote_cal_params_pack_chan(system_id, component_id, chan, msg, coyote_cal_params->id, coyote_cal_params->rotation, coyote_cal_params->offset, coyote_cal_params->scale);
}

/**
 * @brief Send a coyote_cal_params message
 * @param chan MAVLink channel to send the message
 *
 * @param id Data type see COYOTE_CAL_ID_ENUM
 * @param rotation Rotation matrix (if needed)
 * @param offset Translation offset (if needed)
 * @param scale Scale (if needed)
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_coyote_cal_params_send(mavlink_channel_t chan, uint32_t id, const float *rotation, const float *offset, const float *scale)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_COYOTE_CAL_PARAMS_LEN];
	_mav_put_uint32_t(buf, 0, id);
	_mav_put_float_array(buf, 4, rotation, 9);
	_mav_put_float_array(buf, 40, offset, 3);
	_mav_put_float_array(buf, 52, scale, 3);
#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_COYOTE_CAL_PARAMS, buf, MAVLINK_MSG_ID_COYOTE_CAL_PARAMS_LEN, MAVLINK_MSG_ID_COYOTE_CAL_PARAMS_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_COYOTE_CAL_PARAMS, buf, MAVLINK_MSG_ID_COYOTE_CAL_PARAMS_LEN);
#endif
#else
	mavlink_coyote_cal_params_t packet;
	packet.id = id;
	mav_array_memcpy(packet.rotation, rotation, sizeof(float)*9);
	mav_array_memcpy(packet.offset, offset, sizeof(float)*3);
	mav_array_memcpy(packet.scale, scale, sizeof(float)*3);
#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_COYOTE_CAL_PARAMS, (const char *)&packet, MAVLINK_MSG_ID_COYOTE_CAL_PARAMS_LEN, MAVLINK_MSG_ID_COYOTE_CAL_PARAMS_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_COYOTE_CAL_PARAMS, (const char *)&packet, MAVLINK_MSG_ID_COYOTE_CAL_PARAMS_LEN);
#endif
#endif
}

#if MAVLINK_MSG_ID_COYOTE_CAL_PARAMS_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_coyote_cal_params_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint32_t id, const float *rotation, const float *offset, const float *scale)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char *buf = (char *)msgbuf;
	_mav_put_uint32_t(buf, 0, id);
	_mav_put_float_array(buf, 4, rotation, 9);
	_mav_put_float_array(buf, 40, offset, 3);
	_mav_put_float_array(buf, 52, scale, 3);
#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_COYOTE_CAL_PARAMS, buf, MAVLINK_MSG_ID_COYOTE_CAL_PARAMS_LEN, MAVLINK_MSG_ID_COYOTE_CAL_PARAMS_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_COYOTE_CAL_PARAMS, buf, MAVLINK_MSG_ID_COYOTE_CAL_PARAMS_LEN);
#endif
#else
	mavlink_coyote_cal_params_t *packet = (mavlink_coyote_cal_params_t *)msgbuf;
	packet->id = id;
	mav_array_memcpy(packet->rotation, rotation, sizeof(float)*9);
	mav_array_memcpy(packet->offset, offset, sizeof(float)*3);
	mav_array_memcpy(packet->scale, scale, sizeof(float)*3);
#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_COYOTE_CAL_PARAMS, (const char *)packet, MAVLINK_MSG_ID_COYOTE_CAL_PARAMS_LEN, MAVLINK_MSG_ID_COYOTE_CAL_PARAMS_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_COYOTE_CAL_PARAMS, (const char *)packet, MAVLINK_MSG_ID_COYOTE_CAL_PARAMS_LEN);
#endif
#endif
}
#endif

#endif

// MESSAGE COYOTE_CAL_PARAMS UNPACKING


/**
 * @brief Get field id from coyote_cal_params message
 *
 * @return Data type see COYOTE_CAL_ID_ENUM
 */
static inline uint32_t mavlink_msg_coyote_cal_params_get_id(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint32_t(msg,  0);
#else
	return mav_get_uint32_t_c2000(&(msg->payload64[0]),  0);
#endif
}

/**
 * @brief Get field rotation from coyote_cal_params message
 *
 * @return Rotation matrix (if needed)
 */
static inline uint16_t mavlink_msg_coyote_cal_params_get_rotation(const mavlink_message_t* msg, float *rotation)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float_array(msg, rotation, 9,  4);
#else
	return mav_get_float_array_c2000(&(msg->payload64[0]), rotation, 9,  4);
#endif
}

/**
 * @brief Get field offset from coyote_cal_params message
 *
 * @return Translation offset (if needed)
 */
static inline uint16_t mavlink_msg_coyote_cal_params_get_offset(const mavlink_message_t* msg, float *offset)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float_array(msg, offset, 3,  40);
#else
	return mav_get_float_array_c2000(&(msg->payload64[0]), offset, 3,  40);
#endif
}

/**
 * @brief Get field scale from coyote_cal_params message
 *
 * @return Scale (if needed)
 */
static inline uint16_t mavlink_msg_coyote_cal_params_get_scale(const mavlink_message_t* msg, float *scale)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float_array(msg, scale, 3,  52);
#else
	return mav_get_float_array_c2000(&(msg->payload64[0]), scale, 3,  52);
#endif
}

/**
 * @brief Decode a coyote_cal_params message into a struct
 *
 * @param msg The message to decode
 * @param coyote_cal_params C-struct to decode the message contents into
 */
static inline void mavlink_msg_coyote_cal_params_decode(const mavlink_message_t* msg, mavlink_coyote_cal_params_t* coyote_cal_params)
{
#if MAVLINK_NEED_BYTE_SWAP || MAVLINK_C2000
	coyote_cal_params->id = mavlink_msg_coyote_cal_params_get_id(msg);
	mavlink_msg_coyote_cal_params_get_rotation(msg, coyote_cal_params->rotation);
	mavlink_msg_coyote_cal_params_get_offset(msg, coyote_cal_params->offset);
	mavlink_msg_coyote_cal_params_get_scale(msg, coyote_cal_params->scale);
#else
	memcpy(coyote_cal_params, _MAV_PAYLOAD(msg), MAVLINK_MSG_ID_COYOTE_CAL_PARAMS_LEN);
#endif
}
