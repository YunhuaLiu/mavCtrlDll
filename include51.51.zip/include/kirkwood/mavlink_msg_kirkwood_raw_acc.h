// MESSAGE KIRKWOOD_RAW_ACC PACKING

#if MAVLINK_C2000
#include "../protocol_c2000.h"
#endif

#define MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC 174

typedef struct __mavlink_kirkwood_raw_acc_t
{
 uint64_t time_usec; /*< Timestamp (microseconds since UNIX epoch or microseconds since system boot)*/
 float x; /*< X acceleration (raw) [m/s^2]*/
 float y; /*< Y acceleration (raw) [m/s^2]*/
 float z; /*< Z acceleration (raw) [m/s^2]*/
 float range_m_s2; /*< Measurement range [m/s^2]*/
 float temperature; /*< Temperature of accelerometer*/
 int16_t x_raw; /*< X acceleration (raw)*/
 int16_t y_raw; /*< Y acceleration (raw)*/
 int16_t z_raw; /*< Z acceleration (raw)*/
 uint8_t id; /*< Sensor ID*/
 uint8_t flatline; /*< Indicates if measurements are flatlining*/
} mavlink_kirkwood_raw_acc_t;

#define MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC_LEN 36
#define MAVLINK_MSG_ID_174_LEN 36

#define MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC_CRC 220
#define MAVLINK_MSG_ID_174_CRC 220



#define MAVLINK_MESSAGE_INFO_KIRKWOOD_RAW_ACC { \
	"KIRKWOOD_RAW_ACC", \
	11, \
	{  { "time_usec", NULL, MAVLINK_TYPE_UINT64_T, 0, 0, offsetof(mavlink_kirkwood_raw_acc_t, time_usec) }, \
         { "x", NULL, MAVLINK_TYPE_FLOAT, 0, 8, offsetof(mavlink_kirkwood_raw_acc_t, x) }, \
         { "y", NULL, MAVLINK_TYPE_FLOAT, 0, 12, offsetof(mavlink_kirkwood_raw_acc_t, y) }, \
         { "z", NULL, MAVLINK_TYPE_FLOAT, 0, 16, offsetof(mavlink_kirkwood_raw_acc_t, z) }, \
         { "range_m_s2", NULL, MAVLINK_TYPE_FLOAT, 0, 20, offsetof(mavlink_kirkwood_raw_acc_t, range_m_s2) }, \
         { "temperature", NULL, MAVLINK_TYPE_FLOAT, 0, 24, offsetof(mavlink_kirkwood_raw_acc_t, temperature) }, \
         { "x_raw", NULL, MAVLINK_TYPE_INT16_T, 0, 28, offsetof(mavlink_kirkwood_raw_acc_t, x_raw) }, \
         { "y_raw", NULL, MAVLINK_TYPE_INT16_T, 0, 30, offsetof(mavlink_kirkwood_raw_acc_t, y_raw) }, \
         { "z_raw", NULL, MAVLINK_TYPE_INT16_T, 0, 32, offsetof(mavlink_kirkwood_raw_acc_t, z_raw) }, \
         { "id", NULL, MAVLINK_TYPE_UINT8_T, 0, 34, offsetof(mavlink_kirkwood_raw_acc_t, id) }, \
         { "flatline", NULL, MAVLINK_TYPE_UINT8_T, 0, 35, offsetof(mavlink_kirkwood_raw_acc_t, flatline) }, \
         } \
}


/**
 * @brief Pack a kirkwood_raw_acc message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param time_usec Timestamp (microseconds since UNIX epoch or microseconds since system boot)
 * @param id Sensor ID
 * @param x_raw X acceleration (raw)
 * @param y_raw Y acceleration (raw)
 * @param z_raw Z acceleration (raw)
 * @param x X acceleration (raw) [m/s^2]
 * @param y Y acceleration (raw) [m/s^2]
 * @param z Z acceleration (raw) [m/s^2]
 * @param range_m_s2 Measurement range [m/s^2]
 * @param temperature Temperature of accelerometer
 * @param flatline Indicates if measurements are flatlining
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_kirkwood_raw_acc_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
						       uint64_t time_usec, uint8_t id, int16_t x_raw, int16_t y_raw, int16_t z_raw, float x, float y, float z, float range_m_s2, float temperature, uint8_t flatline)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC_LEN];
	_mav_put_uint64_t(buf, 0, time_usec);
	_mav_put_float(buf, 8, x);
	_mav_put_float(buf, 12, y);
	_mav_put_float(buf, 16, z);
	_mav_put_float(buf, 20, range_m_s2);
	_mav_put_float(buf, 24, temperature);
	_mav_put_int16_t(buf, 28, x_raw);
	_mav_put_int16_t(buf, 30, y_raw);
	_mav_put_int16_t(buf, 32, z_raw);
	_mav_put_uint8_t(buf, 34, id);
	_mav_put_uint8_t(buf, 35, flatline);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC_LEN);
#elif MAVLINK_C2000
		mav_put_uint64_t_c2000(&(msg->payload64[0]), 0, time_usec);
		mav_put_float_c2000(&(msg->payload64[0]), 8, x);
		mav_put_float_c2000(&(msg->payload64[0]), 12, y);
		mav_put_float_c2000(&(msg->payload64[0]), 16, z);
		mav_put_float_c2000(&(msg->payload64[0]), 20, range_m_s2);
		mav_put_float_c2000(&(msg->payload64[0]), 24, temperature);
		mav_put_int16_t_c2000(&(msg->payload64[0]), 28, x_raw);
		mav_put_int16_t_c2000(&(msg->payload64[0]), 30, y_raw);
		mav_put_int16_t_c2000(&(msg->payload64[0]), 32, z_raw);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 34, id);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 35, flatline);
	
	
#else
	mavlink_kirkwood_raw_acc_t packet;
	packet.time_usec = time_usec;
	packet.x = x;
	packet.y = y;
	packet.z = z;
	packet.range_m_s2 = range_m_s2;
	packet.temperature = temperature;
	packet.x_raw = x_raw;
	packet.y_raw = y_raw;
	packet.z_raw = z_raw;
	packet.id = id;
	packet.flatline = flatline;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC_LEN, MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC_CRC);
#else
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC_LEN);
#endif
}

/**
 * @brief Pack a kirkwood_raw_acc message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param time_usec Timestamp (microseconds since UNIX epoch or microseconds since system boot)
 * @param id Sensor ID
 * @param x_raw X acceleration (raw)
 * @param y_raw Y acceleration (raw)
 * @param z_raw Z acceleration (raw)
 * @param x X acceleration (raw) [m/s^2]
 * @param y Y acceleration (raw) [m/s^2]
 * @param z Z acceleration (raw) [m/s^2]
 * @param range_m_s2 Measurement range [m/s^2]
 * @param temperature Temperature of accelerometer
 * @param flatline Indicates if measurements are flatlining
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_kirkwood_raw_acc_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
							   mavlink_message_t* msg,
						           uint64_t time_usec,uint8_t id,int16_t x_raw,int16_t y_raw,int16_t z_raw,float x,float y,float z,float range_m_s2,float temperature,uint8_t flatline)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC_LEN];
	_mav_put_uint64_t(buf, 0, time_usec);
	_mav_put_float(buf, 8, x);
	_mav_put_float(buf, 12, y);
	_mav_put_float(buf, 16, z);
	_mav_put_float(buf, 20, range_m_s2);
	_mav_put_float(buf, 24, temperature);
	_mav_put_int16_t(buf, 28, x_raw);
	_mav_put_int16_t(buf, 30, y_raw);
	_mav_put_int16_t(buf, 32, z_raw);
	_mav_put_uint8_t(buf, 34, id);
	_mav_put_uint8_t(buf, 35, flatline);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC_LEN);
#else
	mavlink_kirkwood_raw_acc_t packet;
	packet.time_usec = time_usec;
	packet.x = x;
	packet.y = y;
	packet.z = z;
	packet.range_m_s2 = range_m_s2;
	packet.temperature = temperature;
	packet.x_raw = x_raw;
	packet.y_raw = y_raw;
	packet.z_raw = z_raw;
	packet.id = id;
	packet.flatline = flatline;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC_LEN, MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC_CRC);
#else
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC_LEN);
#endif
}

/**
 * @brief Encode a kirkwood_raw_acc struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param kirkwood_raw_acc C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_kirkwood_raw_acc_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_kirkwood_raw_acc_t* kirkwood_raw_acc)
{
	return mavlink_msg_kirkwood_raw_acc_pack(system_id, component_id, msg, kirkwood_raw_acc->time_usec, kirkwood_raw_acc->id, kirkwood_raw_acc->x_raw, kirkwood_raw_acc->y_raw, kirkwood_raw_acc->z_raw, kirkwood_raw_acc->x, kirkwood_raw_acc->y, kirkwood_raw_acc->z, kirkwood_raw_acc->range_m_s2, kirkwood_raw_acc->temperature, kirkwood_raw_acc->flatline);
}

/**
 * @brief Encode a kirkwood_raw_acc struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param kirkwood_raw_acc C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_kirkwood_raw_acc_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_kirkwood_raw_acc_t* kirkwood_raw_acc)
{
	return mavlink_msg_kirkwood_raw_acc_pack_chan(system_id, component_id, chan, msg, kirkwood_raw_acc->time_usec, kirkwood_raw_acc->id, kirkwood_raw_acc->x_raw, kirkwood_raw_acc->y_raw, kirkwood_raw_acc->z_raw, kirkwood_raw_acc->x, kirkwood_raw_acc->y, kirkwood_raw_acc->z, kirkwood_raw_acc->range_m_s2, kirkwood_raw_acc->temperature, kirkwood_raw_acc->flatline);
}

/**
 * @brief Send a kirkwood_raw_acc message
 * @param chan MAVLink channel to send the message
 *
 * @param time_usec Timestamp (microseconds since UNIX epoch or microseconds since system boot)
 * @param id Sensor ID
 * @param x_raw X acceleration (raw)
 * @param y_raw Y acceleration (raw)
 * @param z_raw Z acceleration (raw)
 * @param x X acceleration (raw) [m/s^2]
 * @param y Y acceleration (raw) [m/s^2]
 * @param z Z acceleration (raw) [m/s^2]
 * @param range_m_s2 Measurement range [m/s^2]
 * @param temperature Temperature of accelerometer
 * @param flatline Indicates if measurements are flatlining
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_kirkwood_raw_acc_send(mavlink_channel_t chan, uint64_t time_usec, uint8_t id, int16_t x_raw, int16_t y_raw, int16_t z_raw, float x, float y, float z, float range_m_s2, float temperature, uint8_t flatline)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC_LEN];
	_mav_put_uint64_t(buf, 0, time_usec);
	_mav_put_float(buf, 8, x);
	_mav_put_float(buf, 12, y);
	_mav_put_float(buf, 16, z);
	_mav_put_float(buf, 20, range_m_s2);
	_mav_put_float(buf, 24, temperature);
	_mav_put_int16_t(buf, 28, x_raw);
	_mav_put_int16_t(buf, 30, y_raw);
	_mav_put_int16_t(buf, 32, z_raw);
	_mav_put_uint8_t(buf, 34, id);
	_mav_put_uint8_t(buf, 35, flatline);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC, buf, MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC_LEN, MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC, buf, MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC_LEN);
#endif
#else
	mavlink_kirkwood_raw_acc_t packet;
	packet.time_usec = time_usec;
	packet.x = x;
	packet.y = y;
	packet.z = z;
	packet.range_m_s2 = range_m_s2;
	packet.temperature = temperature;
	packet.x_raw = x_raw;
	packet.y_raw = y_raw;
	packet.z_raw = z_raw;
	packet.id = id;
	packet.flatline = flatline;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC, (const char *)&packet, MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC_LEN, MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC, (const char *)&packet, MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC_LEN);
#endif
#endif
}

#if MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_kirkwood_raw_acc_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint64_t time_usec, uint8_t id, int16_t x_raw, int16_t y_raw, int16_t z_raw, float x, float y, float z, float range_m_s2, float temperature, uint8_t flatline)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char *buf = (char *)msgbuf;
	_mav_put_uint64_t(buf, 0, time_usec);
	_mav_put_float(buf, 8, x);
	_mav_put_float(buf, 12, y);
	_mav_put_float(buf, 16, z);
	_mav_put_float(buf, 20, range_m_s2);
	_mav_put_float(buf, 24, temperature);
	_mav_put_int16_t(buf, 28, x_raw);
	_mav_put_int16_t(buf, 30, y_raw);
	_mav_put_int16_t(buf, 32, z_raw);
	_mav_put_uint8_t(buf, 34, id);
	_mav_put_uint8_t(buf, 35, flatline);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC, buf, MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC_LEN, MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC, buf, MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC_LEN);
#endif
#else
	mavlink_kirkwood_raw_acc_t *packet = (mavlink_kirkwood_raw_acc_t *)msgbuf;
	packet->time_usec = time_usec;
	packet->x = x;
	packet->y = y;
	packet->z = z;
	packet->range_m_s2 = range_m_s2;
	packet->temperature = temperature;
	packet->x_raw = x_raw;
	packet->y_raw = y_raw;
	packet->z_raw = z_raw;
	packet->id = id;
	packet->flatline = flatline;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC, (const char *)packet, MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC_LEN, MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC, (const char *)packet, MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC_LEN);
#endif
#endif
}
#endif

#endif

// MESSAGE KIRKWOOD_RAW_ACC UNPACKING


/**
 * @brief Get field time_usec from kirkwood_raw_acc message
 *
 * @return Timestamp (microseconds since UNIX epoch or microseconds since system boot)
 */
static inline uint64_t mavlink_msg_kirkwood_raw_acc_get_time_usec(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint64_t(msg,  0);
#else
	return mav_get_uint64_t_c2000(&(msg->payload64[0]),  0);
#endif
}

/**
 * @brief Get field id from kirkwood_raw_acc message
 *
 * @return Sensor ID
 */
static inline uint8_t mavlink_msg_kirkwood_raw_acc_get_id(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  34);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  34);
#endif
}

/**
 * @brief Get field x_raw from kirkwood_raw_acc message
 *
 * @return X acceleration (raw)
 */
static inline int16_t mavlink_msg_kirkwood_raw_acc_get_x_raw(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_int16_t(msg,  28);
#else
	return mav_get_int16_t_c2000(&(msg->payload64[0]),  28);
#endif
}

/**
 * @brief Get field y_raw from kirkwood_raw_acc message
 *
 * @return Y acceleration (raw)
 */
static inline int16_t mavlink_msg_kirkwood_raw_acc_get_y_raw(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_int16_t(msg,  30);
#else
	return mav_get_int16_t_c2000(&(msg->payload64[0]),  30);
#endif
}

/**
 * @brief Get field z_raw from kirkwood_raw_acc message
 *
 * @return Z acceleration (raw)
 */
static inline int16_t mavlink_msg_kirkwood_raw_acc_get_z_raw(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_int16_t(msg,  32);
#else
	return mav_get_int16_t_c2000(&(msg->payload64[0]),  32);
#endif
}

/**
 * @brief Get field x from kirkwood_raw_acc message
 *
 * @return X acceleration (raw) [m/s^2]
 */
static inline float mavlink_msg_kirkwood_raw_acc_get_x(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  8);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  8);
#endif
}

/**
 * @brief Get field y from kirkwood_raw_acc message
 *
 * @return Y acceleration (raw) [m/s^2]
 */
static inline float mavlink_msg_kirkwood_raw_acc_get_y(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  12);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  12);
#endif
}

/**
 * @brief Get field z from kirkwood_raw_acc message
 *
 * @return Z acceleration (raw) [m/s^2]
 */
static inline float mavlink_msg_kirkwood_raw_acc_get_z(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  16);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  16);
#endif
}

/**
 * @brief Get field range_m_s2 from kirkwood_raw_acc message
 *
 * @return Measurement range [m/s^2]
 */
static inline float mavlink_msg_kirkwood_raw_acc_get_range_m_s2(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  20);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  20);
#endif
}

/**
 * @brief Get field temperature from kirkwood_raw_acc message
 *
 * @return Temperature of accelerometer
 */
static inline float mavlink_msg_kirkwood_raw_acc_get_temperature(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  24);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  24);
#endif
}

/**
 * @brief Get field flatline from kirkwood_raw_acc message
 *
 * @return Indicates if measurements are flatlining
 */
static inline uint8_t mavlink_msg_kirkwood_raw_acc_get_flatline(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  35);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  35);
#endif
}

/**
 * @brief Decode a kirkwood_raw_acc message into a struct
 *
 * @param msg The message to decode
 * @param kirkwood_raw_acc C-struct to decode the message contents into
 */
static inline void mavlink_msg_kirkwood_raw_acc_decode(const mavlink_message_t* msg, mavlink_kirkwood_raw_acc_t* kirkwood_raw_acc)
{
#if MAVLINK_NEED_BYTE_SWAP || MAVLINK_C2000
	kirkwood_raw_acc->time_usec = mavlink_msg_kirkwood_raw_acc_get_time_usec(msg);
	kirkwood_raw_acc->x = mavlink_msg_kirkwood_raw_acc_get_x(msg);
	kirkwood_raw_acc->y = mavlink_msg_kirkwood_raw_acc_get_y(msg);
	kirkwood_raw_acc->z = mavlink_msg_kirkwood_raw_acc_get_z(msg);
	kirkwood_raw_acc->range_m_s2 = mavlink_msg_kirkwood_raw_acc_get_range_m_s2(msg);
	kirkwood_raw_acc->temperature = mavlink_msg_kirkwood_raw_acc_get_temperature(msg);
	kirkwood_raw_acc->x_raw = mavlink_msg_kirkwood_raw_acc_get_x_raw(msg);
	kirkwood_raw_acc->y_raw = mavlink_msg_kirkwood_raw_acc_get_y_raw(msg);
	kirkwood_raw_acc->z_raw = mavlink_msg_kirkwood_raw_acc_get_z_raw(msg);
	kirkwood_raw_acc->id = mavlink_msg_kirkwood_raw_acc_get_id(msg);
	kirkwood_raw_acc->flatline = mavlink_msg_kirkwood_raw_acc_get_flatline(msg);
#else
	memcpy(kirkwood_raw_acc, _MAV_PAYLOAD(msg), MAVLINK_MSG_ID_KIRKWOOD_RAW_ACC_LEN);
#endif
}
