// MESSAGE KIRKWOOD_SDLOG_CLIENT_HS PACKING

#if MAVLINK_C2000
#include "../protocol_c2000.h"
#endif

#define MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS 166

typedef struct __mavlink_kirkwood_sdlog_client_hs_t
{
 uint32_t index_start; /*< Contains the data for the operation*/
 uint32_t index_end; /*< Contains the data for the operation*/
 uint8_t opcode; /*< See KIRKWOOD_SDLOG_HS_CLIENT_OPCODE**/
} mavlink_kirkwood_sdlog_client_hs_t;

#define MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS_LEN 9
#define MAVLINK_MSG_ID_166_LEN 9

#define MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS_CRC 177
#define MAVLINK_MSG_ID_166_CRC 177



#define MAVLINK_MESSAGE_INFO_KIRKWOOD_SDLOG_CLIENT_HS { \
	"KIRKWOOD_SDLOG_CLIENT_HS", \
	3, \
	{  { "index_start", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_kirkwood_sdlog_client_hs_t, index_start) }, \
         { "index_end", NULL, MAVLINK_TYPE_UINT32_T, 0, 4, offsetof(mavlink_kirkwood_sdlog_client_hs_t, index_end) }, \
         { "opcode", NULL, MAVLINK_TYPE_UINT8_T, 0, 8, offsetof(mavlink_kirkwood_sdlog_client_hs_t, opcode) }, \
         } \
}


/**
 * @brief Pack a kirkwood_sdlog_client_hs message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param opcode See KIRKWOOD_SDLOG_HS_CLIENT_OPCODE*
 * @param index_start Contains the data for the operation
 * @param index_end Contains the data for the operation
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_kirkwood_sdlog_client_hs_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
						       uint8_t opcode, uint32_t index_start, uint32_t index_end)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS_LEN];
	_mav_put_uint32_t(buf, 0, index_start);
	_mav_put_uint32_t(buf, 4, index_end);
	_mav_put_uint8_t(buf, 8, opcode);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS_LEN);
#elif MAVLINK_C2000
		mav_put_uint32_t_c2000(&(msg->payload64[0]), 0, index_start);
		mav_put_uint32_t_c2000(&(msg->payload64[0]), 4, index_end);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 8, opcode);
	
	
#else
	mavlink_kirkwood_sdlog_client_hs_t packet;
	packet.index_start = index_start;
	packet.index_end = index_end;
	packet.opcode = opcode;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS_LEN, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS_CRC);
#else
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS_LEN);
#endif
}

/**
 * @brief Pack a kirkwood_sdlog_client_hs message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param opcode See KIRKWOOD_SDLOG_HS_CLIENT_OPCODE*
 * @param index_start Contains the data for the operation
 * @param index_end Contains the data for the operation
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_kirkwood_sdlog_client_hs_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
							   mavlink_message_t* msg,
						           uint8_t opcode,uint32_t index_start,uint32_t index_end)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS_LEN];
	_mav_put_uint32_t(buf, 0, index_start);
	_mav_put_uint32_t(buf, 4, index_end);
	_mav_put_uint8_t(buf, 8, opcode);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS_LEN);
#else
	mavlink_kirkwood_sdlog_client_hs_t packet;
	packet.index_start = index_start;
	packet.index_end = index_end;
	packet.opcode = opcode;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS_LEN, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS_CRC);
#else
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS_LEN);
#endif
}

/**
 * @brief Encode a kirkwood_sdlog_client_hs struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param kirkwood_sdlog_client_hs C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_kirkwood_sdlog_client_hs_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_kirkwood_sdlog_client_hs_t* kirkwood_sdlog_client_hs)
{
	return mavlink_msg_kirkwood_sdlog_client_hs_pack(system_id, component_id, msg, kirkwood_sdlog_client_hs->opcode, kirkwood_sdlog_client_hs->index_start, kirkwood_sdlog_client_hs->index_end);
}

/**
 * @brief Encode a kirkwood_sdlog_client_hs struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param kirkwood_sdlog_client_hs C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_kirkwood_sdlog_client_hs_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_kirkwood_sdlog_client_hs_t* kirkwood_sdlog_client_hs)
{
	return mavlink_msg_kirkwood_sdlog_client_hs_pack_chan(system_id, component_id, chan, msg, kirkwood_sdlog_client_hs->opcode, kirkwood_sdlog_client_hs->index_start, kirkwood_sdlog_client_hs->index_end);
}

/**
 * @brief Send a kirkwood_sdlog_client_hs message
 * @param chan MAVLink channel to send the message
 *
 * @param opcode See KIRKWOOD_SDLOG_HS_CLIENT_OPCODE*
 * @param index_start Contains the data for the operation
 * @param index_end Contains the data for the operation
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_kirkwood_sdlog_client_hs_send(mavlink_channel_t chan, uint8_t opcode, uint32_t index_start, uint32_t index_end)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS_LEN];
	_mav_put_uint32_t(buf, 0, index_start);
	_mav_put_uint32_t(buf, 4, index_end);
	_mav_put_uint8_t(buf, 8, opcode);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS, buf, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS_LEN, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS, buf, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS_LEN);
#endif
#else
	mavlink_kirkwood_sdlog_client_hs_t packet;
	packet.index_start = index_start;
	packet.index_end = index_end;
	packet.opcode = opcode;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS, (const char *)&packet, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS_LEN, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS, (const char *)&packet, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS_LEN);
#endif
#endif
}

#if MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_kirkwood_sdlog_client_hs_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint8_t opcode, uint32_t index_start, uint32_t index_end)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char *buf = (char *)msgbuf;
	_mav_put_uint32_t(buf, 0, index_start);
	_mav_put_uint32_t(buf, 4, index_end);
	_mav_put_uint8_t(buf, 8, opcode);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS, buf, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS_LEN, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS, buf, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS_LEN);
#endif
#else
	mavlink_kirkwood_sdlog_client_hs_t *packet = (mavlink_kirkwood_sdlog_client_hs_t *)msgbuf;
	packet->index_start = index_start;
	packet->index_end = index_end;
	packet->opcode = opcode;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS, (const char *)packet, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS_LEN, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS, (const char *)packet, MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS_LEN);
#endif
#endif
}
#endif

#endif

// MESSAGE KIRKWOOD_SDLOG_CLIENT_HS UNPACKING


/**
 * @brief Get field opcode from kirkwood_sdlog_client_hs message
 *
 * @return See KIRKWOOD_SDLOG_HS_CLIENT_OPCODE*
 */
static inline uint8_t mavlink_msg_kirkwood_sdlog_client_hs_get_opcode(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  8);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  8);
#endif
}

/**
 * @brief Get field index_start from kirkwood_sdlog_client_hs message
 *
 * @return Contains the data for the operation
 */
static inline uint32_t mavlink_msg_kirkwood_sdlog_client_hs_get_index_start(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint32_t(msg,  0);
#else
	return mav_get_uint32_t_c2000(&(msg->payload64[0]),  0);
#endif
}

/**
 * @brief Get field index_end from kirkwood_sdlog_client_hs message
 *
 * @return Contains the data for the operation
 */
static inline uint32_t mavlink_msg_kirkwood_sdlog_client_hs_get_index_end(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint32_t(msg,  4);
#else
	return mav_get_uint32_t_c2000(&(msg->payload64[0]),  4);
#endif
}

/**
 * @brief Decode a kirkwood_sdlog_client_hs message into a struct
 *
 * @param msg The message to decode
 * @param kirkwood_sdlog_client_hs C-struct to decode the message contents into
 */
static inline void mavlink_msg_kirkwood_sdlog_client_hs_decode(const mavlink_message_t* msg, mavlink_kirkwood_sdlog_client_hs_t* kirkwood_sdlog_client_hs)
{
#if MAVLINK_NEED_BYTE_SWAP || MAVLINK_C2000
	kirkwood_sdlog_client_hs->index_start = mavlink_msg_kirkwood_sdlog_client_hs_get_index_start(msg);
	kirkwood_sdlog_client_hs->index_end = mavlink_msg_kirkwood_sdlog_client_hs_get_index_end(msg);
	kirkwood_sdlog_client_hs->opcode = mavlink_msg_kirkwood_sdlog_client_hs_get_opcode(msg);
#else
	memcpy(kirkwood_sdlog_client_hs, _MAV_PAYLOAD(msg), MAVLINK_MSG_ID_KIRKWOOD_SDLOG_CLIENT_HS_LEN);
#endif
}
