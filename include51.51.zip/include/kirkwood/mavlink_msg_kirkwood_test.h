// MESSAGE KIRKWOOD_TEST PACKING

#if MAVLINK_C2000
#include "../protocol_c2000.h"
#endif

#define MAVLINK_MSG_ID_KIRKWOOD_TEST 181

typedef struct __mavlink_kirkwood_test_t
{
 uint32_t device; /*<  See KIRKWOOD_CMD_TEST_DEV_ID*/
 uint8_t status; /*< See KIRKWOOD_CMD_TEST_STATUS*/
 uint8_t verbose; /*< 1 for true, 0 for false*/
 uint8_t argc; /*<  See KIRKWOOD_CMD_TEST_DEV_ID*/
 char arg0[20]; /*< command data*/
 char arg1[20]; /*< command data*/
 char arg2[20]; /*< command data*/
 char arg3[20]; /*< command data*/
 char arg4[20]; /*< command data*/
 char arg5[20]; /*< command data*/
 char arg6[20]; /*< command data*/
} mavlink_kirkwood_test_t;

#define MAVLINK_MSG_ID_KIRKWOOD_TEST_LEN 147
#define MAVLINK_MSG_ID_181_LEN 147

#define MAVLINK_MSG_ID_KIRKWOOD_TEST_CRC 38
#define MAVLINK_MSG_ID_181_CRC 38

#define MAVLINK_MSG_KIRKWOOD_TEST_FIELD_ARG0_LEN 20
#define MAVLINK_MSG_KIRKWOOD_TEST_FIELD_ARG1_LEN 20
#define MAVLINK_MSG_KIRKWOOD_TEST_FIELD_ARG2_LEN 20
#define MAVLINK_MSG_KIRKWOOD_TEST_FIELD_ARG3_LEN 20
#define MAVLINK_MSG_KIRKWOOD_TEST_FIELD_ARG4_LEN 20
#define MAVLINK_MSG_KIRKWOOD_TEST_FIELD_ARG5_LEN 20
#define MAVLINK_MSG_KIRKWOOD_TEST_FIELD_ARG6_LEN 20

#define MAVLINK_MESSAGE_INFO_KIRKWOOD_TEST { \
	"KIRKWOOD_TEST", \
	11, \
	{  { "device", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_kirkwood_test_t, device) }, \
         { "status", NULL, MAVLINK_TYPE_UINT8_T, 0, 4, offsetof(mavlink_kirkwood_test_t, status) }, \
         { "verbose", NULL, MAVLINK_TYPE_UINT8_T, 0, 5, offsetof(mavlink_kirkwood_test_t, verbose) }, \
         { "argc", NULL, MAVLINK_TYPE_UINT8_T, 0, 6, offsetof(mavlink_kirkwood_test_t, argc) }, \
         { "arg0", NULL, MAVLINK_TYPE_CHAR, 20, 7, offsetof(mavlink_kirkwood_test_t, arg0) }, \
         { "arg1", NULL, MAVLINK_TYPE_CHAR, 20, 27, offsetof(mavlink_kirkwood_test_t, arg1) }, \
         { "arg2", NULL, MAVLINK_TYPE_CHAR, 20, 47, offsetof(mavlink_kirkwood_test_t, arg2) }, \
         { "arg3", NULL, MAVLINK_TYPE_CHAR, 20, 67, offsetof(mavlink_kirkwood_test_t, arg3) }, \
         { "arg4", NULL, MAVLINK_TYPE_CHAR, 20, 87, offsetof(mavlink_kirkwood_test_t, arg4) }, \
         { "arg5", NULL, MAVLINK_TYPE_CHAR, 20, 107, offsetof(mavlink_kirkwood_test_t, arg5) }, \
         { "arg6", NULL, MAVLINK_TYPE_CHAR, 20, 127, offsetof(mavlink_kirkwood_test_t, arg6) }, \
         } \
}


/**
 * @brief Pack a kirkwood_test message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param device  See KIRKWOOD_CMD_TEST_DEV_ID
 * @param status See KIRKWOOD_CMD_TEST_STATUS
 * @param verbose 1 for true, 0 for false
 * @param argc  See KIRKWOOD_CMD_TEST_DEV_ID
 * @param arg0 command data
 * @param arg1 command data
 * @param arg2 command data
 * @param arg3 command data
 * @param arg4 command data
 * @param arg5 command data
 * @param arg6 command data
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_kirkwood_test_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
						       uint32_t device, uint8_t status, uint8_t verbose, uint8_t argc, const char *arg0, const char *arg1, const char *arg2, const char *arg3, const char *arg4, const char *arg5, const char *arg6)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_TEST_LEN];
	_mav_put_uint32_t(buf, 0, device);
	_mav_put_uint8_t(buf, 4, status);
	_mav_put_uint8_t(buf, 5, verbose);
	_mav_put_uint8_t(buf, 6, argc);
	_mav_put_char_array(buf, 7, arg0, 20);
	_mav_put_char_array(buf, 27, arg1, 20);
	_mav_put_char_array(buf, 47, arg2, 20);
	_mav_put_char_array(buf, 67, arg3, 20);
	_mav_put_char_array(buf, 87, arg4, 20);
	_mav_put_char_array(buf, 107, arg5, 20);
	_mav_put_char_array(buf, 127, arg6, 20);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_KIRKWOOD_TEST_LEN);
#elif MAVLINK_C2000
		mav_put_uint32_t_c2000(&(msg->payload64[0]), 0, device);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 4, status);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 5, verbose);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 6, argc);
	
		mav_put_char_array_c2000(&(msg->payload64[0]), arg0, 7, 20);
		mav_put_char_array_c2000(&(msg->payload64[0]), arg1, 27, 20);
		mav_put_char_array_c2000(&(msg->payload64[0]), arg2, 47, 20);
		mav_put_char_array_c2000(&(msg->payload64[0]), arg3, 67, 20);
		mav_put_char_array_c2000(&(msg->payload64[0]), arg4, 87, 20);
		mav_put_char_array_c2000(&(msg->payload64[0]), arg5, 107, 20);
		mav_put_char_array_c2000(&(msg->payload64[0]), arg6, 127, 20);
	
#else
	mavlink_kirkwood_test_t packet;
	packet.device = device;
	packet.status = status;
	packet.verbose = verbose;
	packet.argc = argc;
	mav_array_memcpy(packet.arg0, arg0, sizeof(char)*20);
	mav_array_memcpy(packet.arg1, arg1, sizeof(char)*20);
	mav_array_memcpy(packet.arg2, arg2, sizeof(char)*20);
	mav_array_memcpy(packet.arg3, arg3, sizeof(char)*20);
	mav_array_memcpy(packet.arg4, arg4, sizeof(char)*20);
	mav_array_memcpy(packet.arg5, arg5, sizeof(char)*20);
	mav_array_memcpy(packet.arg6, arg6, sizeof(char)*20);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_KIRKWOOD_TEST_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_KIRKWOOD_TEST;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_KIRKWOOD_TEST_LEN, MAVLINK_MSG_ID_KIRKWOOD_TEST_CRC);
#else
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_KIRKWOOD_TEST_LEN);
#endif
}

/**
 * @brief Pack a kirkwood_test message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param device  See KIRKWOOD_CMD_TEST_DEV_ID
 * @param status See KIRKWOOD_CMD_TEST_STATUS
 * @param verbose 1 for true, 0 for false
 * @param argc  See KIRKWOOD_CMD_TEST_DEV_ID
 * @param arg0 command data
 * @param arg1 command data
 * @param arg2 command data
 * @param arg3 command data
 * @param arg4 command data
 * @param arg5 command data
 * @param arg6 command data
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_kirkwood_test_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
							   mavlink_message_t* msg,
						           uint32_t device,uint8_t status,uint8_t verbose,uint8_t argc,const char *arg0,const char *arg1,const char *arg2,const char *arg3,const char *arg4,const char *arg5,const char *arg6)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_TEST_LEN];
	_mav_put_uint32_t(buf, 0, device);
	_mav_put_uint8_t(buf, 4, status);
	_mav_put_uint8_t(buf, 5, verbose);
	_mav_put_uint8_t(buf, 6, argc);
	_mav_put_char_array(buf, 7, arg0, 20);
	_mav_put_char_array(buf, 27, arg1, 20);
	_mav_put_char_array(buf, 47, arg2, 20);
	_mav_put_char_array(buf, 67, arg3, 20);
	_mav_put_char_array(buf, 87, arg4, 20);
	_mav_put_char_array(buf, 107, arg5, 20);
	_mav_put_char_array(buf, 127, arg6, 20);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_KIRKWOOD_TEST_LEN);
#else
	mavlink_kirkwood_test_t packet;
	packet.device = device;
	packet.status = status;
	packet.verbose = verbose;
	packet.argc = argc;
	mav_array_memcpy(packet.arg0, arg0, sizeof(char)*20);
	mav_array_memcpy(packet.arg1, arg1, sizeof(char)*20);
	mav_array_memcpy(packet.arg2, arg2, sizeof(char)*20);
	mav_array_memcpy(packet.arg3, arg3, sizeof(char)*20);
	mav_array_memcpy(packet.arg4, arg4, sizeof(char)*20);
	mav_array_memcpy(packet.arg5, arg5, sizeof(char)*20);
	mav_array_memcpy(packet.arg6, arg6, sizeof(char)*20);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_KIRKWOOD_TEST_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_KIRKWOOD_TEST;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_KIRKWOOD_TEST_LEN, MAVLINK_MSG_ID_KIRKWOOD_TEST_CRC);
#else
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_KIRKWOOD_TEST_LEN);
#endif
}

/**
 * @brief Encode a kirkwood_test struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param kirkwood_test C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_kirkwood_test_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_kirkwood_test_t* kirkwood_test)
{
	return mavlink_msg_kirkwood_test_pack(system_id, component_id, msg, kirkwood_test->device, kirkwood_test->status, kirkwood_test->verbose, kirkwood_test->argc, kirkwood_test->arg0, kirkwood_test->arg1, kirkwood_test->arg2, kirkwood_test->arg3, kirkwood_test->arg4, kirkwood_test->arg5, kirkwood_test->arg6);
}

/**
 * @brief Encode a kirkwood_test struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param kirkwood_test C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_kirkwood_test_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_kirkwood_test_t* kirkwood_test)
{
	return mavlink_msg_kirkwood_test_pack_chan(system_id, component_id, chan, msg, kirkwood_test->device, kirkwood_test->status, kirkwood_test->verbose, kirkwood_test->argc, kirkwood_test->arg0, kirkwood_test->arg1, kirkwood_test->arg2, kirkwood_test->arg3, kirkwood_test->arg4, kirkwood_test->arg5, kirkwood_test->arg6);
}

/**
 * @brief Send a kirkwood_test message
 * @param chan MAVLink channel to send the message
 *
 * @param device  See KIRKWOOD_CMD_TEST_DEV_ID
 * @param status See KIRKWOOD_CMD_TEST_STATUS
 * @param verbose 1 for true, 0 for false
 * @param argc  See KIRKWOOD_CMD_TEST_DEV_ID
 * @param arg0 command data
 * @param arg1 command data
 * @param arg2 command data
 * @param arg3 command data
 * @param arg4 command data
 * @param arg5 command data
 * @param arg6 command data
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_kirkwood_test_send(mavlink_channel_t chan, uint32_t device, uint8_t status, uint8_t verbose, uint8_t argc, const char *arg0, const char *arg1, const char *arg2, const char *arg3, const char *arg4, const char *arg5, const char *arg6)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_TEST_LEN];
	_mav_put_uint32_t(buf, 0, device);
	_mav_put_uint8_t(buf, 4, status);
	_mav_put_uint8_t(buf, 5, verbose);
	_mav_put_uint8_t(buf, 6, argc);
	_mav_put_char_array(buf, 7, arg0, 20);
	_mav_put_char_array(buf, 27, arg1, 20);
	_mav_put_char_array(buf, 47, arg2, 20);
	_mav_put_char_array(buf, 67, arg3, 20);
	_mav_put_char_array(buf, 87, arg4, 20);
	_mav_put_char_array(buf, 107, arg5, 20);
	_mav_put_char_array(buf, 127, arg6, 20);
#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_TEST, buf, MAVLINK_MSG_ID_KIRKWOOD_TEST_LEN, MAVLINK_MSG_ID_KIRKWOOD_TEST_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_TEST, buf, MAVLINK_MSG_ID_KIRKWOOD_TEST_LEN);
#endif
#else
	mavlink_kirkwood_test_t packet;
	packet.device = device;
	packet.status = status;
	packet.verbose = verbose;
	packet.argc = argc;
	mav_array_memcpy(packet.arg0, arg0, sizeof(char)*20);
	mav_array_memcpy(packet.arg1, arg1, sizeof(char)*20);
	mav_array_memcpy(packet.arg2, arg2, sizeof(char)*20);
	mav_array_memcpy(packet.arg3, arg3, sizeof(char)*20);
	mav_array_memcpy(packet.arg4, arg4, sizeof(char)*20);
	mav_array_memcpy(packet.arg5, arg5, sizeof(char)*20);
	mav_array_memcpy(packet.arg6, arg6, sizeof(char)*20);
#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_TEST, (const char *)&packet, MAVLINK_MSG_ID_KIRKWOOD_TEST_LEN, MAVLINK_MSG_ID_KIRKWOOD_TEST_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_TEST, (const char *)&packet, MAVLINK_MSG_ID_KIRKWOOD_TEST_LEN);
#endif
#endif
}

#if MAVLINK_MSG_ID_KIRKWOOD_TEST_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_kirkwood_test_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint32_t device, uint8_t status, uint8_t verbose, uint8_t argc, const char *arg0, const char *arg1, const char *arg2, const char *arg3, const char *arg4, const char *arg5, const char *arg6)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char *buf = (char *)msgbuf;
	_mav_put_uint32_t(buf, 0, device);
	_mav_put_uint8_t(buf, 4, status);
	_mav_put_uint8_t(buf, 5, verbose);
	_mav_put_uint8_t(buf, 6, argc);
	_mav_put_char_array(buf, 7, arg0, 20);
	_mav_put_char_array(buf, 27, arg1, 20);
	_mav_put_char_array(buf, 47, arg2, 20);
	_mav_put_char_array(buf, 67, arg3, 20);
	_mav_put_char_array(buf, 87, arg4, 20);
	_mav_put_char_array(buf, 107, arg5, 20);
	_mav_put_char_array(buf, 127, arg6, 20);
#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_TEST, buf, MAVLINK_MSG_ID_KIRKWOOD_TEST_LEN, MAVLINK_MSG_ID_KIRKWOOD_TEST_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_TEST, buf, MAVLINK_MSG_ID_KIRKWOOD_TEST_LEN);
#endif
#else
	mavlink_kirkwood_test_t *packet = (mavlink_kirkwood_test_t *)msgbuf;
	packet->device = device;
	packet->status = status;
	packet->verbose = verbose;
	packet->argc = argc;
	mav_array_memcpy(packet->arg0, arg0, sizeof(char)*20);
	mav_array_memcpy(packet->arg1, arg1, sizeof(char)*20);
	mav_array_memcpy(packet->arg2, arg2, sizeof(char)*20);
	mav_array_memcpy(packet->arg3, arg3, sizeof(char)*20);
	mav_array_memcpy(packet->arg4, arg4, sizeof(char)*20);
	mav_array_memcpy(packet->arg5, arg5, sizeof(char)*20);
	mav_array_memcpy(packet->arg6, arg6, sizeof(char)*20);
#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_TEST, (const char *)packet, MAVLINK_MSG_ID_KIRKWOOD_TEST_LEN, MAVLINK_MSG_ID_KIRKWOOD_TEST_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_TEST, (const char *)packet, MAVLINK_MSG_ID_KIRKWOOD_TEST_LEN);
#endif
#endif
}
#endif

#endif

// MESSAGE KIRKWOOD_TEST UNPACKING


/**
 * @brief Get field device from kirkwood_test message
 *
 * @return  See KIRKWOOD_CMD_TEST_DEV_ID
 */
static inline uint32_t mavlink_msg_kirkwood_test_get_device(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint32_t(msg,  0);
#else
	return mav_get_uint32_t_c2000(&(msg->payload64[0]),  0);
#endif
}

/**
 * @brief Get field status from kirkwood_test message
 *
 * @return See KIRKWOOD_CMD_TEST_STATUS
 */
static inline uint8_t mavlink_msg_kirkwood_test_get_status(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  4);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  4);
#endif
}

/**
 * @brief Get field verbose from kirkwood_test message
 *
 * @return 1 for true, 0 for false
 */
static inline uint8_t mavlink_msg_kirkwood_test_get_verbose(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  5);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  5);
#endif
}

/**
 * @brief Get field argc from kirkwood_test message
 *
 * @return  See KIRKWOOD_CMD_TEST_DEV_ID
 */
static inline uint8_t mavlink_msg_kirkwood_test_get_argc(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  6);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  6);
#endif
}

/**
 * @brief Get field arg0 from kirkwood_test message
 *
 * @return command data
 */
static inline uint16_t mavlink_msg_kirkwood_test_get_arg0(const mavlink_message_t* msg, char *arg0)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_char_array(msg, arg0, 20,  7);
#else
	return mav_get_char_array_c2000(&(msg->payload64[0]), arg0, 20,  7);
#endif
}

/**
 * @brief Get field arg1 from kirkwood_test message
 *
 * @return command data
 */
static inline uint16_t mavlink_msg_kirkwood_test_get_arg1(const mavlink_message_t* msg, char *arg1)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_char_array(msg, arg1, 20,  27);
#else
	return mav_get_char_array_c2000(&(msg->payload64[0]), arg1, 20,  27);
#endif
}

/**
 * @brief Get field arg2 from kirkwood_test message
 *
 * @return command data
 */
static inline uint16_t mavlink_msg_kirkwood_test_get_arg2(const mavlink_message_t* msg, char *arg2)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_char_array(msg, arg2, 20,  47);
#else
	return mav_get_char_array_c2000(&(msg->payload64[0]), arg2, 20,  47);
#endif
}

/**
 * @brief Get field arg3 from kirkwood_test message
 *
 * @return command data
 */
static inline uint16_t mavlink_msg_kirkwood_test_get_arg3(const mavlink_message_t* msg, char *arg3)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_char_array(msg, arg3, 20,  67);
#else
	return mav_get_char_array_c2000(&(msg->payload64[0]), arg3, 20,  67);
#endif
}

/**
 * @brief Get field arg4 from kirkwood_test message
 *
 * @return command data
 */
static inline uint16_t mavlink_msg_kirkwood_test_get_arg4(const mavlink_message_t* msg, char *arg4)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_char_array(msg, arg4, 20,  87);
#else
	return mav_get_char_array_c2000(&(msg->payload64[0]), arg4, 20,  87);
#endif
}

/**
 * @brief Get field arg5 from kirkwood_test message
 *
 * @return command data
 */
static inline uint16_t mavlink_msg_kirkwood_test_get_arg5(const mavlink_message_t* msg, char *arg5)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_char_array(msg, arg5, 20,  107);
#else
	return mav_get_char_array_c2000(&(msg->payload64[0]), arg5, 20,  107);
#endif
}

/**
 * @brief Get field arg6 from kirkwood_test message
 *
 * @return command data
 */
static inline uint16_t mavlink_msg_kirkwood_test_get_arg6(const mavlink_message_t* msg, char *arg6)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_char_array(msg, arg6, 20,  127);
#else
	return mav_get_char_array_c2000(&(msg->payload64[0]), arg6, 20,  127);
#endif
}

/**
 * @brief Decode a kirkwood_test message into a struct
 *
 * @param msg The message to decode
 * @param kirkwood_test C-struct to decode the message contents into
 */
static inline void mavlink_msg_kirkwood_test_decode(const mavlink_message_t* msg, mavlink_kirkwood_test_t* kirkwood_test)
{
#if MAVLINK_NEED_BYTE_SWAP || MAVLINK_C2000
	kirkwood_test->device = mavlink_msg_kirkwood_test_get_device(msg);
	kirkwood_test->status = mavlink_msg_kirkwood_test_get_status(msg);
	kirkwood_test->verbose = mavlink_msg_kirkwood_test_get_verbose(msg);
	kirkwood_test->argc = mavlink_msg_kirkwood_test_get_argc(msg);
	mavlink_msg_kirkwood_test_get_arg0(msg, kirkwood_test->arg0);
	mavlink_msg_kirkwood_test_get_arg1(msg, kirkwood_test->arg1);
	mavlink_msg_kirkwood_test_get_arg2(msg, kirkwood_test->arg2);
	mavlink_msg_kirkwood_test_get_arg3(msg, kirkwood_test->arg3);
	mavlink_msg_kirkwood_test_get_arg4(msg, kirkwood_test->arg4);
	mavlink_msg_kirkwood_test_get_arg5(msg, kirkwood_test->arg5);
	mavlink_msg_kirkwood_test_get_arg6(msg, kirkwood_test->arg6);
#else
	memcpy(kirkwood_test, _MAV_PAYLOAD(msg), MAVLINK_MSG_ID_KIRKWOOD_TEST_LEN);
#endif
}
