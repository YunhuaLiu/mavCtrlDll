// MESSAGE KIRKWOOD_RAW_MAG PACKING

#if MAVLINK_C2000
#include "../protocol_c2000.h"
#endif

#define MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG 173

typedef struct __mavlink_kirkwood_raw_mag_t
{
 uint64_t time_usec; /*< Timestamp (microseconds since UNIX epoch or microseconds since system boot)*/
 float range_ga; /*< Measurement range [Gauss]*/
 float temperature; /*< Temperature of mag*/
 int16_t x_raw; /*< X Magnetic field (raw)*/
 int16_t y_raw; /*< Y Magnetic field (raw)*/
 int16_t z_raw; /*< Z Magnetic field (raw)*/
 uint8_t id; /*< Sensor ID*/
 uint8_t flatline; /*< Indicates if measurements are flatlining*/
} mavlink_kirkwood_raw_mag_t;

#define MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG_LEN 24
#define MAVLINK_MSG_ID_173_LEN 24

#define MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG_CRC 118
#define MAVLINK_MSG_ID_173_CRC 118



#define MAVLINK_MESSAGE_INFO_KIRKWOOD_RAW_MAG { \
	"KIRKWOOD_RAW_MAG", \
	8, \
	{  { "time_usec", NULL, MAVLINK_TYPE_UINT64_T, 0, 0, offsetof(mavlink_kirkwood_raw_mag_t, time_usec) }, \
         { "range_ga", NULL, MAVLINK_TYPE_FLOAT, 0, 8, offsetof(mavlink_kirkwood_raw_mag_t, range_ga) }, \
         { "temperature", NULL, MAVLINK_TYPE_FLOAT, 0, 12, offsetof(mavlink_kirkwood_raw_mag_t, temperature) }, \
         { "x_raw", NULL, MAVLINK_TYPE_INT16_T, 0, 16, offsetof(mavlink_kirkwood_raw_mag_t, x_raw) }, \
         { "y_raw", NULL, MAVLINK_TYPE_INT16_T, 0, 18, offsetof(mavlink_kirkwood_raw_mag_t, y_raw) }, \
         { "z_raw", NULL, MAVLINK_TYPE_INT16_T, 0, 20, offsetof(mavlink_kirkwood_raw_mag_t, z_raw) }, \
         { "id", NULL, MAVLINK_TYPE_UINT8_T, 0, 22, offsetof(mavlink_kirkwood_raw_mag_t, id) }, \
         { "flatline", NULL, MAVLINK_TYPE_UINT8_T, 0, 23, offsetof(mavlink_kirkwood_raw_mag_t, flatline) }, \
         } \
}


/**
 * @brief Pack a kirkwood_raw_mag message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param time_usec Timestamp (microseconds since UNIX epoch or microseconds since system boot)
 * @param id Sensor ID
 * @param x_raw X Magnetic field (raw)
 * @param y_raw Y Magnetic field (raw)
 * @param z_raw Z Magnetic field (raw)
 * @param range_ga Measurement range [Gauss]
 * @param temperature Temperature of mag
 * @param flatline Indicates if measurements are flatlining
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_kirkwood_raw_mag_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
						       uint64_t time_usec, uint8_t id, int16_t x_raw, int16_t y_raw, int16_t z_raw, float range_ga, float temperature, uint8_t flatline)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG_LEN];
	_mav_put_uint64_t(buf, 0, time_usec);
	_mav_put_float(buf, 8, range_ga);
	_mav_put_float(buf, 12, temperature);
	_mav_put_int16_t(buf, 16, x_raw);
	_mav_put_int16_t(buf, 18, y_raw);
	_mav_put_int16_t(buf, 20, z_raw);
	_mav_put_uint8_t(buf, 22, id);
	_mav_put_uint8_t(buf, 23, flatline);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG_LEN);
#elif MAVLINK_C2000
		mav_put_uint64_t_c2000(&(msg->payload64[0]), 0, time_usec);
		mav_put_float_c2000(&(msg->payload64[0]), 8, range_ga);
		mav_put_float_c2000(&(msg->payload64[0]), 12, temperature);
		mav_put_int16_t_c2000(&(msg->payload64[0]), 16, x_raw);
		mav_put_int16_t_c2000(&(msg->payload64[0]), 18, y_raw);
		mav_put_int16_t_c2000(&(msg->payload64[0]), 20, z_raw);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 22, id);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 23, flatline);
	
	
#else
	mavlink_kirkwood_raw_mag_t packet;
	packet.time_usec = time_usec;
	packet.range_ga = range_ga;
	packet.temperature = temperature;
	packet.x_raw = x_raw;
	packet.y_raw = y_raw;
	packet.z_raw = z_raw;
	packet.id = id;
	packet.flatline = flatline;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG_LEN, MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG_CRC);
#else
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG_LEN);
#endif
}

/**
 * @brief Pack a kirkwood_raw_mag message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param time_usec Timestamp (microseconds since UNIX epoch or microseconds since system boot)
 * @param id Sensor ID
 * @param x_raw X Magnetic field (raw)
 * @param y_raw Y Magnetic field (raw)
 * @param z_raw Z Magnetic field (raw)
 * @param range_ga Measurement range [Gauss]
 * @param temperature Temperature of mag
 * @param flatline Indicates if measurements are flatlining
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_kirkwood_raw_mag_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
							   mavlink_message_t* msg,
						           uint64_t time_usec,uint8_t id,int16_t x_raw,int16_t y_raw,int16_t z_raw,float range_ga,float temperature,uint8_t flatline)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG_LEN];
	_mav_put_uint64_t(buf, 0, time_usec);
	_mav_put_float(buf, 8, range_ga);
	_mav_put_float(buf, 12, temperature);
	_mav_put_int16_t(buf, 16, x_raw);
	_mav_put_int16_t(buf, 18, y_raw);
	_mav_put_int16_t(buf, 20, z_raw);
	_mav_put_uint8_t(buf, 22, id);
	_mav_put_uint8_t(buf, 23, flatline);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG_LEN);
#else
	mavlink_kirkwood_raw_mag_t packet;
	packet.time_usec = time_usec;
	packet.range_ga = range_ga;
	packet.temperature = temperature;
	packet.x_raw = x_raw;
	packet.y_raw = y_raw;
	packet.z_raw = z_raw;
	packet.id = id;
	packet.flatline = flatline;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG_LEN, MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG_CRC);
#else
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG_LEN);
#endif
}

/**
 * @brief Encode a kirkwood_raw_mag struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param kirkwood_raw_mag C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_kirkwood_raw_mag_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_kirkwood_raw_mag_t* kirkwood_raw_mag)
{
	return mavlink_msg_kirkwood_raw_mag_pack(system_id, component_id, msg, kirkwood_raw_mag->time_usec, kirkwood_raw_mag->id, kirkwood_raw_mag->x_raw, kirkwood_raw_mag->y_raw, kirkwood_raw_mag->z_raw, kirkwood_raw_mag->range_ga, kirkwood_raw_mag->temperature, kirkwood_raw_mag->flatline);
}

/**
 * @brief Encode a kirkwood_raw_mag struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param kirkwood_raw_mag C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_kirkwood_raw_mag_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_kirkwood_raw_mag_t* kirkwood_raw_mag)
{
	return mavlink_msg_kirkwood_raw_mag_pack_chan(system_id, component_id, chan, msg, kirkwood_raw_mag->time_usec, kirkwood_raw_mag->id, kirkwood_raw_mag->x_raw, kirkwood_raw_mag->y_raw, kirkwood_raw_mag->z_raw, kirkwood_raw_mag->range_ga, kirkwood_raw_mag->temperature, kirkwood_raw_mag->flatline);
}

/**
 * @brief Send a kirkwood_raw_mag message
 * @param chan MAVLink channel to send the message
 *
 * @param time_usec Timestamp (microseconds since UNIX epoch or microseconds since system boot)
 * @param id Sensor ID
 * @param x_raw X Magnetic field (raw)
 * @param y_raw Y Magnetic field (raw)
 * @param z_raw Z Magnetic field (raw)
 * @param range_ga Measurement range [Gauss]
 * @param temperature Temperature of mag
 * @param flatline Indicates if measurements are flatlining
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_kirkwood_raw_mag_send(mavlink_channel_t chan, uint64_t time_usec, uint8_t id, int16_t x_raw, int16_t y_raw, int16_t z_raw, float range_ga, float temperature, uint8_t flatline)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG_LEN];
	_mav_put_uint64_t(buf, 0, time_usec);
	_mav_put_float(buf, 8, range_ga);
	_mav_put_float(buf, 12, temperature);
	_mav_put_int16_t(buf, 16, x_raw);
	_mav_put_int16_t(buf, 18, y_raw);
	_mav_put_int16_t(buf, 20, z_raw);
	_mav_put_uint8_t(buf, 22, id);
	_mav_put_uint8_t(buf, 23, flatline);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG, buf, MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG_LEN, MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG, buf, MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG_LEN);
#endif
#else
	mavlink_kirkwood_raw_mag_t packet;
	packet.time_usec = time_usec;
	packet.range_ga = range_ga;
	packet.temperature = temperature;
	packet.x_raw = x_raw;
	packet.y_raw = y_raw;
	packet.z_raw = z_raw;
	packet.id = id;
	packet.flatline = flatline;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG, (const char *)&packet, MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG_LEN, MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG, (const char *)&packet, MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG_LEN);
#endif
#endif
}

#if MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_kirkwood_raw_mag_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint64_t time_usec, uint8_t id, int16_t x_raw, int16_t y_raw, int16_t z_raw, float range_ga, float temperature, uint8_t flatline)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char *buf = (char *)msgbuf;
	_mav_put_uint64_t(buf, 0, time_usec);
	_mav_put_float(buf, 8, range_ga);
	_mav_put_float(buf, 12, temperature);
	_mav_put_int16_t(buf, 16, x_raw);
	_mav_put_int16_t(buf, 18, y_raw);
	_mav_put_int16_t(buf, 20, z_raw);
	_mav_put_uint8_t(buf, 22, id);
	_mav_put_uint8_t(buf, 23, flatline);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG, buf, MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG_LEN, MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG, buf, MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG_LEN);
#endif
#else
	mavlink_kirkwood_raw_mag_t *packet = (mavlink_kirkwood_raw_mag_t *)msgbuf;
	packet->time_usec = time_usec;
	packet->range_ga = range_ga;
	packet->temperature = temperature;
	packet->x_raw = x_raw;
	packet->y_raw = y_raw;
	packet->z_raw = z_raw;
	packet->id = id;
	packet->flatline = flatline;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG, (const char *)packet, MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG_LEN, MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG, (const char *)packet, MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG_LEN);
#endif
#endif
}
#endif

#endif

// MESSAGE KIRKWOOD_RAW_MAG UNPACKING


/**
 * @brief Get field time_usec from kirkwood_raw_mag message
 *
 * @return Timestamp (microseconds since UNIX epoch or microseconds since system boot)
 */
static inline uint64_t mavlink_msg_kirkwood_raw_mag_get_time_usec(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint64_t(msg,  0);
#else
	return mav_get_uint64_t_c2000(&(msg->payload64[0]),  0);
#endif
}

/**
 * @brief Get field id from kirkwood_raw_mag message
 *
 * @return Sensor ID
 */
static inline uint8_t mavlink_msg_kirkwood_raw_mag_get_id(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  22);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  22);
#endif
}

/**
 * @brief Get field x_raw from kirkwood_raw_mag message
 *
 * @return X Magnetic field (raw)
 */
static inline int16_t mavlink_msg_kirkwood_raw_mag_get_x_raw(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_int16_t(msg,  16);
#else
	return mav_get_int16_t_c2000(&(msg->payload64[0]),  16);
#endif
}

/**
 * @brief Get field y_raw from kirkwood_raw_mag message
 *
 * @return Y Magnetic field (raw)
 */
static inline int16_t mavlink_msg_kirkwood_raw_mag_get_y_raw(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_int16_t(msg,  18);
#else
	return mav_get_int16_t_c2000(&(msg->payload64[0]),  18);
#endif
}

/**
 * @brief Get field z_raw from kirkwood_raw_mag message
 *
 * @return Z Magnetic field (raw)
 */
static inline int16_t mavlink_msg_kirkwood_raw_mag_get_z_raw(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_int16_t(msg,  20);
#else
	return mav_get_int16_t_c2000(&(msg->payload64[0]),  20);
#endif
}

/**
 * @brief Get field range_ga from kirkwood_raw_mag message
 *
 * @return Measurement range [Gauss]
 */
static inline float mavlink_msg_kirkwood_raw_mag_get_range_ga(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  8);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  8);
#endif
}

/**
 * @brief Get field temperature from kirkwood_raw_mag message
 *
 * @return Temperature of mag
 */
static inline float mavlink_msg_kirkwood_raw_mag_get_temperature(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  12);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  12);
#endif
}

/**
 * @brief Get field flatline from kirkwood_raw_mag message
 *
 * @return Indicates if measurements are flatlining
 */
static inline uint8_t mavlink_msg_kirkwood_raw_mag_get_flatline(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  23);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  23);
#endif
}

/**
 * @brief Decode a kirkwood_raw_mag message into a struct
 *
 * @param msg The message to decode
 * @param kirkwood_raw_mag C-struct to decode the message contents into
 */
static inline void mavlink_msg_kirkwood_raw_mag_decode(const mavlink_message_t* msg, mavlink_kirkwood_raw_mag_t* kirkwood_raw_mag)
{
#if MAVLINK_NEED_BYTE_SWAP || MAVLINK_C2000
	kirkwood_raw_mag->time_usec = mavlink_msg_kirkwood_raw_mag_get_time_usec(msg);
	kirkwood_raw_mag->range_ga = mavlink_msg_kirkwood_raw_mag_get_range_ga(msg);
	kirkwood_raw_mag->temperature = mavlink_msg_kirkwood_raw_mag_get_temperature(msg);
	kirkwood_raw_mag->x_raw = mavlink_msg_kirkwood_raw_mag_get_x_raw(msg);
	kirkwood_raw_mag->y_raw = mavlink_msg_kirkwood_raw_mag_get_y_raw(msg);
	kirkwood_raw_mag->z_raw = mavlink_msg_kirkwood_raw_mag_get_z_raw(msg);
	kirkwood_raw_mag->id = mavlink_msg_kirkwood_raw_mag_get_id(msg);
	kirkwood_raw_mag->flatline = mavlink_msg_kirkwood_raw_mag_get_flatline(msg);
#else
	memcpy(kirkwood_raw_mag, _MAV_PAYLOAD(msg), MAVLINK_MSG_ID_KIRKWOOD_RAW_MAG_LEN);
#endif
}
