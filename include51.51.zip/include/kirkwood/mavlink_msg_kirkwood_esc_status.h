// MESSAGE KIRKWOOD_ESC_STATUS PACKING

#if MAVLINK_C2000
#include "../protocol_c2000.h"
#endif

#define MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS 164

typedef struct __mavlink_kirkwood_esc_status_t
{
 uint64_t timestamp; /*< timestamp*/
 uint16_t motor_speed_actual[4]; /*< Actual motor speed as reported by ESC (rpm)*/
 uint16_t motor_speed_request[4]; /*< Requested motor speed (ESC setpoint raw)(rpm)*/
 int16_t esc_temparature[4]; /*< Temperature as reported by ESC (milli Celsius) */
 uint16_t esc_voltage[4]; /*< As reported by ESC (mV)*/
 uint16_t esc_current[4]; /*< As reported by ESC (mA)*/
 uint16_t esc_state[4]; /*< register SW faults as reported by ESC.. Refer to ESC_SW_FAULTS for bitwise fields*/
 uint16_t esc_cmd_fault[4]; /*<  ESC cmd fails (bitwise) 0:speed set cmd fail 1:Periodic read cmd fail*/
 uint8_t state; /*< esc driver state*/
} mavlink_kirkwood_esc_status_t;

#define MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS_LEN 65
#define MAVLINK_MSG_ID_164_LEN 65

#define MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS_CRC 36
#define MAVLINK_MSG_ID_164_CRC 36

#define MAVLINK_MSG_KIRKWOOD_ESC_STATUS_FIELD_MOTOR_SPEED_ACTUAL_LEN 4
#define MAVLINK_MSG_KIRKWOOD_ESC_STATUS_FIELD_MOTOR_SPEED_REQUEST_LEN 4
#define MAVLINK_MSG_KIRKWOOD_ESC_STATUS_FIELD_ESC_TEMPARATURE_LEN 4
#define MAVLINK_MSG_KIRKWOOD_ESC_STATUS_FIELD_ESC_VOLTAGE_LEN 4
#define MAVLINK_MSG_KIRKWOOD_ESC_STATUS_FIELD_ESC_CURRENT_LEN 4
#define MAVLINK_MSG_KIRKWOOD_ESC_STATUS_FIELD_ESC_STATE_LEN 4
#define MAVLINK_MSG_KIRKWOOD_ESC_STATUS_FIELD_ESC_CMD_FAULT_LEN 4

#define MAVLINK_MESSAGE_INFO_KIRKWOOD_ESC_STATUS { \
	"KIRKWOOD_ESC_STATUS", \
	9, \
	{  { "timestamp", NULL, MAVLINK_TYPE_UINT64_T, 0, 0, offsetof(mavlink_kirkwood_esc_status_t, timestamp) }, \
         { "motor_speed_actual", NULL, MAVLINK_TYPE_UINT16_T, 4, 8, offsetof(mavlink_kirkwood_esc_status_t, motor_speed_actual) }, \
         { "motor_speed_request", NULL, MAVLINK_TYPE_UINT16_T, 4, 16, offsetof(mavlink_kirkwood_esc_status_t, motor_speed_request) }, \
         { "esc_temparature", NULL, MAVLINK_TYPE_INT16_T, 4, 24, offsetof(mavlink_kirkwood_esc_status_t, esc_temparature) }, \
         { "esc_voltage", NULL, MAVLINK_TYPE_UINT16_T, 4, 32, offsetof(mavlink_kirkwood_esc_status_t, esc_voltage) }, \
         { "esc_current", NULL, MAVLINK_TYPE_UINT16_T, 4, 40, offsetof(mavlink_kirkwood_esc_status_t, esc_current) }, \
         { "esc_state", NULL, MAVLINK_TYPE_UINT16_T, 4, 48, offsetof(mavlink_kirkwood_esc_status_t, esc_state) }, \
         { "esc_cmd_fault", NULL, MAVLINK_TYPE_UINT16_T, 4, 56, offsetof(mavlink_kirkwood_esc_status_t, esc_cmd_fault) }, \
         { "state", NULL, MAVLINK_TYPE_UINT8_T, 0, 64, offsetof(mavlink_kirkwood_esc_status_t, state) }, \
         } \
}


/**
 * @brief Pack a kirkwood_esc_status message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param timestamp timestamp
 * @param motor_speed_actual Actual motor speed as reported by ESC (rpm)
 * @param motor_speed_request Requested motor speed (ESC setpoint raw)(rpm)
 * @param esc_temparature Temperature as reported by ESC (milli Celsius) 
 * @param esc_voltage As reported by ESC (mV)
 * @param esc_current As reported by ESC (mA)
 * @param esc_state register SW faults as reported by ESC.. Refer to ESC_SW_FAULTS for bitwise fields
 * @param esc_cmd_fault  ESC cmd fails (bitwise) 0:speed set cmd fail 1:Periodic read cmd fail
 * @param state esc driver state
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_kirkwood_esc_status_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
						       uint64_t timestamp, const uint16_t *motor_speed_actual, const uint16_t *motor_speed_request, const int16_t *esc_temparature, const uint16_t *esc_voltage, const uint16_t *esc_current, const uint16_t *esc_state, const uint16_t *esc_cmd_fault, uint8_t state)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS_LEN];
	_mav_put_uint64_t(buf, 0, timestamp);
	_mav_put_uint8_t(buf, 64, state);
	_mav_put_uint16_t_array(buf, 8, motor_speed_actual, 4);
	_mav_put_uint16_t_array(buf, 16, motor_speed_request, 4);
	_mav_put_int16_t_array(buf, 24, esc_temparature, 4);
	_mav_put_uint16_t_array(buf, 32, esc_voltage, 4);
	_mav_put_uint16_t_array(buf, 40, esc_current, 4);
	_mav_put_uint16_t_array(buf, 48, esc_state, 4);
	_mav_put_uint16_t_array(buf, 56, esc_cmd_fault, 4);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS_LEN);
#elif MAVLINK_C2000
		mav_put_uint64_t_c2000(&(msg->payload64[0]), 0, timestamp);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 64, state);
	
		mav_put_uint16_t_array_c2000(&(msg->payload64[0]), motor_speed_actual, 8, 4);
		mav_put_uint16_t_array_c2000(&(msg->payload64[0]), motor_speed_request, 16, 4);
		mav_put_int16_t_array_c2000(&(msg->payload64[0]), esc_temparature, 24, 4);
		mav_put_uint16_t_array_c2000(&(msg->payload64[0]), esc_voltage, 32, 4);
		mav_put_uint16_t_array_c2000(&(msg->payload64[0]), esc_current, 40, 4);
		mav_put_uint16_t_array_c2000(&(msg->payload64[0]), esc_state, 48, 4);
		mav_put_uint16_t_array_c2000(&(msg->payload64[0]), esc_cmd_fault, 56, 4);
	
#else
	mavlink_kirkwood_esc_status_t packet;
	packet.timestamp = timestamp;
	packet.state = state;
	mav_array_memcpy(packet.motor_speed_actual, motor_speed_actual, sizeof(uint16_t)*4);
	mav_array_memcpy(packet.motor_speed_request, motor_speed_request, sizeof(uint16_t)*4);
	mav_array_memcpy(packet.esc_temparature, esc_temparature, sizeof(int16_t)*4);
	mav_array_memcpy(packet.esc_voltage, esc_voltage, sizeof(uint16_t)*4);
	mav_array_memcpy(packet.esc_current, esc_current, sizeof(uint16_t)*4);
	mav_array_memcpy(packet.esc_state, esc_state, sizeof(uint16_t)*4);
	mav_array_memcpy(packet.esc_cmd_fault, esc_cmd_fault, sizeof(uint16_t)*4);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS_LEN, MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS_CRC);
#else
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS_LEN);
#endif
}

/**
 * @brief Pack a kirkwood_esc_status message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param timestamp timestamp
 * @param motor_speed_actual Actual motor speed as reported by ESC (rpm)
 * @param motor_speed_request Requested motor speed (ESC setpoint raw)(rpm)
 * @param esc_temparature Temperature as reported by ESC (milli Celsius) 
 * @param esc_voltage As reported by ESC (mV)
 * @param esc_current As reported by ESC (mA)
 * @param esc_state register SW faults as reported by ESC.. Refer to ESC_SW_FAULTS for bitwise fields
 * @param esc_cmd_fault  ESC cmd fails (bitwise) 0:speed set cmd fail 1:Periodic read cmd fail
 * @param state esc driver state
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_kirkwood_esc_status_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
							   mavlink_message_t* msg,
						           uint64_t timestamp,const uint16_t *motor_speed_actual,const uint16_t *motor_speed_request,const int16_t *esc_temparature,const uint16_t *esc_voltage,const uint16_t *esc_current,const uint16_t *esc_state,const uint16_t *esc_cmd_fault,uint8_t state)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS_LEN];
	_mav_put_uint64_t(buf, 0, timestamp);
	_mav_put_uint8_t(buf, 64, state);
	_mav_put_uint16_t_array(buf, 8, motor_speed_actual, 4);
	_mav_put_uint16_t_array(buf, 16, motor_speed_request, 4);
	_mav_put_int16_t_array(buf, 24, esc_temparature, 4);
	_mav_put_uint16_t_array(buf, 32, esc_voltage, 4);
	_mav_put_uint16_t_array(buf, 40, esc_current, 4);
	_mav_put_uint16_t_array(buf, 48, esc_state, 4);
	_mav_put_uint16_t_array(buf, 56, esc_cmd_fault, 4);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS_LEN);
#else
	mavlink_kirkwood_esc_status_t packet;
	packet.timestamp = timestamp;
	packet.state = state;
	mav_array_memcpy(packet.motor_speed_actual, motor_speed_actual, sizeof(uint16_t)*4);
	mav_array_memcpy(packet.motor_speed_request, motor_speed_request, sizeof(uint16_t)*4);
	mav_array_memcpy(packet.esc_temparature, esc_temparature, sizeof(int16_t)*4);
	mav_array_memcpy(packet.esc_voltage, esc_voltage, sizeof(uint16_t)*4);
	mav_array_memcpy(packet.esc_current, esc_current, sizeof(uint16_t)*4);
	mav_array_memcpy(packet.esc_state, esc_state, sizeof(uint16_t)*4);
	mav_array_memcpy(packet.esc_cmd_fault, esc_cmd_fault, sizeof(uint16_t)*4);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS_LEN, MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS_CRC);
#else
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS_LEN);
#endif
}

/**
 * @brief Encode a kirkwood_esc_status struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param kirkwood_esc_status C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_kirkwood_esc_status_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_kirkwood_esc_status_t* kirkwood_esc_status)
{
	return mavlink_msg_kirkwood_esc_status_pack(system_id, component_id, msg, kirkwood_esc_status->timestamp, kirkwood_esc_status->motor_speed_actual, kirkwood_esc_status->motor_speed_request, kirkwood_esc_status->esc_temparature, kirkwood_esc_status->esc_voltage, kirkwood_esc_status->esc_current, kirkwood_esc_status->esc_state, kirkwood_esc_status->esc_cmd_fault, kirkwood_esc_status->state);
}

/**
 * @brief Encode a kirkwood_esc_status struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param kirkwood_esc_status C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_kirkwood_esc_status_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_kirkwood_esc_status_t* kirkwood_esc_status)
{
	return mavlink_msg_kirkwood_esc_status_pack_chan(system_id, component_id, chan, msg, kirkwood_esc_status->timestamp, kirkwood_esc_status->motor_speed_actual, kirkwood_esc_status->motor_speed_request, kirkwood_esc_status->esc_temparature, kirkwood_esc_status->esc_voltage, kirkwood_esc_status->esc_current, kirkwood_esc_status->esc_state, kirkwood_esc_status->esc_cmd_fault, kirkwood_esc_status->state);
}

/**
 * @brief Send a kirkwood_esc_status message
 * @param chan MAVLink channel to send the message
 *
 * @param timestamp timestamp
 * @param motor_speed_actual Actual motor speed as reported by ESC (rpm)
 * @param motor_speed_request Requested motor speed (ESC setpoint raw)(rpm)
 * @param esc_temparature Temperature as reported by ESC (milli Celsius) 
 * @param esc_voltage As reported by ESC (mV)
 * @param esc_current As reported by ESC (mA)
 * @param esc_state register SW faults as reported by ESC.. Refer to ESC_SW_FAULTS for bitwise fields
 * @param esc_cmd_fault  ESC cmd fails (bitwise) 0:speed set cmd fail 1:Periodic read cmd fail
 * @param state esc driver state
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_kirkwood_esc_status_send(mavlink_channel_t chan, uint64_t timestamp, const uint16_t *motor_speed_actual, const uint16_t *motor_speed_request, const int16_t *esc_temparature, const uint16_t *esc_voltage, const uint16_t *esc_current, const uint16_t *esc_state, const uint16_t *esc_cmd_fault, uint8_t state)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS_LEN];
	_mav_put_uint64_t(buf, 0, timestamp);
	_mav_put_uint8_t(buf, 64, state);
	_mav_put_uint16_t_array(buf, 8, motor_speed_actual, 4);
	_mav_put_uint16_t_array(buf, 16, motor_speed_request, 4);
	_mav_put_int16_t_array(buf, 24, esc_temparature, 4);
	_mav_put_uint16_t_array(buf, 32, esc_voltage, 4);
	_mav_put_uint16_t_array(buf, 40, esc_current, 4);
	_mav_put_uint16_t_array(buf, 48, esc_state, 4);
	_mav_put_uint16_t_array(buf, 56, esc_cmd_fault, 4);
#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS, buf, MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS_LEN, MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS, buf, MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS_LEN);
#endif
#else
	mavlink_kirkwood_esc_status_t packet;
	packet.timestamp = timestamp;
	packet.state = state;
	mav_array_memcpy(packet.motor_speed_actual, motor_speed_actual, sizeof(uint16_t)*4);
	mav_array_memcpy(packet.motor_speed_request, motor_speed_request, sizeof(uint16_t)*4);
	mav_array_memcpy(packet.esc_temparature, esc_temparature, sizeof(int16_t)*4);
	mav_array_memcpy(packet.esc_voltage, esc_voltage, sizeof(uint16_t)*4);
	mav_array_memcpy(packet.esc_current, esc_current, sizeof(uint16_t)*4);
	mav_array_memcpy(packet.esc_state, esc_state, sizeof(uint16_t)*4);
	mav_array_memcpy(packet.esc_cmd_fault, esc_cmd_fault, sizeof(uint16_t)*4);
#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS, (const char *)&packet, MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS_LEN, MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS, (const char *)&packet, MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS_LEN);
#endif
#endif
}

#if MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_kirkwood_esc_status_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint64_t timestamp, const uint16_t *motor_speed_actual, const uint16_t *motor_speed_request, const int16_t *esc_temparature, const uint16_t *esc_voltage, const uint16_t *esc_current, const uint16_t *esc_state, const uint16_t *esc_cmd_fault, uint8_t state)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char *buf = (char *)msgbuf;
	_mav_put_uint64_t(buf, 0, timestamp);
	_mav_put_uint8_t(buf, 64, state);
	_mav_put_uint16_t_array(buf, 8, motor_speed_actual, 4);
	_mav_put_uint16_t_array(buf, 16, motor_speed_request, 4);
	_mav_put_int16_t_array(buf, 24, esc_temparature, 4);
	_mav_put_uint16_t_array(buf, 32, esc_voltage, 4);
	_mav_put_uint16_t_array(buf, 40, esc_current, 4);
	_mav_put_uint16_t_array(buf, 48, esc_state, 4);
	_mav_put_uint16_t_array(buf, 56, esc_cmd_fault, 4);
#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS, buf, MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS_LEN, MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS, buf, MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS_LEN);
#endif
#else
	mavlink_kirkwood_esc_status_t *packet = (mavlink_kirkwood_esc_status_t *)msgbuf;
	packet->timestamp = timestamp;
	packet->state = state;
	mav_array_memcpy(packet->motor_speed_actual, motor_speed_actual, sizeof(uint16_t)*4);
	mav_array_memcpy(packet->motor_speed_request, motor_speed_request, sizeof(uint16_t)*4);
	mav_array_memcpy(packet->esc_temparature, esc_temparature, sizeof(int16_t)*4);
	mav_array_memcpy(packet->esc_voltage, esc_voltage, sizeof(uint16_t)*4);
	mav_array_memcpy(packet->esc_current, esc_current, sizeof(uint16_t)*4);
	mav_array_memcpy(packet->esc_state, esc_state, sizeof(uint16_t)*4);
	mav_array_memcpy(packet->esc_cmd_fault, esc_cmd_fault, sizeof(uint16_t)*4);
#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS, (const char *)packet, MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS_LEN, MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS, (const char *)packet, MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS_LEN);
#endif
#endif
}
#endif

#endif

// MESSAGE KIRKWOOD_ESC_STATUS UNPACKING


/**
 * @brief Get field timestamp from kirkwood_esc_status message
 *
 * @return timestamp
 */
static inline uint64_t mavlink_msg_kirkwood_esc_status_get_timestamp(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint64_t(msg,  0);
#else
	return mav_get_uint64_t_c2000(&(msg->payload64[0]),  0);
#endif
}

/**
 * @brief Get field motor_speed_actual from kirkwood_esc_status message
 *
 * @return Actual motor speed as reported by ESC (rpm)
 */
static inline uint16_t mavlink_msg_kirkwood_esc_status_get_motor_speed_actual(const mavlink_message_t* msg, uint16_t *motor_speed_actual)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint16_t_array(msg, motor_speed_actual, 4,  8);
#else
	return mav_get_uint16_t_array_c2000(&(msg->payload64[0]), motor_speed_actual, 4,  8);
#endif
}

/**
 * @brief Get field motor_speed_request from kirkwood_esc_status message
 *
 * @return Requested motor speed (ESC setpoint raw)(rpm)
 */
static inline uint16_t mavlink_msg_kirkwood_esc_status_get_motor_speed_request(const mavlink_message_t* msg, uint16_t *motor_speed_request)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint16_t_array(msg, motor_speed_request, 4,  16);
#else
	return mav_get_uint16_t_array_c2000(&(msg->payload64[0]), motor_speed_request, 4,  16);
#endif
}

/**
 * @brief Get field esc_temparature from kirkwood_esc_status message
 *
 * @return Temperature as reported by ESC (milli Celsius) 
 */
static inline uint16_t mavlink_msg_kirkwood_esc_status_get_esc_temparature(const mavlink_message_t* msg, int16_t *esc_temparature)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_int16_t_array(msg, esc_temparature, 4,  24);
#else
	return mav_get_int16_t_array_c2000(&(msg->payload64[0]), esc_temparature, 4,  24);
#endif
}

/**
 * @brief Get field esc_voltage from kirkwood_esc_status message
 *
 * @return As reported by ESC (mV)
 */
static inline uint16_t mavlink_msg_kirkwood_esc_status_get_esc_voltage(const mavlink_message_t* msg, uint16_t *esc_voltage)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint16_t_array(msg, esc_voltage, 4,  32);
#else
	return mav_get_uint16_t_array_c2000(&(msg->payload64[0]), esc_voltage, 4,  32);
#endif
}

/**
 * @brief Get field esc_current from kirkwood_esc_status message
 *
 * @return As reported by ESC (mA)
 */
static inline uint16_t mavlink_msg_kirkwood_esc_status_get_esc_current(const mavlink_message_t* msg, uint16_t *esc_current)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint16_t_array(msg, esc_current, 4,  40);
#else
	return mav_get_uint16_t_array_c2000(&(msg->payload64[0]), esc_current, 4,  40);
#endif
}

/**
 * @brief Get field esc_state from kirkwood_esc_status message
 *
 * @return register SW faults as reported by ESC.. Refer to ESC_SW_FAULTS for bitwise fields
 */
static inline uint16_t mavlink_msg_kirkwood_esc_status_get_esc_state(const mavlink_message_t* msg, uint16_t *esc_state)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint16_t_array(msg, esc_state, 4,  48);
#else
	return mav_get_uint16_t_array_c2000(&(msg->payload64[0]), esc_state, 4,  48);
#endif
}

/**
 * @brief Get field esc_cmd_fault from kirkwood_esc_status message
 *
 * @return  ESC cmd fails (bitwise) 0:speed set cmd fail 1:Periodic read cmd fail
 */
static inline uint16_t mavlink_msg_kirkwood_esc_status_get_esc_cmd_fault(const mavlink_message_t* msg, uint16_t *esc_cmd_fault)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint16_t_array(msg, esc_cmd_fault, 4,  56);
#else
	return mav_get_uint16_t_array_c2000(&(msg->payload64[0]), esc_cmd_fault, 4,  56);
#endif
}

/**
 * @brief Get field state from kirkwood_esc_status message
 *
 * @return esc driver state
 */
static inline uint8_t mavlink_msg_kirkwood_esc_status_get_state(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  64);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  64);
#endif
}

/**
 * @brief Decode a kirkwood_esc_status message into a struct
 *
 * @param msg The message to decode
 * @param kirkwood_esc_status C-struct to decode the message contents into
 */
static inline void mavlink_msg_kirkwood_esc_status_decode(const mavlink_message_t* msg, mavlink_kirkwood_esc_status_t* kirkwood_esc_status)
{
#if MAVLINK_NEED_BYTE_SWAP || MAVLINK_C2000
	kirkwood_esc_status->timestamp = mavlink_msg_kirkwood_esc_status_get_timestamp(msg);
	mavlink_msg_kirkwood_esc_status_get_motor_speed_actual(msg, kirkwood_esc_status->motor_speed_actual);
	mavlink_msg_kirkwood_esc_status_get_motor_speed_request(msg, kirkwood_esc_status->motor_speed_request);
	mavlink_msg_kirkwood_esc_status_get_esc_temparature(msg, kirkwood_esc_status->esc_temparature);
	mavlink_msg_kirkwood_esc_status_get_esc_voltage(msg, kirkwood_esc_status->esc_voltage);
	mavlink_msg_kirkwood_esc_status_get_esc_current(msg, kirkwood_esc_status->esc_current);
	mavlink_msg_kirkwood_esc_status_get_esc_state(msg, kirkwood_esc_status->esc_state);
	mavlink_msg_kirkwood_esc_status_get_esc_cmd_fault(msg, kirkwood_esc_status->esc_cmd_fault);
	kirkwood_esc_status->state = mavlink_msg_kirkwood_esc_status_get_state(msg);
#else
	memcpy(kirkwood_esc_status, _MAV_PAYLOAD(msg), MAVLINK_MSG_ID_KIRKWOOD_ESC_STATUS_LEN);
#endif
}
