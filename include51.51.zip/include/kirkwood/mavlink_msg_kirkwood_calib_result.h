// MESSAGE KIRKWOOD_CALIB_RESULT PACKING

#if MAVLINK_C2000
#include "../protocol_c2000.h"
#endif

#define MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT 185

typedef struct __mavlink_kirkwood_calib_result_t
{
 float offset[3]; /*< x,y,z offset for mag/accel*/
 float scale[3]; /*< rotation for mag, x,y,z offset 2 for accel*/
 uint8_t result; /*< Calibration result. See KIRKWOOD_CALIB_RESULT enum*/
 uint8_t device_type; /*< Calibration device. See KIRKWOOD_CMD_GP_CAL param index1*/
} mavlink_kirkwood_calib_result_t;

#define MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT_LEN 26
#define MAVLINK_MSG_ID_185_LEN 26

#define MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT_CRC 5
#define MAVLINK_MSG_ID_185_CRC 5

#define MAVLINK_MSG_KIRKWOOD_CALIB_RESULT_FIELD_OFFSET_LEN 3
#define MAVLINK_MSG_KIRKWOOD_CALIB_RESULT_FIELD_SCALE_LEN 3

#define MAVLINK_MESSAGE_INFO_KIRKWOOD_CALIB_RESULT { \
	"KIRKWOOD_CALIB_RESULT", \
	4, \
	{  { "offset", NULL, MAVLINK_TYPE_FLOAT, 3, 0, offsetof(mavlink_kirkwood_calib_result_t, offset) }, \
         { "scale", NULL, MAVLINK_TYPE_FLOAT, 3, 12, offsetof(mavlink_kirkwood_calib_result_t, scale) }, \
         { "result", NULL, MAVLINK_TYPE_UINT8_T, 0, 24, offsetof(mavlink_kirkwood_calib_result_t, result) }, \
         { "device_type", NULL, MAVLINK_TYPE_UINT8_T, 0, 25, offsetof(mavlink_kirkwood_calib_result_t, device_type) }, \
         } \
}


/**
 * @brief Pack a kirkwood_calib_result message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param result Calibration result. See KIRKWOOD_CALIB_RESULT enum
 * @param device_type Calibration device. See KIRKWOOD_CMD_GP_CAL param index1
 * @param offset x,y,z offset for mag/accel
 * @param scale rotation for mag, x,y,z offset 2 for accel
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_kirkwood_calib_result_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
						       uint8_t result, uint8_t device_type, const float *offset, const float *scale)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT_LEN];
	_mav_put_uint8_t(buf, 24, result);
	_mav_put_uint8_t(buf, 25, device_type);
	_mav_put_float_array(buf, 0, offset, 3);
	_mav_put_float_array(buf, 12, scale, 3);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT_LEN);
#elif MAVLINK_C2000
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 24, result);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 25, device_type);
	
		mav_put_float_array_c2000(&(msg->payload64[0]), offset, 0, 3);
		mav_put_float_array_c2000(&(msg->payload64[0]), scale, 12, 3);
	
#else
	mavlink_kirkwood_calib_result_t packet;
	packet.result = result;
	packet.device_type = device_type;
	mav_array_memcpy(packet.offset, offset, sizeof(float)*3);
	mav_array_memcpy(packet.scale, scale, sizeof(float)*3);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT_LEN, MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT_CRC);
#else
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT_LEN);
#endif
}

/**
 * @brief Pack a kirkwood_calib_result message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param result Calibration result. See KIRKWOOD_CALIB_RESULT enum
 * @param device_type Calibration device. See KIRKWOOD_CMD_GP_CAL param index1
 * @param offset x,y,z offset for mag/accel
 * @param scale rotation for mag, x,y,z offset 2 for accel
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_kirkwood_calib_result_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
							   mavlink_message_t* msg,
						           uint8_t result,uint8_t device_type,const float *offset,const float *scale)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT_LEN];
	_mav_put_uint8_t(buf, 24, result);
	_mav_put_uint8_t(buf, 25, device_type);
	_mav_put_float_array(buf, 0, offset, 3);
	_mav_put_float_array(buf, 12, scale, 3);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT_LEN);
#else
	mavlink_kirkwood_calib_result_t packet;
	packet.result = result;
	packet.device_type = device_type;
	mav_array_memcpy(packet.offset, offset, sizeof(float)*3);
	mav_array_memcpy(packet.scale, scale, sizeof(float)*3);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT_LEN, MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT_CRC);
#else
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT_LEN);
#endif
}

/**
 * @brief Encode a kirkwood_calib_result struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param kirkwood_calib_result C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_kirkwood_calib_result_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_kirkwood_calib_result_t* kirkwood_calib_result)
{
	return mavlink_msg_kirkwood_calib_result_pack(system_id, component_id, msg, kirkwood_calib_result->result, kirkwood_calib_result->device_type, kirkwood_calib_result->offset, kirkwood_calib_result->scale);
}

/**
 * @brief Encode a kirkwood_calib_result struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param kirkwood_calib_result C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_kirkwood_calib_result_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_kirkwood_calib_result_t* kirkwood_calib_result)
{
	return mavlink_msg_kirkwood_calib_result_pack_chan(system_id, component_id, chan, msg, kirkwood_calib_result->result, kirkwood_calib_result->device_type, kirkwood_calib_result->offset, kirkwood_calib_result->scale);
}

/**
 * @brief Send a kirkwood_calib_result message
 * @param chan MAVLink channel to send the message
 *
 * @param result Calibration result. See KIRKWOOD_CALIB_RESULT enum
 * @param device_type Calibration device. See KIRKWOOD_CMD_GP_CAL param index1
 * @param offset x,y,z offset for mag/accel
 * @param scale rotation for mag, x,y,z offset 2 for accel
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_kirkwood_calib_result_send(mavlink_channel_t chan, uint8_t result, uint8_t device_type, const float *offset, const float *scale)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT_LEN];
	_mav_put_uint8_t(buf, 24, result);
	_mav_put_uint8_t(buf, 25, device_type);
	_mav_put_float_array(buf, 0, offset, 3);
	_mav_put_float_array(buf, 12, scale, 3);
#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT, buf, MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT_LEN, MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT, buf, MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT_LEN);
#endif
#else
	mavlink_kirkwood_calib_result_t packet;
	packet.result = result;
	packet.device_type = device_type;
	mav_array_memcpy(packet.offset, offset, sizeof(float)*3);
	mav_array_memcpy(packet.scale, scale, sizeof(float)*3);
#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT, (const char *)&packet, MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT_LEN, MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT, (const char *)&packet, MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT_LEN);
#endif
#endif
}

#if MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_kirkwood_calib_result_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint8_t result, uint8_t device_type, const float *offset, const float *scale)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char *buf = (char *)msgbuf;
	_mav_put_uint8_t(buf, 24, result);
	_mav_put_uint8_t(buf, 25, device_type);
	_mav_put_float_array(buf, 0, offset, 3);
	_mav_put_float_array(buf, 12, scale, 3);
#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT, buf, MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT_LEN, MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT, buf, MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT_LEN);
#endif
#else
	mavlink_kirkwood_calib_result_t *packet = (mavlink_kirkwood_calib_result_t *)msgbuf;
	packet->result = result;
	packet->device_type = device_type;
	mav_array_memcpy(packet->offset, offset, sizeof(float)*3);
	mav_array_memcpy(packet->scale, scale, sizeof(float)*3);
#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT, (const char *)packet, MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT_LEN, MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT, (const char *)packet, MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT_LEN);
#endif
#endif
}
#endif

#endif

// MESSAGE KIRKWOOD_CALIB_RESULT UNPACKING


/**
 * @brief Get field result from kirkwood_calib_result message
 *
 * @return Calibration result. See KIRKWOOD_CALIB_RESULT enum
 */
static inline uint8_t mavlink_msg_kirkwood_calib_result_get_result(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  24);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  24);
#endif
}

/**
 * @brief Get field device_type from kirkwood_calib_result message
 *
 * @return Calibration device. See KIRKWOOD_CMD_GP_CAL param index1
 */
static inline uint8_t mavlink_msg_kirkwood_calib_result_get_device_type(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  25);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  25);
#endif
}

/**
 * @brief Get field offset from kirkwood_calib_result message
 *
 * @return x,y,z offset for mag/accel
 */
static inline uint16_t mavlink_msg_kirkwood_calib_result_get_offset(const mavlink_message_t* msg, float *offset)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float_array(msg, offset, 3,  0);
#else
	return mav_get_float_array_c2000(&(msg->payload64[0]), offset, 3,  0);
#endif
}

/**
 * @brief Get field scale from kirkwood_calib_result message
 *
 * @return rotation for mag, x,y,z offset 2 for accel
 */
static inline uint16_t mavlink_msg_kirkwood_calib_result_get_scale(const mavlink_message_t* msg, float *scale)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float_array(msg, scale, 3,  12);
#else
	return mav_get_float_array_c2000(&(msg->payload64[0]), scale, 3,  12);
#endif
}

/**
 * @brief Decode a kirkwood_calib_result message into a struct
 *
 * @param msg The message to decode
 * @param kirkwood_calib_result C-struct to decode the message contents into
 */
static inline void mavlink_msg_kirkwood_calib_result_decode(const mavlink_message_t* msg, mavlink_kirkwood_calib_result_t* kirkwood_calib_result)
{
#if MAVLINK_NEED_BYTE_SWAP || MAVLINK_C2000
	mavlink_msg_kirkwood_calib_result_get_offset(msg, kirkwood_calib_result->offset);
	mavlink_msg_kirkwood_calib_result_get_scale(msg, kirkwood_calib_result->scale);
	kirkwood_calib_result->result = mavlink_msg_kirkwood_calib_result_get_result(msg);
	kirkwood_calib_result->device_type = mavlink_msg_kirkwood_calib_result_get_device_type(msg);
#else
	memcpy(kirkwood_calib_result, _MAV_PAYLOAD(msg), MAVLINK_MSG_ID_KIRKWOOD_CALIB_RESULT_LEN);
#endif
}
