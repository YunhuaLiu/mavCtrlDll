// MESSAGE KIRKWOOD_EVENT PACKING

#if MAVLINK_C2000
#include "../protocol_c2000.h"
#endif

#define MAVLINK_MSG_ID_KIRKWOOD_EVENT 160

typedef struct __mavlink_kirkwood_event_t
{
 uint64_t timestamp; /*< Time, in us since system boot, at which the event was triggered*/
 uint32_t event; /*< Event as described in kw_event.h*/
} mavlink_kirkwood_event_t;

#define MAVLINK_MSG_ID_KIRKWOOD_EVENT_LEN 12
#define MAVLINK_MSG_ID_160_LEN 12

#define MAVLINK_MSG_ID_KIRKWOOD_EVENT_CRC 12
#define MAVLINK_MSG_ID_160_CRC 12



#define MAVLINK_MESSAGE_INFO_KIRKWOOD_EVENT { \
	"KIRKWOOD_EVENT", \
	2, \
	{  { "timestamp", NULL, MAVLINK_TYPE_UINT64_T, 0, 0, offsetof(mavlink_kirkwood_event_t, timestamp) }, \
         { "event", NULL, MAVLINK_TYPE_UINT32_T, 0, 8, offsetof(mavlink_kirkwood_event_t, event) }, \
         } \
}


/**
 * @brief Pack a kirkwood_event message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param event Event as described in kw_event.h
 * @param timestamp Time, in us since system boot, at which the event was triggered
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_kirkwood_event_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
						       uint32_t event, uint64_t timestamp)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_EVENT_LEN];
	_mav_put_uint64_t(buf, 0, timestamp);
	_mav_put_uint32_t(buf, 8, event);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_KIRKWOOD_EVENT_LEN);
#elif MAVLINK_C2000
		mav_put_uint64_t_c2000(&(msg->payload64[0]), 0, timestamp);
		mav_put_uint32_t_c2000(&(msg->payload64[0]), 8, event);
	
	
#else
	mavlink_kirkwood_event_t packet;
	packet.timestamp = timestamp;
	packet.event = event;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_KIRKWOOD_EVENT_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_KIRKWOOD_EVENT;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_KIRKWOOD_EVENT_LEN, MAVLINK_MSG_ID_KIRKWOOD_EVENT_CRC);
#else
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_KIRKWOOD_EVENT_LEN);
#endif
}

/**
 * @brief Pack a kirkwood_event message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param event Event as described in kw_event.h
 * @param timestamp Time, in us since system boot, at which the event was triggered
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_kirkwood_event_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
							   mavlink_message_t* msg,
						           uint32_t event,uint64_t timestamp)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_EVENT_LEN];
	_mav_put_uint64_t(buf, 0, timestamp);
	_mav_put_uint32_t(buf, 8, event);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_KIRKWOOD_EVENT_LEN);
#else
	mavlink_kirkwood_event_t packet;
	packet.timestamp = timestamp;
	packet.event = event;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_KIRKWOOD_EVENT_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_KIRKWOOD_EVENT;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_KIRKWOOD_EVENT_LEN, MAVLINK_MSG_ID_KIRKWOOD_EVENT_CRC);
#else
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_KIRKWOOD_EVENT_LEN);
#endif
}

/**
 * @brief Encode a kirkwood_event struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param kirkwood_event C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_kirkwood_event_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_kirkwood_event_t* kirkwood_event)
{
	return mavlink_msg_kirkwood_event_pack(system_id, component_id, msg, kirkwood_event->event, kirkwood_event->timestamp);
}

/**
 * @brief Encode a kirkwood_event struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param kirkwood_event C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_kirkwood_event_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_kirkwood_event_t* kirkwood_event)
{
	return mavlink_msg_kirkwood_event_pack_chan(system_id, component_id, chan, msg, kirkwood_event->event, kirkwood_event->timestamp);
}

/**
 * @brief Send a kirkwood_event message
 * @param chan MAVLink channel to send the message
 *
 * @param event Event as described in kw_event.h
 * @param timestamp Time, in us since system boot, at which the event was triggered
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_kirkwood_event_send(mavlink_channel_t chan, uint32_t event, uint64_t timestamp)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_EVENT_LEN];
	_mav_put_uint64_t(buf, 0, timestamp);
	_mav_put_uint32_t(buf, 8, event);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_EVENT, buf, MAVLINK_MSG_ID_KIRKWOOD_EVENT_LEN, MAVLINK_MSG_ID_KIRKWOOD_EVENT_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_EVENT, buf, MAVLINK_MSG_ID_KIRKWOOD_EVENT_LEN);
#endif
#else
	mavlink_kirkwood_event_t packet;
	packet.timestamp = timestamp;
	packet.event = event;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_EVENT, (const char *)&packet, MAVLINK_MSG_ID_KIRKWOOD_EVENT_LEN, MAVLINK_MSG_ID_KIRKWOOD_EVENT_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_EVENT, (const char *)&packet, MAVLINK_MSG_ID_KIRKWOOD_EVENT_LEN);
#endif
#endif
}

#if MAVLINK_MSG_ID_KIRKWOOD_EVENT_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_kirkwood_event_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint32_t event, uint64_t timestamp)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char *buf = (char *)msgbuf;
	_mav_put_uint64_t(buf, 0, timestamp);
	_mav_put_uint32_t(buf, 8, event);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_EVENT, buf, MAVLINK_MSG_ID_KIRKWOOD_EVENT_LEN, MAVLINK_MSG_ID_KIRKWOOD_EVENT_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_EVENT, buf, MAVLINK_MSG_ID_KIRKWOOD_EVENT_LEN);
#endif
#else
	mavlink_kirkwood_event_t *packet = (mavlink_kirkwood_event_t *)msgbuf;
	packet->timestamp = timestamp;
	packet->event = event;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_EVENT, (const char *)packet, MAVLINK_MSG_ID_KIRKWOOD_EVENT_LEN, MAVLINK_MSG_ID_KIRKWOOD_EVENT_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_EVENT, (const char *)packet, MAVLINK_MSG_ID_KIRKWOOD_EVENT_LEN);
#endif
#endif
}
#endif

#endif

// MESSAGE KIRKWOOD_EVENT UNPACKING


/**
 * @brief Get field event from kirkwood_event message
 *
 * @return Event as described in kw_event.h
 */
static inline uint32_t mavlink_msg_kirkwood_event_get_event(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint32_t(msg,  8);
#else
	return mav_get_uint32_t_c2000(&(msg->payload64[0]),  8);
#endif
}

/**
 * @brief Get field timestamp from kirkwood_event message
 *
 * @return Time, in us since system boot, at which the event was triggered
 */
static inline uint64_t mavlink_msg_kirkwood_event_get_timestamp(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint64_t(msg,  0);
#else
	return mav_get_uint64_t_c2000(&(msg->payload64[0]),  0);
#endif
}

/**
 * @brief Decode a kirkwood_event message into a struct
 *
 * @param msg The message to decode
 * @param kirkwood_event C-struct to decode the message contents into
 */
static inline void mavlink_msg_kirkwood_event_decode(const mavlink_message_t* msg, mavlink_kirkwood_event_t* kirkwood_event)
{
#if MAVLINK_NEED_BYTE_SWAP || MAVLINK_C2000
	kirkwood_event->timestamp = mavlink_msg_kirkwood_event_get_timestamp(msg);
	kirkwood_event->event = mavlink_msg_kirkwood_event_get_event(msg);
#else
	memcpy(kirkwood_event, _MAV_PAYLOAD(msg), MAVLINK_MSG_ID_KIRKWOOD_EVENT_LEN);
#endif
}
