// MESSAGE KIRKWOOD_SYSTEM_HEALTH PACKING

#if MAVLINK_C2000
#include "../protocol_c2000.h"
#endif

#define MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH 183

typedef struct __mavlink_kirkwood_system_health_t
{
 uint8_t accel; /*< accelorometer status*/
 uint8_t mag; /*< magnetometer status*/
 uint8_t gyro; /*< gyrometer status*/
 uint8_t baro; /*< barometer status*/
 uint8_t gps; /*< gps status*/
 uint8_t rc; /*< rc status*/
 uint8_t rc_override; /*< rc override status*/
 uint8_t battery; /*< battery status*/
 uint8_t gimbal; /*< gimbal status*/
 uint8_t esc; /*< esc status*/
 uint8_t global_pos; /*< global position status*/
 uint8_t local_pos; /*< local position status*/
 uint8_t gps_pos; /*< gps position status*/
 uint8_t home_pos; /*< home position status*/
 uint8_t arms_deployed; /*< arms deployment status - yes(1)/no(0)*/
 uint8_t landing_gear_deployed; /*< landing gear deployment status - yes(1)/no(0)*/
 uint8_t upright; /*< upright status yes(0)/no(1)*/
 uint8_t nfz; /*< nfz status*/
} mavlink_kirkwood_system_health_t;

#define MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH_LEN 18
#define MAVLINK_MSG_ID_183_LEN 18

#define MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH_CRC 182
#define MAVLINK_MSG_ID_183_CRC 182



#define MAVLINK_MESSAGE_INFO_KIRKWOOD_SYSTEM_HEALTH { \
	"KIRKWOOD_SYSTEM_HEALTH", \
	18, \
	{  { "accel", NULL, MAVLINK_TYPE_UINT8_T, 0, 0, offsetof(mavlink_kirkwood_system_health_t, accel) }, \
         { "mag", NULL, MAVLINK_TYPE_UINT8_T, 0, 1, offsetof(mavlink_kirkwood_system_health_t, mag) }, \
         { "gyro", NULL, MAVLINK_TYPE_UINT8_T, 0, 2, offsetof(mavlink_kirkwood_system_health_t, gyro) }, \
         { "baro", NULL, MAVLINK_TYPE_UINT8_T, 0, 3, offsetof(mavlink_kirkwood_system_health_t, baro) }, \
         { "gps", NULL, MAVLINK_TYPE_UINT8_T, 0, 4, offsetof(mavlink_kirkwood_system_health_t, gps) }, \
         { "rc", NULL, MAVLINK_TYPE_UINT8_T, 0, 5, offsetof(mavlink_kirkwood_system_health_t, rc) }, \
         { "rc_override", NULL, MAVLINK_TYPE_UINT8_T, 0, 6, offsetof(mavlink_kirkwood_system_health_t, rc_override) }, \
         { "battery", NULL, MAVLINK_TYPE_UINT8_T, 0, 7, offsetof(mavlink_kirkwood_system_health_t, battery) }, \
         { "gimbal", NULL, MAVLINK_TYPE_UINT8_T, 0, 8, offsetof(mavlink_kirkwood_system_health_t, gimbal) }, \
         { "esc", NULL, MAVLINK_TYPE_UINT8_T, 0, 9, offsetof(mavlink_kirkwood_system_health_t, esc) }, \
         { "global_pos", NULL, MAVLINK_TYPE_UINT8_T, 0, 10, offsetof(mavlink_kirkwood_system_health_t, global_pos) }, \
         { "local_pos", NULL, MAVLINK_TYPE_UINT8_T, 0, 11, offsetof(mavlink_kirkwood_system_health_t, local_pos) }, \
         { "gps_pos", NULL, MAVLINK_TYPE_UINT8_T, 0, 12, offsetof(mavlink_kirkwood_system_health_t, gps_pos) }, \
         { "home_pos", NULL, MAVLINK_TYPE_UINT8_T, 0, 13, offsetof(mavlink_kirkwood_system_health_t, home_pos) }, \
         { "arms_deployed", NULL, MAVLINK_TYPE_UINT8_T, 0, 14, offsetof(mavlink_kirkwood_system_health_t, arms_deployed) }, \
         { "landing_gear_deployed", NULL, MAVLINK_TYPE_UINT8_T, 0, 15, offsetof(mavlink_kirkwood_system_health_t, landing_gear_deployed) }, \
         { "upright", NULL, MAVLINK_TYPE_UINT8_T, 0, 16, offsetof(mavlink_kirkwood_system_health_t, upright) }, \
         { "nfz", NULL, MAVLINK_TYPE_UINT8_T, 0, 17, offsetof(mavlink_kirkwood_system_health_t, nfz) }, \
         } \
}


/**
 * @brief Pack a kirkwood_system_health message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param accel accelorometer status
 * @param mag magnetometer status
 * @param gyro gyrometer status
 * @param baro barometer status
 * @param gps gps status
 * @param rc rc status
 * @param rc_override rc override status
 * @param battery battery status
 * @param gimbal gimbal status
 * @param esc esc status
 * @param global_pos global position status
 * @param local_pos local position status
 * @param gps_pos gps position status
 * @param home_pos home position status
 * @param arms_deployed arms deployment status - yes(1)/no(0)
 * @param landing_gear_deployed landing gear deployment status - yes(1)/no(0)
 * @param upright upright status yes(0)/no(1)
 * @param nfz nfz status
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_kirkwood_system_health_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
						       uint8_t accel, uint8_t mag, uint8_t gyro, uint8_t baro, uint8_t gps, uint8_t rc, uint8_t rc_override, uint8_t battery, uint8_t gimbal, uint8_t esc, uint8_t global_pos, uint8_t local_pos, uint8_t gps_pos, uint8_t home_pos, uint8_t arms_deployed, uint8_t landing_gear_deployed, uint8_t upright, uint8_t nfz)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH_LEN];
	_mav_put_uint8_t(buf, 0, accel);
	_mav_put_uint8_t(buf, 1, mag);
	_mav_put_uint8_t(buf, 2, gyro);
	_mav_put_uint8_t(buf, 3, baro);
	_mav_put_uint8_t(buf, 4, gps);
	_mav_put_uint8_t(buf, 5, rc);
	_mav_put_uint8_t(buf, 6, rc_override);
	_mav_put_uint8_t(buf, 7, battery);
	_mav_put_uint8_t(buf, 8, gimbal);
	_mav_put_uint8_t(buf, 9, esc);
	_mav_put_uint8_t(buf, 10, global_pos);
	_mav_put_uint8_t(buf, 11, local_pos);
	_mav_put_uint8_t(buf, 12, gps_pos);
	_mav_put_uint8_t(buf, 13, home_pos);
	_mav_put_uint8_t(buf, 14, arms_deployed);
	_mav_put_uint8_t(buf, 15, landing_gear_deployed);
	_mav_put_uint8_t(buf, 16, upright);
	_mav_put_uint8_t(buf, 17, nfz);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH_LEN);
#elif MAVLINK_C2000
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 0, accel);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 1, mag);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 2, gyro);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 3, baro);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 4, gps);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 5, rc);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 6, rc_override);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 7, battery);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 8, gimbal);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 9, esc);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 10, global_pos);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 11, local_pos);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 12, gps_pos);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 13, home_pos);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 14, arms_deployed);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 15, landing_gear_deployed);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 16, upright);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 17, nfz);
	
	
#else
	mavlink_kirkwood_system_health_t packet;
	packet.accel = accel;
	packet.mag = mag;
	packet.gyro = gyro;
	packet.baro = baro;
	packet.gps = gps;
	packet.rc = rc;
	packet.rc_override = rc_override;
	packet.battery = battery;
	packet.gimbal = gimbal;
	packet.esc = esc;
	packet.global_pos = global_pos;
	packet.local_pos = local_pos;
	packet.gps_pos = gps_pos;
	packet.home_pos = home_pos;
	packet.arms_deployed = arms_deployed;
	packet.landing_gear_deployed = landing_gear_deployed;
	packet.upright = upright;
	packet.nfz = nfz;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH_LEN, MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH_CRC);
#else
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH_LEN);
#endif
}

/**
 * @brief Pack a kirkwood_system_health message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param accel accelorometer status
 * @param mag magnetometer status
 * @param gyro gyrometer status
 * @param baro barometer status
 * @param gps gps status
 * @param rc rc status
 * @param rc_override rc override status
 * @param battery battery status
 * @param gimbal gimbal status
 * @param esc esc status
 * @param global_pos global position status
 * @param local_pos local position status
 * @param gps_pos gps position status
 * @param home_pos home position status
 * @param arms_deployed arms deployment status - yes(1)/no(0)
 * @param landing_gear_deployed landing gear deployment status - yes(1)/no(0)
 * @param upright upright status yes(0)/no(1)
 * @param nfz nfz status
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_kirkwood_system_health_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
							   mavlink_message_t* msg,
						           uint8_t accel,uint8_t mag,uint8_t gyro,uint8_t baro,uint8_t gps,uint8_t rc,uint8_t rc_override,uint8_t battery,uint8_t gimbal,uint8_t esc,uint8_t global_pos,uint8_t local_pos,uint8_t gps_pos,uint8_t home_pos,uint8_t arms_deployed,uint8_t landing_gear_deployed,uint8_t upright,uint8_t nfz)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH_LEN];
	_mav_put_uint8_t(buf, 0, accel);
	_mav_put_uint8_t(buf, 1, mag);
	_mav_put_uint8_t(buf, 2, gyro);
	_mav_put_uint8_t(buf, 3, baro);
	_mav_put_uint8_t(buf, 4, gps);
	_mav_put_uint8_t(buf, 5, rc);
	_mav_put_uint8_t(buf, 6, rc_override);
	_mav_put_uint8_t(buf, 7, battery);
	_mav_put_uint8_t(buf, 8, gimbal);
	_mav_put_uint8_t(buf, 9, esc);
	_mav_put_uint8_t(buf, 10, global_pos);
	_mav_put_uint8_t(buf, 11, local_pos);
	_mav_put_uint8_t(buf, 12, gps_pos);
	_mav_put_uint8_t(buf, 13, home_pos);
	_mav_put_uint8_t(buf, 14, arms_deployed);
	_mav_put_uint8_t(buf, 15, landing_gear_deployed);
	_mav_put_uint8_t(buf, 16, upright);
	_mav_put_uint8_t(buf, 17, nfz);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH_LEN);
#else
	mavlink_kirkwood_system_health_t packet;
	packet.accel = accel;
	packet.mag = mag;
	packet.gyro = gyro;
	packet.baro = baro;
	packet.gps = gps;
	packet.rc = rc;
	packet.rc_override = rc_override;
	packet.battery = battery;
	packet.gimbal = gimbal;
	packet.esc = esc;
	packet.global_pos = global_pos;
	packet.local_pos = local_pos;
	packet.gps_pos = gps_pos;
	packet.home_pos = home_pos;
	packet.arms_deployed = arms_deployed;
	packet.landing_gear_deployed = landing_gear_deployed;
	packet.upright = upright;
	packet.nfz = nfz;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH_LEN, MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH_CRC);
#else
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH_LEN);
#endif
}

/**
 * @brief Encode a kirkwood_system_health struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param kirkwood_system_health C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_kirkwood_system_health_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_kirkwood_system_health_t* kirkwood_system_health)
{
	return mavlink_msg_kirkwood_system_health_pack(system_id, component_id, msg, kirkwood_system_health->accel, kirkwood_system_health->mag, kirkwood_system_health->gyro, kirkwood_system_health->baro, kirkwood_system_health->gps, kirkwood_system_health->rc, kirkwood_system_health->rc_override, kirkwood_system_health->battery, kirkwood_system_health->gimbal, kirkwood_system_health->esc, kirkwood_system_health->global_pos, kirkwood_system_health->local_pos, kirkwood_system_health->gps_pos, kirkwood_system_health->home_pos, kirkwood_system_health->arms_deployed, kirkwood_system_health->landing_gear_deployed, kirkwood_system_health->upright, kirkwood_system_health->nfz);
}

/**
 * @brief Encode a kirkwood_system_health struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param kirkwood_system_health C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_kirkwood_system_health_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_kirkwood_system_health_t* kirkwood_system_health)
{
	return mavlink_msg_kirkwood_system_health_pack_chan(system_id, component_id, chan, msg, kirkwood_system_health->accel, kirkwood_system_health->mag, kirkwood_system_health->gyro, kirkwood_system_health->baro, kirkwood_system_health->gps, kirkwood_system_health->rc, kirkwood_system_health->rc_override, kirkwood_system_health->battery, kirkwood_system_health->gimbal, kirkwood_system_health->esc, kirkwood_system_health->global_pos, kirkwood_system_health->local_pos, kirkwood_system_health->gps_pos, kirkwood_system_health->home_pos, kirkwood_system_health->arms_deployed, kirkwood_system_health->landing_gear_deployed, kirkwood_system_health->upright, kirkwood_system_health->nfz);
}

/**
 * @brief Send a kirkwood_system_health message
 * @param chan MAVLink channel to send the message
 *
 * @param accel accelorometer status
 * @param mag magnetometer status
 * @param gyro gyrometer status
 * @param baro barometer status
 * @param gps gps status
 * @param rc rc status
 * @param rc_override rc override status
 * @param battery battery status
 * @param gimbal gimbal status
 * @param esc esc status
 * @param global_pos global position status
 * @param local_pos local position status
 * @param gps_pos gps position status
 * @param home_pos home position status
 * @param arms_deployed arms deployment status - yes(1)/no(0)
 * @param landing_gear_deployed landing gear deployment status - yes(1)/no(0)
 * @param upright upright status yes(0)/no(1)
 * @param nfz nfz status
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_kirkwood_system_health_send(mavlink_channel_t chan, uint8_t accel, uint8_t mag, uint8_t gyro, uint8_t baro, uint8_t gps, uint8_t rc, uint8_t rc_override, uint8_t battery, uint8_t gimbal, uint8_t esc, uint8_t global_pos, uint8_t local_pos, uint8_t gps_pos, uint8_t home_pos, uint8_t arms_deployed, uint8_t landing_gear_deployed, uint8_t upright, uint8_t nfz)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH_LEN];
	_mav_put_uint8_t(buf, 0, accel);
	_mav_put_uint8_t(buf, 1, mag);
	_mav_put_uint8_t(buf, 2, gyro);
	_mav_put_uint8_t(buf, 3, baro);
	_mav_put_uint8_t(buf, 4, gps);
	_mav_put_uint8_t(buf, 5, rc);
	_mav_put_uint8_t(buf, 6, rc_override);
	_mav_put_uint8_t(buf, 7, battery);
	_mav_put_uint8_t(buf, 8, gimbal);
	_mav_put_uint8_t(buf, 9, esc);
	_mav_put_uint8_t(buf, 10, global_pos);
	_mav_put_uint8_t(buf, 11, local_pos);
	_mav_put_uint8_t(buf, 12, gps_pos);
	_mav_put_uint8_t(buf, 13, home_pos);
	_mav_put_uint8_t(buf, 14, arms_deployed);
	_mav_put_uint8_t(buf, 15, landing_gear_deployed);
	_mav_put_uint8_t(buf, 16, upright);
	_mav_put_uint8_t(buf, 17, nfz);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH, buf, MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH_LEN, MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH, buf, MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH_LEN);
#endif
#else
	mavlink_kirkwood_system_health_t packet;
	packet.accel = accel;
	packet.mag = mag;
	packet.gyro = gyro;
	packet.baro = baro;
	packet.gps = gps;
	packet.rc = rc;
	packet.rc_override = rc_override;
	packet.battery = battery;
	packet.gimbal = gimbal;
	packet.esc = esc;
	packet.global_pos = global_pos;
	packet.local_pos = local_pos;
	packet.gps_pos = gps_pos;
	packet.home_pos = home_pos;
	packet.arms_deployed = arms_deployed;
	packet.landing_gear_deployed = landing_gear_deployed;
	packet.upright = upright;
	packet.nfz = nfz;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH, (const char *)&packet, MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH_LEN, MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH, (const char *)&packet, MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH_LEN);
#endif
#endif
}

#if MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_kirkwood_system_health_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint8_t accel, uint8_t mag, uint8_t gyro, uint8_t baro, uint8_t gps, uint8_t rc, uint8_t rc_override, uint8_t battery, uint8_t gimbal, uint8_t esc, uint8_t global_pos, uint8_t local_pos, uint8_t gps_pos, uint8_t home_pos, uint8_t arms_deployed, uint8_t landing_gear_deployed, uint8_t upright, uint8_t nfz)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char *buf = (char *)msgbuf;
	_mav_put_uint8_t(buf, 0, accel);
	_mav_put_uint8_t(buf, 1, mag);
	_mav_put_uint8_t(buf, 2, gyro);
	_mav_put_uint8_t(buf, 3, baro);
	_mav_put_uint8_t(buf, 4, gps);
	_mav_put_uint8_t(buf, 5, rc);
	_mav_put_uint8_t(buf, 6, rc_override);
	_mav_put_uint8_t(buf, 7, battery);
	_mav_put_uint8_t(buf, 8, gimbal);
	_mav_put_uint8_t(buf, 9, esc);
	_mav_put_uint8_t(buf, 10, global_pos);
	_mav_put_uint8_t(buf, 11, local_pos);
	_mav_put_uint8_t(buf, 12, gps_pos);
	_mav_put_uint8_t(buf, 13, home_pos);
	_mav_put_uint8_t(buf, 14, arms_deployed);
	_mav_put_uint8_t(buf, 15, landing_gear_deployed);
	_mav_put_uint8_t(buf, 16, upright);
	_mav_put_uint8_t(buf, 17, nfz);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH, buf, MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH_LEN, MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH, buf, MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH_LEN);
#endif
#else
	mavlink_kirkwood_system_health_t *packet = (mavlink_kirkwood_system_health_t *)msgbuf;
	packet->accel = accel;
	packet->mag = mag;
	packet->gyro = gyro;
	packet->baro = baro;
	packet->gps = gps;
	packet->rc = rc;
	packet->rc_override = rc_override;
	packet->battery = battery;
	packet->gimbal = gimbal;
	packet->esc = esc;
	packet->global_pos = global_pos;
	packet->local_pos = local_pos;
	packet->gps_pos = gps_pos;
	packet->home_pos = home_pos;
	packet->arms_deployed = arms_deployed;
	packet->landing_gear_deployed = landing_gear_deployed;
	packet->upright = upright;
	packet->nfz = nfz;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH, (const char *)packet, MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH_LEN, MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH, (const char *)packet, MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH_LEN);
#endif
#endif
}
#endif

#endif

// MESSAGE KIRKWOOD_SYSTEM_HEALTH UNPACKING


/**
 * @brief Get field accel from kirkwood_system_health message
 *
 * @return accelorometer status
 */
static inline uint8_t mavlink_msg_kirkwood_system_health_get_accel(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  0);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  0);
#endif
}

/**
 * @brief Get field mag from kirkwood_system_health message
 *
 * @return magnetometer status
 */
static inline uint8_t mavlink_msg_kirkwood_system_health_get_mag(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  1);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  1);
#endif
}

/**
 * @brief Get field gyro from kirkwood_system_health message
 *
 * @return gyrometer status
 */
static inline uint8_t mavlink_msg_kirkwood_system_health_get_gyro(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  2);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  2);
#endif
}

/**
 * @brief Get field baro from kirkwood_system_health message
 *
 * @return barometer status
 */
static inline uint8_t mavlink_msg_kirkwood_system_health_get_baro(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  3);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  3);
#endif
}

/**
 * @brief Get field gps from kirkwood_system_health message
 *
 * @return gps status
 */
static inline uint8_t mavlink_msg_kirkwood_system_health_get_gps(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  4);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  4);
#endif
}

/**
 * @brief Get field rc from kirkwood_system_health message
 *
 * @return rc status
 */
static inline uint8_t mavlink_msg_kirkwood_system_health_get_rc(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  5);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  5);
#endif
}

/**
 * @brief Get field rc_override from kirkwood_system_health message
 *
 * @return rc override status
 */
static inline uint8_t mavlink_msg_kirkwood_system_health_get_rc_override(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  6);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  6);
#endif
}

/**
 * @brief Get field battery from kirkwood_system_health message
 *
 * @return battery status
 */
static inline uint8_t mavlink_msg_kirkwood_system_health_get_battery(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  7);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  7);
#endif
}

/**
 * @brief Get field gimbal from kirkwood_system_health message
 *
 * @return gimbal status
 */
static inline uint8_t mavlink_msg_kirkwood_system_health_get_gimbal(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  8);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  8);
#endif
}

/**
 * @brief Get field esc from kirkwood_system_health message
 *
 * @return esc status
 */
static inline uint8_t mavlink_msg_kirkwood_system_health_get_esc(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  9);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  9);
#endif
}

/**
 * @brief Get field global_pos from kirkwood_system_health message
 *
 * @return global position status
 */
static inline uint8_t mavlink_msg_kirkwood_system_health_get_global_pos(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  10);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  10);
#endif
}

/**
 * @brief Get field local_pos from kirkwood_system_health message
 *
 * @return local position status
 */
static inline uint8_t mavlink_msg_kirkwood_system_health_get_local_pos(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  11);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  11);
#endif
}

/**
 * @brief Get field gps_pos from kirkwood_system_health message
 *
 * @return gps position status
 */
static inline uint8_t mavlink_msg_kirkwood_system_health_get_gps_pos(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  12);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  12);
#endif
}

/**
 * @brief Get field home_pos from kirkwood_system_health message
 *
 * @return home position status
 */
static inline uint8_t mavlink_msg_kirkwood_system_health_get_home_pos(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  13);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  13);
#endif
}

/**
 * @brief Get field arms_deployed from kirkwood_system_health message
 *
 * @return arms deployment status - yes(1)/no(0)
 */
static inline uint8_t mavlink_msg_kirkwood_system_health_get_arms_deployed(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  14);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  14);
#endif
}

/**
 * @brief Get field landing_gear_deployed from kirkwood_system_health message
 *
 * @return landing gear deployment status - yes(1)/no(0)
 */
static inline uint8_t mavlink_msg_kirkwood_system_health_get_landing_gear_deployed(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  15);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  15);
#endif
}

/**
 * @brief Get field upright from kirkwood_system_health message
 *
 * @return upright status yes(0)/no(1)
 */
static inline uint8_t mavlink_msg_kirkwood_system_health_get_upright(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  16);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  16);
#endif
}

/**
 * @brief Get field nfz from kirkwood_system_health message
 *
 * @return nfz status
 */
static inline uint8_t mavlink_msg_kirkwood_system_health_get_nfz(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  17);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  17);
#endif
}

/**
 * @brief Decode a kirkwood_system_health message into a struct
 *
 * @param msg The message to decode
 * @param kirkwood_system_health C-struct to decode the message contents into
 */
static inline void mavlink_msg_kirkwood_system_health_decode(const mavlink_message_t* msg, mavlink_kirkwood_system_health_t* kirkwood_system_health)
{
#if MAVLINK_NEED_BYTE_SWAP || MAVLINK_C2000
	kirkwood_system_health->accel = mavlink_msg_kirkwood_system_health_get_accel(msg);
	kirkwood_system_health->mag = mavlink_msg_kirkwood_system_health_get_mag(msg);
	kirkwood_system_health->gyro = mavlink_msg_kirkwood_system_health_get_gyro(msg);
	kirkwood_system_health->baro = mavlink_msg_kirkwood_system_health_get_baro(msg);
	kirkwood_system_health->gps = mavlink_msg_kirkwood_system_health_get_gps(msg);
	kirkwood_system_health->rc = mavlink_msg_kirkwood_system_health_get_rc(msg);
	kirkwood_system_health->rc_override = mavlink_msg_kirkwood_system_health_get_rc_override(msg);
	kirkwood_system_health->battery = mavlink_msg_kirkwood_system_health_get_battery(msg);
	kirkwood_system_health->gimbal = mavlink_msg_kirkwood_system_health_get_gimbal(msg);
	kirkwood_system_health->esc = mavlink_msg_kirkwood_system_health_get_esc(msg);
	kirkwood_system_health->global_pos = mavlink_msg_kirkwood_system_health_get_global_pos(msg);
	kirkwood_system_health->local_pos = mavlink_msg_kirkwood_system_health_get_local_pos(msg);
	kirkwood_system_health->gps_pos = mavlink_msg_kirkwood_system_health_get_gps_pos(msg);
	kirkwood_system_health->home_pos = mavlink_msg_kirkwood_system_health_get_home_pos(msg);
	kirkwood_system_health->arms_deployed = mavlink_msg_kirkwood_system_health_get_arms_deployed(msg);
	kirkwood_system_health->landing_gear_deployed = mavlink_msg_kirkwood_system_health_get_landing_gear_deployed(msg);
	kirkwood_system_health->upright = mavlink_msg_kirkwood_system_health_get_upright(msg);
	kirkwood_system_health->nfz = mavlink_msg_kirkwood_system_health_get_nfz(msg);
#else
	memcpy(kirkwood_system_health, _MAV_PAYLOAD(msg), MAVLINK_MSG_ID_KIRKWOOD_SYSTEM_HEALTH_LEN);
#endif
}
