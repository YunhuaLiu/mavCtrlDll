// MESSAGE COYOTE_SENSE PACKING

#if MAVLINK_C2000
#include "../protocol_c2000.h"
#endif

#define MAVLINK_MSG_ID_COYOTE_SENSE 176

typedef struct __mavlink_coyote_sense_t
{
 uint32_t time_boot_ms; /*< Timestamp (milliseconds since system boot)*/
 float gyro[3]; /*< raw gyro*/
 float accel[3]; /*< raw accel*/
 float encoder[3]; /*< raw encoder*/
} mavlink_coyote_sense_t;

#define MAVLINK_MSG_ID_COYOTE_SENSE_LEN 40
#define MAVLINK_MSG_ID_176_LEN 40

#define MAVLINK_MSG_ID_COYOTE_SENSE_CRC 157
#define MAVLINK_MSG_ID_176_CRC 157

#define MAVLINK_MSG_COYOTE_SENSE_FIELD_GYRO_LEN 3
#define MAVLINK_MSG_COYOTE_SENSE_FIELD_ACCEL_LEN 3
#define MAVLINK_MSG_COYOTE_SENSE_FIELD_ENCODER_LEN 3

#define MAVLINK_MESSAGE_INFO_COYOTE_SENSE { \
	"COYOTE_SENSE", \
	4, \
	{  { "time_boot_ms", NULL, MAVLINK_TYPE_UINT32_T, 0, 0, offsetof(mavlink_coyote_sense_t, time_boot_ms) }, \
         { "gyro", NULL, MAVLINK_TYPE_FLOAT, 3, 4, offsetof(mavlink_coyote_sense_t, gyro) }, \
         { "accel", NULL, MAVLINK_TYPE_FLOAT, 3, 16, offsetof(mavlink_coyote_sense_t, accel) }, \
         { "encoder", NULL, MAVLINK_TYPE_FLOAT, 3, 28, offsetof(mavlink_coyote_sense_t, encoder) }, \
         } \
}


/**
 * @brief Pack a coyote_sense message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param time_boot_ms Timestamp (milliseconds since system boot)
 * @param gyro raw gyro
 * @param accel raw accel
 * @param encoder raw encoder
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_coyote_sense_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
						       uint32_t time_boot_ms, const float *gyro, const float *accel, const float *encoder)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_COYOTE_SENSE_LEN];
	_mav_put_uint32_t(buf, 0, time_boot_ms);
	_mav_put_float_array(buf, 4, gyro, 3);
	_mav_put_float_array(buf, 16, accel, 3);
	_mav_put_float_array(buf, 28, encoder, 3);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_COYOTE_SENSE_LEN);
#elif MAVLINK_C2000
		mav_put_uint32_t_c2000(&(msg->payload64[0]), 0, time_boot_ms);
	
		mav_put_float_array_c2000(&(msg->payload64[0]), gyro, 4, 3);
		mav_put_float_array_c2000(&(msg->payload64[0]), accel, 16, 3);
		mav_put_float_array_c2000(&(msg->payload64[0]), encoder, 28, 3);
	
#else
	mavlink_coyote_sense_t packet;
	packet.time_boot_ms = time_boot_ms;
	mav_array_memcpy(packet.gyro, gyro, sizeof(float)*3);
	mav_array_memcpy(packet.accel, accel, sizeof(float)*3);
	mav_array_memcpy(packet.encoder, encoder, sizeof(float)*3);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_COYOTE_SENSE_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_COYOTE_SENSE;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_COYOTE_SENSE_LEN, MAVLINK_MSG_ID_COYOTE_SENSE_CRC);
#else
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_COYOTE_SENSE_LEN);
#endif
}

/**
 * @brief Pack a coyote_sense message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param time_boot_ms Timestamp (milliseconds since system boot)
 * @param gyro raw gyro
 * @param accel raw accel
 * @param encoder raw encoder
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_coyote_sense_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
							   mavlink_message_t* msg,
						           uint32_t time_boot_ms,const float *gyro,const float *accel,const float *encoder)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_COYOTE_SENSE_LEN];
	_mav_put_uint32_t(buf, 0, time_boot_ms);
	_mav_put_float_array(buf, 4, gyro, 3);
	_mav_put_float_array(buf, 16, accel, 3);
	_mav_put_float_array(buf, 28, encoder, 3);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_COYOTE_SENSE_LEN);
#else
	mavlink_coyote_sense_t packet;
	packet.time_boot_ms = time_boot_ms;
	mav_array_memcpy(packet.gyro, gyro, sizeof(float)*3);
	mav_array_memcpy(packet.accel, accel, sizeof(float)*3);
	mav_array_memcpy(packet.encoder, encoder, sizeof(float)*3);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_COYOTE_SENSE_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_COYOTE_SENSE;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_COYOTE_SENSE_LEN, MAVLINK_MSG_ID_COYOTE_SENSE_CRC);
#else
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_COYOTE_SENSE_LEN);
#endif
}

/**
 * @brief Encode a coyote_sense struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param coyote_sense C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_coyote_sense_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_coyote_sense_t* coyote_sense)
{
	return mavlink_msg_coyote_sense_pack(system_id, component_id, msg, coyote_sense->time_boot_ms, coyote_sense->gyro, coyote_sense->accel, coyote_sense->encoder);
}

/**
 * @brief Encode a coyote_sense struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param coyote_sense C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_coyote_sense_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_coyote_sense_t* coyote_sense)
{
	return mavlink_msg_coyote_sense_pack_chan(system_id, component_id, chan, msg, coyote_sense->time_boot_ms, coyote_sense->gyro, coyote_sense->accel, coyote_sense->encoder);
}

/**
 * @brief Send a coyote_sense message
 * @param chan MAVLink channel to send the message
 *
 * @param time_boot_ms Timestamp (milliseconds since system boot)
 * @param gyro raw gyro
 * @param accel raw accel
 * @param encoder raw encoder
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_coyote_sense_send(mavlink_channel_t chan, uint32_t time_boot_ms, const float *gyro, const float *accel, const float *encoder)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_COYOTE_SENSE_LEN];
	_mav_put_uint32_t(buf, 0, time_boot_ms);
	_mav_put_float_array(buf, 4, gyro, 3);
	_mav_put_float_array(buf, 16, accel, 3);
	_mav_put_float_array(buf, 28, encoder, 3);
#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_COYOTE_SENSE, buf, MAVLINK_MSG_ID_COYOTE_SENSE_LEN, MAVLINK_MSG_ID_COYOTE_SENSE_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_COYOTE_SENSE, buf, MAVLINK_MSG_ID_COYOTE_SENSE_LEN);
#endif
#else
	mavlink_coyote_sense_t packet;
	packet.time_boot_ms = time_boot_ms;
	mav_array_memcpy(packet.gyro, gyro, sizeof(float)*3);
	mav_array_memcpy(packet.accel, accel, sizeof(float)*3);
	mav_array_memcpy(packet.encoder, encoder, sizeof(float)*3);
#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_COYOTE_SENSE, (const char *)&packet, MAVLINK_MSG_ID_COYOTE_SENSE_LEN, MAVLINK_MSG_ID_COYOTE_SENSE_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_COYOTE_SENSE, (const char *)&packet, MAVLINK_MSG_ID_COYOTE_SENSE_LEN);
#endif
#endif
}

#if MAVLINK_MSG_ID_COYOTE_SENSE_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_coyote_sense_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint32_t time_boot_ms, const float *gyro, const float *accel, const float *encoder)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char *buf = (char *)msgbuf;
	_mav_put_uint32_t(buf, 0, time_boot_ms);
	_mav_put_float_array(buf, 4, gyro, 3);
	_mav_put_float_array(buf, 16, accel, 3);
	_mav_put_float_array(buf, 28, encoder, 3);
#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_COYOTE_SENSE, buf, MAVLINK_MSG_ID_COYOTE_SENSE_LEN, MAVLINK_MSG_ID_COYOTE_SENSE_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_COYOTE_SENSE, buf, MAVLINK_MSG_ID_COYOTE_SENSE_LEN);
#endif
#else
	mavlink_coyote_sense_t *packet = (mavlink_coyote_sense_t *)msgbuf;
	packet->time_boot_ms = time_boot_ms;
	mav_array_memcpy(packet->gyro, gyro, sizeof(float)*3);
	mav_array_memcpy(packet->accel, accel, sizeof(float)*3);
	mav_array_memcpy(packet->encoder, encoder, sizeof(float)*3);
#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_COYOTE_SENSE, (const char *)packet, MAVLINK_MSG_ID_COYOTE_SENSE_LEN, MAVLINK_MSG_ID_COYOTE_SENSE_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_COYOTE_SENSE, (const char *)packet, MAVLINK_MSG_ID_COYOTE_SENSE_LEN);
#endif
#endif
}
#endif

#endif

// MESSAGE COYOTE_SENSE UNPACKING


/**
 * @brief Get field time_boot_ms from coyote_sense message
 *
 * @return Timestamp (milliseconds since system boot)
 */
static inline uint32_t mavlink_msg_coyote_sense_get_time_boot_ms(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint32_t(msg,  0);
#else
	return mav_get_uint32_t_c2000(&(msg->payload64[0]),  0);
#endif
}

/**
 * @brief Get field gyro from coyote_sense message
 *
 * @return raw gyro
 */
static inline uint16_t mavlink_msg_coyote_sense_get_gyro(const mavlink_message_t* msg, float *gyro)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float_array(msg, gyro, 3,  4);
#else
	return mav_get_float_array_c2000(&(msg->payload64[0]), gyro, 3,  4);
#endif
}

/**
 * @brief Get field accel from coyote_sense message
 *
 * @return raw accel
 */
static inline uint16_t mavlink_msg_coyote_sense_get_accel(const mavlink_message_t* msg, float *accel)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float_array(msg, accel, 3,  16);
#else
	return mav_get_float_array_c2000(&(msg->payload64[0]), accel, 3,  16);
#endif
}

/**
 * @brief Get field encoder from coyote_sense message
 *
 * @return raw encoder
 */
static inline uint16_t mavlink_msg_coyote_sense_get_encoder(const mavlink_message_t* msg, float *encoder)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float_array(msg, encoder, 3,  28);
#else
	return mav_get_float_array_c2000(&(msg->payload64[0]), encoder, 3,  28);
#endif
}

/**
 * @brief Decode a coyote_sense message into a struct
 *
 * @param msg The message to decode
 * @param coyote_sense C-struct to decode the message contents into
 */
static inline void mavlink_msg_coyote_sense_decode(const mavlink_message_t* msg, mavlink_coyote_sense_t* coyote_sense)
{
#if MAVLINK_NEED_BYTE_SWAP || MAVLINK_C2000
	coyote_sense->time_boot_ms = mavlink_msg_coyote_sense_get_time_boot_ms(msg);
	mavlink_msg_coyote_sense_get_gyro(msg, coyote_sense->gyro);
	mavlink_msg_coyote_sense_get_accel(msg, coyote_sense->accel);
	mavlink_msg_coyote_sense_get_encoder(msg, coyote_sense->encoder);
#else
	memcpy(coyote_sense, _MAV_PAYLOAD(msg), MAVLINK_MSG_ID_COYOTE_SENSE_LEN);
#endif
}
