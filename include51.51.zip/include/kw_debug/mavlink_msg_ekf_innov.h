// MESSAGE EKF_INNOV PACKING

#if MAVLINK_C2000
#include "../protocol_c2000.h"
#endif

#define MAVLINK_MSG_ID_EKF_INNOV 191

typedef struct __mavlink_ekf_innov_t
{
 uint64_t time_usec; /*< Timestamp*/
 float vN; /*< Innovation: Velocity N-Direction*/
 float vE; /*< Innovation: Velocity E-Direction*/
 float vD; /*< Innovation: Velocity D-Direction*/
 float pN; /*< Innovation: Position N-Direction*/
 float pE; /*< Innovation: Position E-Direction*/
 float pD; /*< Innovation: Position D-Direction*/
 float magX; /*< Innovation: Magnetometer X-Direction*/
 float magY; /*< Innovation: Magnetometer Y-Direction*/
 float magZ; /*< Innovation: Magnetometer Z-Direction*/
 float vtas; /*< Innovation: Airspeed*/
 float rng; /*< Innovation: Range Data*/
 float s_vN; /*< Innovation Standard Deviation: Velocity N-Direction*/
 float s_vE; /*< Innovation Standard Deviation: Velocity E-Direction*/
 float s_vD; /*< Innovation Standard Deviation: Velocity D-Direction*/
 float s_pN; /*< Innovation Standard Deviation: Position N-Direction*/
 float s_pE; /*< Innovation Standard Deviation: Position E-Direction*/
 float s_pD; /*< Innovation Standard Deviation: Position D-Direction*/
 float s_magX; /*< Innovation Standard Deviation: Magnetometer X-Direction*/
 float s_magY; /*< Innovation Standard Deviation: Magnetometer Y-Direction*/
 float s_magZ; /*< Innovation Standard Deviation: Magnetometer Z-Direction*/
 float s_vtas; /*< Innovation Standard Deviation: Airspeed*/
 float s_rng; /*< Innovation Standard Deviation: Range Data*/
 uint8_t fused_vNED; /*< Has been fused (is valid)?: Velocity NED-Frame*/
 uint8_t fused_pNE; /*< Has been fused (is valid)?: Position NE-Frame*/
 uint8_t fused_pD; /*< Has been fused (is valid)?: Position D-Direction*/
 uint8_t fused_magXYZ; /*< Has been fused (is valid)?: Magnetometer XYZ-Frame*/
 uint8_t fused_vtas; /*< Has been fused (is valid)?: Airspeed*/
 uint8_t fused_rng; /*< Has been fused (is valid)?: Range Data*/
} mavlink_ekf_innov_t;

#define MAVLINK_MSG_ID_EKF_INNOV_LEN 102
#define MAVLINK_MSG_ID_191_LEN 102

#define MAVLINK_MSG_ID_EKF_INNOV_CRC 245
#define MAVLINK_MSG_ID_191_CRC 245



#define MAVLINK_MESSAGE_INFO_EKF_INNOV { \
	"EKF_INNOV", \
	29, \
	{  { "time_usec", NULL, MAVLINK_TYPE_UINT64_T, 0, 0, offsetof(mavlink_ekf_innov_t, time_usec) }, \
         { "vN", NULL, MAVLINK_TYPE_FLOAT, 0, 8, offsetof(mavlink_ekf_innov_t, vN) }, \
         { "vE", NULL, MAVLINK_TYPE_FLOAT, 0, 12, offsetof(mavlink_ekf_innov_t, vE) }, \
         { "vD", NULL, MAVLINK_TYPE_FLOAT, 0, 16, offsetof(mavlink_ekf_innov_t, vD) }, \
         { "pN", NULL, MAVLINK_TYPE_FLOAT, 0, 20, offsetof(mavlink_ekf_innov_t, pN) }, \
         { "pE", NULL, MAVLINK_TYPE_FLOAT, 0, 24, offsetof(mavlink_ekf_innov_t, pE) }, \
         { "pD", NULL, MAVLINK_TYPE_FLOAT, 0, 28, offsetof(mavlink_ekf_innov_t, pD) }, \
         { "magX", NULL, MAVLINK_TYPE_FLOAT, 0, 32, offsetof(mavlink_ekf_innov_t, magX) }, \
         { "magY", NULL, MAVLINK_TYPE_FLOAT, 0, 36, offsetof(mavlink_ekf_innov_t, magY) }, \
         { "magZ", NULL, MAVLINK_TYPE_FLOAT, 0, 40, offsetof(mavlink_ekf_innov_t, magZ) }, \
         { "vtas", NULL, MAVLINK_TYPE_FLOAT, 0, 44, offsetof(mavlink_ekf_innov_t, vtas) }, \
         { "rng", NULL, MAVLINK_TYPE_FLOAT, 0, 48, offsetof(mavlink_ekf_innov_t, rng) }, \
         { "s_vN", NULL, MAVLINK_TYPE_FLOAT, 0, 52, offsetof(mavlink_ekf_innov_t, s_vN) }, \
         { "s_vE", NULL, MAVLINK_TYPE_FLOAT, 0, 56, offsetof(mavlink_ekf_innov_t, s_vE) }, \
         { "s_vD", NULL, MAVLINK_TYPE_FLOAT, 0, 60, offsetof(mavlink_ekf_innov_t, s_vD) }, \
         { "s_pN", NULL, MAVLINK_TYPE_FLOAT, 0, 64, offsetof(mavlink_ekf_innov_t, s_pN) }, \
         { "s_pE", NULL, MAVLINK_TYPE_FLOAT, 0, 68, offsetof(mavlink_ekf_innov_t, s_pE) }, \
         { "s_pD", NULL, MAVLINK_TYPE_FLOAT, 0, 72, offsetof(mavlink_ekf_innov_t, s_pD) }, \
         { "s_magX", NULL, MAVLINK_TYPE_FLOAT, 0, 76, offsetof(mavlink_ekf_innov_t, s_magX) }, \
         { "s_magY", NULL, MAVLINK_TYPE_FLOAT, 0, 80, offsetof(mavlink_ekf_innov_t, s_magY) }, \
         { "s_magZ", NULL, MAVLINK_TYPE_FLOAT, 0, 84, offsetof(mavlink_ekf_innov_t, s_magZ) }, \
         { "s_vtas", NULL, MAVLINK_TYPE_FLOAT, 0, 88, offsetof(mavlink_ekf_innov_t, s_vtas) }, \
         { "s_rng", NULL, MAVLINK_TYPE_FLOAT, 0, 92, offsetof(mavlink_ekf_innov_t, s_rng) }, \
         { "fused_vNED", NULL, MAVLINK_TYPE_UINT8_T, 0, 96, offsetof(mavlink_ekf_innov_t, fused_vNED) }, \
         { "fused_pNE", NULL, MAVLINK_TYPE_UINT8_T, 0, 97, offsetof(mavlink_ekf_innov_t, fused_pNE) }, \
         { "fused_pD", NULL, MAVLINK_TYPE_UINT8_T, 0, 98, offsetof(mavlink_ekf_innov_t, fused_pD) }, \
         { "fused_magXYZ", NULL, MAVLINK_TYPE_UINT8_T, 0, 99, offsetof(mavlink_ekf_innov_t, fused_magXYZ) }, \
         { "fused_vtas", NULL, MAVLINK_TYPE_UINT8_T, 0, 100, offsetof(mavlink_ekf_innov_t, fused_vtas) }, \
         { "fused_rng", NULL, MAVLINK_TYPE_UINT8_T, 0, 101, offsetof(mavlink_ekf_innov_t, fused_rng) }, \
         } \
}


/**
 * @brief Pack a ekf_innov message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param time_usec Timestamp
 * @param vN Innovation: Velocity N-Direction
 * @param vE Innovation: Velocity E-Direction
 * @param vD Innovation: Velocity D-Direction
 * @param pN Innovation: Position N-Direction
 * @param pE Innovation: Position E-Direction
 * @param pD Innovation: Position D-Direction
 * @param magX Innovation: Magnetometer X-Direction
 * @param magY Innovation: Magnetometer Y-Direction
 * @param magZ Innovation: Magnetometer Z-Direction
 * @param vtas Innovation: Airspeed
 * @param rng Innovation: Range Data
 * @param s_vN Innovation Standard Deviation: Velocity N-Direction
 * @param s_vE Innovation Standard Deviation: Velocity E-Direction
 * @param s_vD Innovation Standard Deviation: Velocity D-Direction
 * @param s_pN Innovation Standard Deviation: Position N-Direction
 * @param s_pE Innovation Standard Deviation: Position E-Direction
 * @param s_pD Innovation Standard Deviation: Position D-Direction
 * @param s_magX Innovation Standard Deviation: Magnetometer X-Direction
 * @param s_magY Innovation Standard Deviation: Magnetometer Y-Direction
 * @param s_magZ Innovation Standard Deviation: Magnetometer Z-Direction
 * @param s_vtas Innovation Standard Deviation: Airspeed
 * @param s_rng Innovation Standard Deviation: Range Data
 * @param fused_vNED Has been fused (is valid)?: Velocity NED-Frame
 * @param fused_pNE Has been fused (is valid)?: Position NE-Frame
 * @param fused_pD Has been fused (is valid)?: Position D-Direction
 * @param fused_magXYZ Has been fused (is valid)?: Magnetometer XYZ-Frame
 * @param fused_vtas Has been fused (is valid)?: Airspeed
 * @param fused_rng Has been fused (is valid)?: Range Data
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ekf_innov_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
						       uint64_t time_usec, float vN, float vE, float vD, float pN, float pE, float pD, float magX, float magY, float magZ, float vtas, float rng, float s_vN, float s_vE, float s_vD, float s_pN, float s_pE, float s_pD, float s_magX, float s_magY, float s_magZ, float s_vtas, float s_rng, uint8_t fused_vNED, uint8_t fused_pNE, uint8_t fused_pD, uint8_t fused_magXYZ, uint8_t fused_vtas, uint8_t fused_rng)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_EKF_INNOV_LEN];
	_mav_put_uint64_t(buf, 0, time_usec);
	_mav_put_float(buf, 8, vN);
	_mav_put_float(buf, 12, vE);
	_mav_put_float(buf, 16, vD);
	_mav_put_float(buf, 20, pN);
	_mav_put_float(buf, 24, pE);
	_mav_put_float(buf, 28, pD);
	_mav_put_float(buf, 32, magX);
	_mav_put_float(buf, 36, magY);
	_mav_put_float(buf, 40, magZ);
	_mav_put_float(buf, 44, vtas);
	_mav_put_float(buf, 48, rng);
	_mav_put_float(buf, 52, s_vN);
	_mav_put_float(buf, 56, s_vE);
	_mav_put_float(buf, 60, s_vD);
	_mav_put_float(buf, 64, s_pN);
	_mav_put_float(buf, 68, s_pE);
	_mav_put_float(buf, 72, s_pD);
	_mav_put_float(buf, 76, s_magX);
	_mav_put_float(buf, 80, s_magY);
	_mav_put_float(buf, 84, s_magZ);
	_mav_put_float(buf, 88, s_vtas);
	_mav_put_float(buf, 92, s_rng);
	_mav_put_uint8_t(buf, 96, fused_vNED);
	_mav_put_uint8_t(buf, 97, fused_pNE);
	_mav_put_uint8_t(buf, 98, fused_pD);
	_mav_put_uint8_t(buf, 99, fused_magXYZ);
	_mav_put_uint8_t(buf, 100, fused_vtas);
	_mav_put_uint8_t(buf, 101, fused_rng);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_EKF_INNOV_LEN);
#elif MAVLINK_C2000
		mav_put_uint64_t_c2000(&(msg->payload64[0]), 0, time_usec);
		mav_put_float_c2000(&(msg->payload64[0]), 8, vN);
		mav_put_float_c2000(&(msg->payload64[0]), 12, vE);
		mav_put_float_c2000(&(msg->payload64[0]), 16, vD);
		mav_put_float_c2000(&(msg->payload64[0]), 20, pN);
		mav_put_float_c2000(&(msg->payload64[0]), 24, pE);
		mav_put_float_c2000(&(msg->payload64[0]), 28, pD);
		mav_put_float_c2000(&(msg->payload64[0]), 32, magX);
		mav_put_float_c2000(&(msg->payload64[0]), 36, magY);
		mav_put_float_c2000(&(msg->payload64[0]), 40, magZ);
		mav_put_float_c2000(&(msg->payload64[0]), 44, vtas);
		mav_put_float_c2000(&(msg->payload64[0]), 48, rng);
		mav_put_float_c2000(&(msg->payload64[0]), 52, s_vN);
		mav_put_float_c2000(&(msg->payload64[0]), 56, s_vE);
		mav_put_float_c2000(&(msg->payload64[0]), 60, s_vD);
		mav_put_float_c2000(&(msg->payload64[0]), 64, s_pN);
		mav_put_float_c2000(&(msg->payload64[0]), 68, s_pE);
		mav_put_float_c2000(&(msg->payload64[0]), 72, s_pD);
		mav_put_float_c2000(&(msg->payload64[0]), 76, s_magX);
		mav_put_float_c2000(&(msg->payload64[0]), 80, s_magY);
		mav_put_float_c2000(&(msg->payload64[0]), 84, s_magZ);
		mav_put_float_c2000(&(msg->payload64[0]), 88, s_vtas);
		mav_put_float_c2000(&(msg->payload64[0]), 92, s_rng);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 96, fused_vNED);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 97, fused_pNE);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 98, fused_pD);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 99, fused_magXYZ);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 100, fused_vtas);
		mav_put_uint8_t_c2000(&(msg->payload64[0]), 101, fused_rng);
	
	
#else
	mavlink_ekf_innov_t packet;
	packet.time_usec = time_usec;
	packet.vN = vN;
	packet.vE = vE;
	packet.vD = vD;
	packet.pN = pN;
	packet.pE = pE;
	packet.pD = pD;
	packet.magX = magX;
	packet.magY = magY;
	packet.magZ = magZ;
	packet.vtas = vtas;
	packet.rng = rng;
	packet.s_vN = s_vN;
	packet.s_vE = s_vE;
	packet.s_vD = s_vD;
	packet.s_pN = s_pN;
	packet.s_pE = s_pE;
	packet.s_pD = s_pD;
	packet.s_magX = s_magX;
	packet.s_magY = s_magY;
	packet.s_magZ = s_magZ;
	packet.s_vtas = s_vtas;
	packet.s_rng = s_rng;
	packet.fused_vNED = fused_vNED;
	packet.fused_pNE = fused_pNE;
	packet.fused_pD = fused_pD;
	packet.fused_magXYZ = fused_magXYZ;
	packet.fused_vtas = fused_vtas;
	packet.fused_rng = fused_rng;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_EKF_INNOV_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_EKF_INNOV;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_EKF_INNOV_LEN, MAVLINK_MSG_ID_EKF_INNOV_CRC);
#else
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_EKF_INNOV_LEN);
#endif
}

/**
 * @brief Pack a ekf_innov message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param time_usec Timestamp
 * @param vN Innovation: Velocity N-Direction
 * @param vE Innovation: Velocity E-Direction
 * @param vD Innovation: Velocity D-Direction
 * @param pN Innovation: Position N-Direction
 * @param pE Innovation: Position E-Direction
 * @param pD Innovation: Position D-Direction
 * @param magX Innovation: Magnetometer X-Direction
 * @param magY Innovation: Magnetometer Y-Direction
 * @param magZ Innovation: Magnetometer Z-Direction
 * @param vtas Innovation: Airspeed
 * @param rng Innovation: Range Data
 * @param s_vN Innovation Standard Deviation: Velocity N-Direction
 * @param s_vE Innovation Standard Deviation: Velocity E-Direction
 * @param s_vD Innovation Standard Deviation: Velocity D-Direction
 * @param s_pN Innovation Standard Deviation: Position N-Direction
 * @param s_pE Innovation Standard Deviation: Position E-Direction
 * @param s_pD Innovation Standard Deviation: Position D-Direction
 * @param s_magX Innovation Standard Deviation: Magnetometer X-Direction
 * @param s_magY Innovation Standard Deviation: Magnetometer Y-Direction
 * @param s_magZ Innovation Standard Deviation: Magnetometer Z-Direction
 * @param s_vtas Innovation Standard Deviation: Airspeed
 * @param s_rng Innovation Standard Deviation: Range Data
 * @param fused_vNED Has been fused (is valid)?: Velocity NED-Frame
 * @param fused_pNE Has been fused (is valid)?: Position NE-Frame
 * @param fused_pD Has been fused (is valid)?: Position D-Direction
 * @param fused_magXYZ Has been fused (is valid)?: Magnetometer XYZ-Frame
 * @param fused_vtas Has been fused (is valid)?: Airspeed
 * @param fused_rng Has been fused (is valid)?: Range Data
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ekf_innov_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
							   mavlink_message_t* msg,
						           uint64_t time_usec,float vN,float vE,float vD,float pN,float pE,float pD,float magX,float magY,float magZ,float vtas,float rng,float s_vN,float s_vE,float s_vD,float s_pN,float s_pE,float s_pD,float s_magX,float s_magY,float s_magZ,float s_vtas,float s_rng,uint8_t fused_vNED,uint8_t fused_pNE,uint8_t fused_pD,uint8_t fused_magXYZ,uint8_t fused_vtas,uint8_t fused_rng)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_EKF_INNOV_LEN];
	_mav_put_uint64_t(buf, 0, time_usec);
	_mav_put_float(buf, 8, vN);
	_mav_put_float(buf, 12, vE);
	_mav_put_float(buf, 16, vD);
	_mav_put_float(buf, 20, pN);
	_mav_put_float(buf, 24, pE);
	_mav_put_float(buf, 28, pD);
	_mav_put_float(buf, 32, magX);
	_mav_put_float(buf, 36, magY);
	_mav_put_float(buf, 40, magZ);
	_mav_put_float(buf, 44, vtas);
	_mav_put_float(buf, 48, rng);
	_mav_put_float(buf, 52, s_vN);
	_mav_put_float(buf, 56, s_vE);
	_mav_put_float(buf, 60, s_vD);
	_mav_put_float(buf, 64, s_pN);
	_mav_put_float(buf, 68, s_pE);
	_mav_put_float(buf, 72, s_pD);
	_mav_put_float(buf, 76, s_magX);
	_mav_put_float(buf, 80, s_magY);
	_mav_put_float(buf, 84, s_magZ);
	_mav_put_float(buf, 88, s_vtas);
	_mav_put_float(buf, 92, s_rng);
	_mav_put_uint8_t(buf, 96, fused_vNED);
	_mav_put_uint8_t(buf, 97, fused_pNE);
	_mav_put_uint8_t(buf, 98, fused_pD);
	_mav_put_uint8_t(buf, 99, fused_magXYZ);
	_mav_put_uint8_t(buf, 100, fused_vtas);
	_mav_put_uint8_t(buf, 101, fused_rng);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_EKF_INNOV_LEN);
#else
	mavlink_ekf_innov_t packet;
	packet.time_usec = time_usec;
	packet.vN = vN;
	packet.vE = vE;
	packet.vD = vD;
	packet.pN = pN;
	packet.pE = pE;
	packet.pD = pD;
	packet.magX = magX;
	packet.magY = magY;
	packet.magZ = magZ;
	packet.vtas = vtas;
	packet.rng = rng;
	packet.s_vN = s_vN;
	packet.s_vE = s_vE;
	packet.s_vD = s_vD;
	packet.s_pN = s_pN;
	packet.s_pE = s_pE;
	packet.s_pD = s_pD;
	packet.s_magX = s_magX;
	packet.s_magY = s_magY;
	packet.s_magZ = s_magZ;
	packet.s_vtas = s_vtas;
	packet.s_rng = s_rng;
	packet.fused_vNED = fused_vNED;
	packet.fused_pNE = fused_pNE;
	packet.fused_pD = fused_pD;
	packet.fused_magXYZ = fused_magXYZ;
	packet.fused_vtas = fused_vtas;
	packet.fused_rng = fused_rng;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_EKF_INNOV_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_EKF_INNOV;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_EKF_INNOV_LEN, MAVLINK_MSG_ID_EKF_INNOV_CRC);
#else
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_EKF_INNOV_LEN);
#endif
}

/**
 * @brief Encode a ekf_innov struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param ekf_innov C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ekf_innov_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_ekf_innov_t* ekf_innov)
{
	return mavlink_msg_ekf_innov_pack(system_id, component_id, msg, ekf_innov->time_usec, ekf_innov->vN, ekf_innov->vE, ekf_innov->vD, ekf_innov->pN, ekf_innov->pE, ekf_innov->pD, ekf_innov->magX, ekf_innov->magY, ekf_innov->magZ, ekf_innov->vtas, ekf_innov->rng, ekf_innov->s_vN, ekf_innov->s_vE, ekf_innov->s_vD, ekf_innov->s_pN, ekf_innov->s_pE, ekf_innov->s_pD, ekf_innov->s_magX, ekf_innov->s_magY, ekf_innov->s_magZ, ekf_innov->s_vtas, ekf_innov->s_rng, ekf_innov->fused_vNED, ekf_innov->fused_pNE, ekf_innov->fused_pD, ekf_innov->fused_magXYZ, ekf_innov->fused_vtas, ekf_innov->fused_rng);
}

/**
 * @brief Encode a ekf_innov struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param ekf_innov C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ekf_innov_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_ekf_innov_t* ekf_innov)
{
	return mavlink_msg_ekf_innov_pack_chan(system_id, component_id, chan, msg, ekf_innov->time_usec, ekf_innov->vN, ekf_innov->vE, ekf_innov->vD, ekf_innov->pN, ekf_innov->pE, ekf_innov->pD, ekf_innov->magX, ekf_innov->magY, ekf_innov->magZ, ekf_innov->vtas, ekf_innov->rng, ekf_innov->s_vN, ekf_innov->s_vE, ekf_innov->s_vD, ekf_innov->s_pN, ekf_innov->s_pE, ekf_innov->s_pD, ekf_innov->s_magX, ekf_innov->s_magY, ekf_innov->s_magZ, ekf_innov->s_vtas, ekf_innov->s_rng, ekf_innov->fused_vNED, ekf_innov->fused_pNE, ekf_innov->fused_pD, ekf_innov->fused_magXYZ, ekf_innov->fused_vtas, ekf_innov->fused_rng);
}

/**
 * @brief Send a ekf_innov message
 * @param chan MAVLink channel to send the message
 *
 * @param time_usec Timestamp
 * @param vN Innovation: Velocity N-Direction
 * @param vE Innovation: Velocity E-Direction
 * @param vD Innovation: Velocity D-Direction
 * @param pN Innovation: Position N-Direction
 * @param pE Innovation: Position E-Direction
 * @param pD Innovation: Position D-Direction
 * @param magX Innovation: Magnetometer X-Direction
 * @param magY Innovation: Magnetometer Y-Direction
 * @param magZ Innovation: Magnetometer Z-Direction
 * @param vtas Innovation: Airspeed
 * @param rng Innovation: Range Data
 * @param s_vN Innovation Standard Deviation: Velocity N-Direction
 * @param s_vE Innovation Standard Deviation: Velocity E-Direction
 * @param s_vD Innovation Standard Deviation: Velocity D-Direction
 * @param s_pN Innovation Standard Deviation: Position N-Direction
 * @param s_pE Innovation Standard Deviation: Position E-Direction
 * @param s_pD Innovation Standard Deviation: Position D-Direction
 * @param s_magX Innovation Standard Deviation: Magnetometer X-Direction
 * @param s_magY Innovation Standard Deviation: Magnetometer Y-Direction
 * @param s_magZ Innovation Standard Deviation: Magnetometer Z-Direction
 * @param s_vtas Innovation Standard Deviation: Airspeed
 * @param s_rng Innovation Standard Deviation: Range Data
 * @param fused_vNED Has been fused (is valid)?: Velocity NED-Frame
 * @param fused_pNE Has been fused (is valid)?: Position NE-Frame
 * @param fused_pD Has been fused (is valid)?: Position D-Direction
 * @param fused_magXYZ Has been fused (is valid)?: Magnetometer XYZ-Frame
 * @param fused_vtas Has been fused (is valid)?: Airspeed
 * @param fused_rng Has been fused (is valid)?: Range Data
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_ekf_innov_send(mavlink_channel_t chan, uint64_t time_usec, float vN, float vE, float vD, float pN, float pE, float pD, float magX, float magY, float magZ, float vtas, float rng, float s_vN, float s_vE, float s_vD, float s_pN, float s_pE, float s_pD, float s_magX, float s_magY, float s_magZ, float s_vtas, float s_rng, uint8_t fused_vNED, uint8_t fused_pNE, uint8_t fused_pD, uint8_t fused_magXYZ, uint8_t fused_vtas, uint8_t fused_rng)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_EKF_INNOV_LEN];
	_mav_put_uint64_t(buf, 0, time_usec);
	_mav_put_float(buf, 8, vN);
	_mav_put_float(buf, 12, vE);
	_mav_put_float(buf, 16, vD);
	_mav_put_float(buf, 20, pN);
	_mav_put_float(buf, 24, pE);
	_mav_put_float(buf, 28, pD);
	_mav_put_float(buf, 32, magX);
	_mav_put_float(buf, 36, magY);
	_mav_put_float(buf, 40, magZ);
	_mav_put_float(buf, 44, vtas);
	_mav_put_float(buf, 48, rng);
	_mav_put_float(buf, 52, s_vN);
	_mav_put_float(buf, 56, s_vE);
	_mav_put_float(buf, 60, s_vD);
	_mav_put_float(buf, 64, s_pN);
	_mav_put_float(buf, 68, s_pE);
	_mav_put_float(buf, 72, s_pD);
	_mav_put_float(buf, 76, s_magX);
	_mav_put_float(buf, 80, s_magY);
	_mav_put_float(buf, 84, s_magZ);
	_mav_put_float(buf, 88, s_vtas);
	_mav_put_float(buf, 92, s_rng);
	_mav_put_uint8_t(buf, 96, fused_vNED);
	_mav_put_uint8_t(buf, 97, fused_pNE);
	_mav_put_uint8_t(buf, 98, fused_pD);
	_mav_put_uint8_t(buf, 99, fused_magXYZ);
	_mav_put_uint8_t(buf, 100, fused_vtas);
	_mav_put_uint8_t(buf, 101, fused_rng);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_EKF_INNOV, buf, MAVLINK_MSG_ID_EKF_INNOV_LEN, MAVLINK_MSG_ID_EKF_INNOV_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_EKF_INNOV, buf, MAVLINK_MSG_ID_EKF_INNOV_LEN);
#endif
#else
	mavlink_ekf_innov_t packet;
	packet.time_usec = time_usec;
	packet.vN = vN;
	packet.vE = vE;
	packet.vD = vD;
	packet.pN = pN;
	packet.pE = pE;
	packet.pD = pD;
	packet.magX = magX;
	packet.magY = magY;
	packet.magZ = magZ;
	packet.vtas = vtas;
	packet.rng = rng;
	packet.s_vN = s_vN;
	packet.s_vE = s_vE;
	packet.s_vD = s_vD;
	packet.s_pN = s_pN;
	packet.s_pE = s_pE;
	packet.s_pD = s_pD;
	packet.s_magX = s_magX;
	packet.s_magY = s_magY;
	packet.s_magZ = s_magZ;
	packet.s_vtas = s_vtas;
	packet.s_rng = s_rng;
	packet.fused_vNED = fused_vNED;
	packet.fused_pNE = fused_pNE;
	packet.fused_pD = fused_pD;
	packet.fused_magXYZ = fused_magXYZ;
	packet.fused_vtas = fused_vtas;
	packet.fused_rng = fused_rng;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_EKF_INNOV, (const char *)&packet, MAVLINK_MSG_ID_EKF_INNOV_LEN, MAVLINK_MSG_ID_EKF_INNOV_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_EKF_INNOV, (const char *)&packet, MAVLINK_MSG_ID_EKF_INNOV_LEN);
#endif
#endif
}

#if MAVLINK_MSG_ID_EKF_INNOV_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_ekf_innov_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint64_t time_usec, float vN, float vE, float vD, float pN, float pE, float pD, float magX, float magY, float magZ, float vtas, float rng, float s_vN, float s_vE, float s_vD, float s_pN, float s_pE, float s_pD, float s_magX, float s_magY, float s_magZ, float s_vtas, float s_rng, uint8_t fused_vNED, uint8_t fused_pNE, uint8_t fused_pD, uint8_t fused_magXYZ, uint8_t fused_vtas, uint8_t fused_rng)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char *buf = (char *)msgbuf;
	_mav_put_uint64_t(buf, 0, time_usec);
	_mav_put_float(buf, 8, vN);
	_mav_put_float(buf, 12, vE);
	_mav_put_float(buf, 16, vD);
	_mav_put_float(buf, 20, pN);
	_mav_put_float(buf, 24, pE);
	_mav_put_float(buf, 28, pD);
	_mav_put_float(buf, 32, magX);
	_mav_put_float(buf, 36, magY);
	_mav_put_float(buf, 40, magZ);
	_mav_put_float(buf, 44, vtas);
	_mav_put_float(buf, 48, rng);
	_mav_put_float(buf, 52, s_vN);
	_mav_put_float(buf, 56, s_vE);
	_mav_put_float(buf, 60, s_vD);
	_mav_put_float(buf, 64, s_pN);
	_mav_put_float(buf, 68, s_pE);
	_mav_put_float(buf, 72, s_pD);
	_mav_put_float(buf, 76, s_magX);
	_mav_put_float(buf, 80, s_magY);
	_mav_put_float(buf, 84, s_magZ);
	_mav_put_float(buf, 88, s_vtas);
	_mav_put_float(buf, 92, s_rng);
	_mav_put_uint8_t(buf, 96, fused_vNED);
	_mav_put_uint8_t(buf, 97, fused_pNE);
	_mav_put_uint8_t(buf, 98, fused_pD);
	_mav_put_uint8_t(buf, 99, fused_magXYZ);
	_mav_put_uint8_t(buf, 100, fused_vtas);
	_mav_put_uint8_t(buf, 101, fused_rng);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_EKF_INNOV, buf, MAVLINK_MSG_ID_EKF_INNOV_LEN, MAVLINK_MSG_ID_EKF_INNOV_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_EKF_INNOV, buf, MAVLINK_MSG_ID_EKF_INNOV_LEN);
#endif
#else
	mavlink_ekf_innov_t *packet = (mavlink_ekf_innov_t *)msgbuf;
	packet->time_usec = time_usec;
	packet->vN = vN;
	packet->vE = vE;
	packet->vD = vD;
	packet->pN = pN;
	packet->pE = pE;
	packet->pD = pD;
	packet->magX = magX;
	packet->magY = magY;
	packet->magZ = magZ;
	packet->vtas = vtas;
	packet->rng = rng;
	packet->s_vN = s_vN;
	packet->s_vE = s_vE;
	packet->s_vD = s_vD;
	packet->s_pN = s_pN;
	packet->s_pE = s_pE;
	packet->s_pD = s_pD;
	packet->s_magX = s_magX;
	packet->s_magY = s_magY;
	packet->s_magZ = s_magZ;
	packet->s_vtas = s_vtas;
	packet->s_rng = s_rng;
	packet->fused_vNED = fused_vNED;
	packet->fused_pNE = fused_pNE;
	packet->fused_pD = fused_pD;
	packet->fused_magXYZ = fused_magXYZ;
	packet->fused_vtas = fused_vtas;
	packet->fused_rng = fused_rng;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_EKF_INNOV, (const char *)packet, MAVLINK_MSG_ID_EKF_INNOV_LEN, MAVLINK_MSG_ID_EKF_INNOV_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_EKF_INNOV, (const char *)packet, MAVLINK_MSG_ID_EKF_INNOV_LEN);
#endif
#endif
}
#endif

#endif

// MESSAGE EKF_INNOV UNPACKING


/**
 * @brief Get field time_usec from ekf_innov message
 *
 * @return Timestamp
 */
static inline uint64_t mavlink_msg_ekf_innov_get_time_usec(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint64_t(msg,  0);
#else
	return mav_get_uint64_t_c2000(&(msg->payload64[0]),  0);
#endif
}

/**
 * @brief Get field vN from ekf_innov message
 *
 * @return Innovation: Velocity N-Direction
 */
static inline float mavlink_msg_ekf_innov_get_vN(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  8);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  8);
#endif
}

/**
 * @brief Get field vE from ekf_innov message
 *
 * @return Innovation: Velocity E-Direction
 */
static inline float mavlink_msg_ekf_innov_get_vE(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  12);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  12);
#endif
}

/**
 * @brief Get field vD from ekf_innov message
 *
 * @return Innovation: Velocity D-Direction
 */
static inline float mavlink_msg_ekf_innov_get_vD(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  16);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  16);
#endif
}

/**
 * @brief Get field pN from ekf_innov message
 *
 * @return Innovation: Position N-Direction
 */
static inline float mavlink_msg_ekf_innov_get_pN(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  20);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  20);
#endif
}

/**
 * @brief Get field pE from ekf_innov message
 *
 * @return Innovation: Position E-Direction
 */
static inline float mavlink_msg_ekf_innov_get_pE(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  24);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  24);
#endif
}

/**
 * @brief Get field pD from ekf_innov message
 *
 * @return Innovation: Position D-Direction
 */
static inline float mavlink_msg_ekf_innov_get_pD(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  28);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  28);
#endif
}

/**
 * @brief Get field magX from ekf_innov message
 *
 * @return Innovation: Magnetometer X-Direction
 */
static inline float mavlink_msg_ekf_innov_get_magX(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  32);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  32);
#endif
}

/**
 * @brief Get field magY from ekf_innov message
 *
 * @return Innovation: Magnetometer Y-Direction
 */
static inline float mavlink_msg_ekf_innov_get_magY(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  36);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  36);
#endif
}

/**
 * @brief Get field magZ from ekf_innov message
 *
 * @return Innovation: Magnetometer Z-Direction
 */
static inline float mavlink_msg_ekf_innov_get_magZ(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  40);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  40);
#endif
}

/**
 * @brief Get field vtas from ekf_innov message
 *
 * @return Innovation: Airspeed
 */
static inline float mavlink_msg_ekf_innov_get_vtas(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  44);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  44);
#endif
}

/**
 * @brief Get field rng from ekf_innov message
 *
 * @return Innovation: Range Data
 */
static inline float mavlink_msg_ekf_innov_get_rng(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  48);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  48);
#endif
}

/**
 * @brief Get field s_vN from ekf_innov message
 *
 * @return Innovation Standard Deviation: Velocity N-Direction
 */
static inline float mavlink_msg_ekf_innov_get_s_vN(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  52);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  52);
#endif
}

/**
 * @brief Get field s_vE from ekf_innov message
 *
 * @return Innovation Standard Deviation: Velocity E-Direction
 */
static inline float mavlink_msg_ekf_innov_get_s_vE(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  56);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  56);
#endif
}

/**
 * @brief Get field s_vD from ekf_innov message
 *
 * @return Innovation Standard Deviation: Velocity D-Direction
 */
static inline float mavlink_msg_ekf_innov_get_s_vD(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  60);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  60);
#endif
}

/**
 * @brief Get field s_pN from ekf_innov message
 *
 * @return Innovation Standard Deviation: Position N-Direction
 */
static inline float mavlink_msg_ekf_innov_get_s_pN(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  64);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  64);
#endif
}

/**
 * @brief Get field s_pE from ekf_innov message
 *
 * @return Innovation Standard Deviation: Position E-Direction
 */
static inline float mavlink_msg_ekf_innov_get_s_pE(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  68);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  68);
#endif
}

/**
 * @brief Get field s_pD from ekf_innov message
 *
 * @return Innovation Standard Deviation: Position D-Direction
 */
static inline float mavlink_msg_ekf_innov_get_s_pD(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  72);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  72);
#endif
}

/**
 * @brief Get field s_magX from ekf_innov message
 *
 * @return Innovation Standard Deviation: Magnetometer X-Direction
 */
static inline float mavlink_msg_ekf_innov_get_s_magX(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  76);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  76);
#endif
}

/**
 * @brief Get field s_magY from ekf_innov message
 *
 * @return Innovation Standard Deviation: Magnetometer Y-Direction
 */
static inline float mavlink_msg_ekf_innov_get_s_magY(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  80);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  80);
#endif
}

/**
 * @brief Get field s_magZ from ekf_innov message
 *
 * @return Innovation Standard Deviation: Magnetometer Z-Direction
 */
static inline float mavlink_msg_ekf_innov_get_s_magZ(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  84);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  84);
#endif
}

/**
 * @brief Get field s_vtas from ekf_innov message
 *
 * @return Innovation Standard Deviation: Airspeed
 */
static inline float mavlink_msg_ekf_innov_get_s_vtas(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  88);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  88);
#endif
}

/**
 * @brief Get field s_rng from ekf_innov message
 *
 * @return Innovation Standard Deviation: Range Data
 */
static inline float mavlink_msg_ekf_innov_get_s_rng(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  92);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  92);
#endif
}

/**
 * @brief Get field fused_vNED from ekf_innov message
 *
 * @return Has been fused (is valid)?: Velocity NED-Frame
 */
static inline uint8_t mavlink_msg_ekf_innov_get_fused_vNED(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  96);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  96);
#endif
}

/**
 * @brief Get field fused_pNE from ekf_innov message
 *
 * @return Has been fused (is valid)?: Position NE-Frame
 */
static inline uint8_t mavlink_msg_ekf_innov_get_fused_pNE(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  97);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  97);
#endif
}

/**
 * @brief Get field fused_pD from ekf_innov message
 *
 * @return Has been fused (is valid)?: Position D-Direction
 */
static inline uint8_t mavlink_msg_ekf_innov_get_fused_pD(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  98);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  98);
#endif
}

/**
 * @brief Get field fused_magXYZ from ekf_innov message
 *
 * @return Has been fused (is valid)?: Magnetometer XYZ-Frame
 */
static inline uint8_t mavlink_msg_ekf_innov_get_fused_magXYZ(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  99);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  99);
#endif
}

/**
 * @brief Get field fused_vtas from ekf_innov message
 *
 * @return Has been fused (is valid)?: Airspeed
 */
static inline uint8_t mavlink_msg_ekf_innov_get_fused_vtas(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  100);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  100);
#endif
}

/**
 * @brief Get field fused_rng from ekf_innov message
 *
 * @return Has been fused (is valid)?: Range Data
 */
static inline uint8_t mavlink_msg_ekf_innov_get_fused_rng(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint8_t(msg,  101);
#else
	return mav_get_uint8_t_c2000(&(msg->payload64[0]),  101);
#endif
}

/**
 * @brief Decode a ekf_innov message into a struct
 *
 * @param msg The message to decode
 * @param ekf_innov C-struct to decode the message contents into
 */
static inline void mavlink_msg_ekf_innov_decode(const mavlink_message_t* msg, mavlink_ekf_innov_t* ekf_innov)
{
#if MAVLINK_NEED_BYTE_SWAP || MAVLINK_C2000
	ekf_innov->time_usec = mavlink_msg_ekf_innov_get_time_usec(msg);
	ekf_innov->vN = mavlink_msg_ekf_innov_get_vN(msg);
	ekf_innov->vE = mavlink_msg_ekf_innov_get_vE(msg);
	ekf_innov->vD = mavlink_msg_ekf_innov_get_vD(msg);
	ekf_innov->pN = mavlink_msg_ekf_innov_get_pN(msg);
	ekf_innov->pE = mavlink_msg_ekf_innov_get_pE(msg);
	ekf_innov->pD = mavlink_msg_ekf_innov_get_pD(msg);
	ekf_innov->magX = mavlink_msg_ekf_innov_get_magX(msg);
	ekf_innov->magY = mavlink_msg_ekf_innov_get_magY(msg);
	ekf_innov->magZ = mavlink_msg_ekf_innov_get_magZ(msg);
	ekf_innov->vtas = mavlink_msg_ekf_innov_get_vtas(msg);
	ekf_innov->rng = mavlink_msg_ekf_innov_get_rng(msg);
	ekf_innov->s_vN = mavlink_msg_ekf_innov_get_s_vN(msg);
	ekf_innov->s_vE = mavlink_msg_ekf_innov_get_s_vE(msg);
	ekf_innov->s_vD = mavlink_msg_ekf_innov_get_s_vD(msg);
	ekf_innov->s_pN = mavlink_msg_ekf_innov_get_s_pN(msg);
	ekf_innov->s_pE = mavlink_msg_ekf_innov_get_s_pE(msg);
	ekf_innov->s_pD = mavlink_msg_ekf_innov_get_s_pD(msg);
	ekf_innov->s_magX = mavlink_msg_ekf_innov_get_s_magX(msg);
	ekf_innov->s_magY = mavlink_msg_ekf_innov_get_s_magY(msg);
	ekf_innov->s_magZ = mavlink_msg_ekf_innov_get_s_magZ(msg);
	ekf_innov->s_vtas = mavlink_msg_ekf_innov_get_s_vtas(msg);
	ekf_innov->s_rng = mavlink_msg_ekf_innov_get_s_rng(msg);
	ekf_innov->fused_vNED = mavlink_msg_ekf_innov_get_fused_vNED(msg);
	ekf_innov->fused_pNE = mavlink_msg_ekf_innov_get_fused_pNE(msg);
	ekf_innov->fused_pD = mavlink_msg_ekf_innov_get_fused_pD(msg);
	ekf_innov->fused_magXYZ = mavlink_msg_ekf_innov_get_fused_magXYZ(msg);
	ekf_innov->fused_vtas = mavlink_msg_ekf_innov_get_fused_vtas(msg);
	ekf_innov->fused_rng = mavlink_msg_ekf_innov_get_fused_rng(msg);
#else
	memcpy(ekf_innov, _MAV_PAYLOAD(msg), MAVLINK_MSG_ID_EKF_INNOV_LEN);
#endif
}
