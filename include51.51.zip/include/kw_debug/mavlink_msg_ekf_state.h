// MESSAGE EKF_STATE PACKING

#if MAVLINK_C2000
#include "../protocol_c2000.h"
#endif

#define MAVLINK_MSG_ID_EKF_STATE 190

typedef struct __mavlink_ekf_state_t
{
 uint64_t time_usec; /*< Timestamp*/
 float qw; /*< Quaternion qNEDXYZ*/
 float qx; /*< Quaternion qNEDXYZ*/
 float qy; /*< Quaternion qNEDXYZ*/
 float qz; /*< Quaternion qNEDXYZ*/
 float vN; /*< Velocity N-Direction (NED-Frame)*/
 float vE; /*< Velocity E-Direction (NED-Frame)*/
 float vD; /*< Velocity D-Direction (NED-Frame)*/
 float pN; /*< Position N-Direction (NED-Frame)*/
 float pE; /*< Position E-Direction (NED-Frame)*/
 float pD; /*< Position D-Direction (NED-Frame)*/
 float dBaX; /*< Delta Angle Bias in X-Direction (XYZ-Frame)*/
 float dBaY; /*< Delta Angle Bias in Y-Direction (XYZ-Frame)*/
 float dBaZ; /*< Delta Angle Bias in Z-Direction (XYZ-Frame)*/
 float dBvZ; /*< Delta Velocity Bias in Z-Direction (XYZ-Frame)*/
 float windX; /*< Wind Estimate in X-Direction (XYZ-Frame)*/
 float windY; /*< Wind Estimate in Y-Direction (XYZ-Frame)*/
 float magN; /*< Magnetic Vector in N-Direction (NED-Frame)*/
 float magE; /*< Magnetic Vector In E-Direction (NED-Frame)*/
 float magD; /*< Magnetic Vector In D-Direction (NED-Frame)*/
 float BmagX; /*< Magnetic Vector Bias in X-Direction (XYZ-Frame)*/
 float BmagY; /*< Magnetic Vector Bias in Y-Direction (XYZ-Frame)*/
 float BmagZ; /*< Magnetic Vector Bias in Z-Direction (XYZ-Frame)*/
 float s_qw; /*< Sigma: Quaternion qNEDXYZ*/
 float s_qx; /*< Sigma: Quaternion qNEDXYZ*/
 float s_qy; /*< Sigma: Quaternion qNEDXYZ*/
 float s_qz; /*< Sigma: Quaternion qNEDXYZ*/
 float s_vN; /*< Sigma: Velocity N-Direction (NED-Frame)*/
 float s_vE; /*< Sigma: Velocity E-Direction (NED-Frame)*/
 float s_vD; /*< Sigma: Velocity D-Direction (NED-Frame)*/
 float s_pN; /*< Sigma: Position N-Direction (NED-Frame)*/
 float s_pE; /*< Sigma: Position E-Direction (NED-Frame)*/
 float s_pD; /*< Sigma: Position D-Direction (NED-Frame)*/
 float s_dBaX; /*< Sigma: Delta Angle Bias in X-Direction (XYZ-Frame)*/
 float s_dBaY; /*< Sigma: Delta Angle Bias in Y-Direction (XYZ-Frame)*/
 float s_dBaZ; /*< Sigma: Delta Angle Bias in Z-Direction (XYZ-Frame)*/
 float s_dBvZ; /*< Sigma: Delta Velocity Bias in Z-Direction (XYZ-Frame)*/
 float s_windX; /*< Sigma: Wind Estimate in X-Direction (XYZ-Frame)*/
 float s_windY; /*< Sigma: Wind Estimate in Y-Direction (XYZ-Frame)*/
 float s_magN; /*< Sigma: Magnetic Vector in N-Direction (NED-Frame)*/
 float s_magE; /*< Sigma: Magnetic Vector in E-Direction (NED-Frame)*/
 float s_magD; /*< Sigma: Magnetic Vector in D-Direction (NED-Frame)*/
 float s_BmagX; /*< Sigma: Magnetic Vector Bias in X-Direction (XYZ-Frame)*/
 float s_BmagY; /*< Sigma: Magnetic Vector Bias in Y-Direction (XYZ-Frame)*/
 float s_BmagZ; /*< Sigma: Magnetic Vector Bias in Z-Direction (XYZ-Frame)*/
} mavlink_ekf_state_t;

#define MAVLINK_MSG_ID_EKF_STATE_LEN 184
#define MAVLINK_MSG_ID_190_LEN 184

#define MAVLINK_MSG_ID_EKF_STATE_CRC 120
#define MAVLINK_MSG_ID_190_CRC 120



#define MAVLINK_MESSAGE_INFO_EKF_STATE { \
	"EKF_STATE", \
	45, \
	{  { "time_usec", NULL, MAVLINK_TYPE_UINT64_T, 0, 0, offsetof(mavlink_ekf_state_t, time_usec) }, \
         { "qw", NULL, MAVLINK_TYPE_FLOAT, 0, 8, offsetof(mavlink_ekf_state_t, qw) }, \
         { "qx", NULL, MAVLINK_TYPE_FLOAT, 0, 12, offsetof(mavlink_ekf_state_t, qx) }, \
         { "qy", NULL, MAVLINK_TYPE_FLOAT, 0, 16, offsetof(mavlink_ekf_state_t, qy) }, \
         { "qz", NULL, MAVLINK_TYPE_FLOAT, 0, 20, offsetof(mavlink_ekf_state_t, qz) }, \
         { "vN", NULL, MAVLINK_TYPE_FLOAT, 0, 24, offsetof(mavlink_ekf_state_t, vN) }, \
         { "vE", NULL, MAVLINK_TYPE_FLOAT, 0, 28, offsetof(mavlink_ekf_state_t, vE) }, \
         { "vD", NULL, MAVLINK_TYPE_FLOAT, 0, 32, offsetof(mavlink_ekf_state_t, vD) }, \
         { "pN", NULL, MAVLINK_TYPE_FLOAT, 0, 36, offsetof(mavlink_ekf_state_t, pN) }, \
         { "pE", NULL, MAVLINK_TYPE_FLOAT, 0, 40, offsetof(mavlink_ekf_state_t, pE) }, \
         { "pD", NULL, MAVLINK_TYPE_FLOAT, 0, 44, offsetof(mavlink_ekf_state_t, pD) }, \
         { "dBaX", NULL, MAVLINK_TYPE_FLOAT, 0, 48, offsetof(mavlink_ekf_state_t, dBaX) }, \
         { "dBaY", NULL, MAVLINK_TYPE_FLOAT, 0, 52, offsetof(mavlink_ekf_state_t, dBaY) }, \
         { "dBaZ", NULL, MAVLINK_TYPE_FLOAT, 0, 56, offsetof(mavlink_ekf_state_t, dBaZ) }, \
         { "dBvZ", NULL, MAVLINK_TYPE_FLOAT, 0, 60, offsetof(mavlink_ekf_state_t, dBvZ) }, \
         { "windX", NULL, MAVLINK_TYPE_FLOAT, 0, 64, offsetof(mavlink_ekf_state_t, windX) }, \
         { "windY", NULL, MAVLINK_TYPE_FLOAT, 0, 68, offsetof(mavlink_ekf_state_t, windY) }, \
         { "magN", NULL, MAVLINK_TYPE_FLOAT, 0, 72, offsetof(mavlink_ekf_state_t, magN) }, \
         { "magE", NULL, MAVLINK_TYPE_FLOAT, 0, 76, offsetof(mavlink_ekf_state_t, magE) }, \
         { "magD", NULL, MAVLINK_TYPE_FLOAT, 0, 80, offsetof(mavlink_ekf_state_t, magD) }, \
         { "BmagX", NULL, MAVLINK_TYPE_FLOAT, 0, 84, offsetof(mavlink_ekf_state_t, BmagX) }, \
         { "BmagY", NULL, MAVLINK_TYPE_FLOAT, 0, 88, offsetof(mavlink_ekf_state_t, BmagY) }, \
         { "BmagZ", NULL, MAVLINK_TYPE_FLOAT, 0, 92, offsetof(mavlink_ekf_state_t, BmagZ) }, \
         { "s_qw", NULL, MAVLINK_TYPE_FLOAT, 0, 96, offsetof(mavlink_ekf_state_t, s_qw) }, \
         { "s_qx", NULL, MAVLINK_TYPE_FLOAT, 0, 100, offsetof(mavlink_ekf_state_t, s_qx) }, \
         { "s_qy", NULL, MAVLINK_TYPE_FLOAT, 0, 104, offsetof(mavlink_ekf_state_t, s_qy) }, \
         { "s_qz", NULL, MAVLINK_TYPE_FLOAT, 0, 108, offsetof(mavlink_ekf_state_t, s_qz) }, \
         { "s_vN", NULL, MAVLINK_TYPE_FLOAT, 0, 112, offsetof(mavlink_ekf_state_t, s_vN) }, \
         { "s_vE", NULL, MAVLINK_TYPE_FLOAT, 0, 116, offsetof(mavlink_ekf_state_t, s_vE) }, \
         { "s_vD", NULL, MAVLINK_TYPE_FLOAT, 0, 120, offsetof(mavlink_ekf_state_t, s_vD) }, \
         { "s_pN", NULL, MAVLINK_TYPE_FLOAT, 0, 124, offsetof(mavlink_ekf_state_t, s_pN) }, \
         { "s_pE", NULL, MAVLINK_TYPE_FLOAT, 0, 128, offsetof(mavlink_ekf_state_t, s_pE) }, \
         { "s_pD", NULL, MAVLINK_TYPE_FLOAT, 0, 132, offsetof(mavlink_ekf_state_t, s_pD) }, \
         { "s_dBaX", NULL, MAVLINK_TYPE_FLOAT, 0, 136, offsetof(mavlink_ekf_state_t, s_dBaX) }, \
         { "s_dBaY", NULL, MAVLINK_TYPE_FLOAT, 0, 140, offsetof(mavlink_ekf_state_t, s_dBaY) }, \
         { "s_dBaZ", NULL, MAVLINK_TYPE_FLOAT, 0, 144, offsetof(mavlink_ekf_state_t, s_dBaZ) }, \
         { "s_dBvZ", NULL, MAVLINK_TYPE_FLOAT, 0, 148, offsetof(mavlink_ekf_state_t, s_dBvZ) }, \
         { "s_windX", NULL, MAVLINK_TYPE_FLOAT, 0, 152, offsetof(mavlink_ekf_state_t, s_windX) }, \
         { "s_windY", NULL, MAVLINK_TYPE_FLOAT, 0, 156, offsetof(mavlink_ekf_state_t, s_windY) }, \
         { "s_magN", NULL, MAVLINK_TYPE_FLOAT, 0, 160, offsetof(mavlink_ekf_state_t, s_magN) }, \
         { "s_magE", NULL, MAVLINK_TYPE_FLOAT, 0, 164, offsetof(mavlink_ekf_state_t, s_magE) }, \
         { "s_magD", NULL, MAVLINK_TYPE_FLOAT, 0, 168, offsetof(mavlink_ekf_state_t, s_magD) }, \
         { "s_BmagX", NULL, MAVLINK_TYPE_FLOAT, 0, 172, offsetof(mavlink_ekf_state_t, s_BmagX) }, \
         { "s_BmagY", NULL, MAVLINK_TYPE_FLOAT, 0, 176, offsetof(mavlink_ekf_state_t, s_BmagY) }, \
         { "s_BmagZ", NULL, MAVLINK_TYPE_FLOAT, 0, 180, offsetof(mavlink_ekf_state_t, s_BmagZ) }, \
         } \
}


/**
 * @brief Pack a ekf_state message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param time_usec Timestamp
 * @param qw Quaternion qNEDXYZ
 * @param qx Quaternion qNEDXYZ
 * @param qy Quaternion qNEDXYZ
 * @param qz Quaternion qNEDXYZ
 * @param vN Velocity N-Direction (NED-Frame)
 * @param vE Velocity E-Direction (NED-Frame)
 * @param vD Velocity D-Direction (NED-Frame)
 * @param pN Position N-Direction (NED-Frame)
 * @param pE Position E-Direction (NED-Frame)
 * @param pD Position D-Direction (NED-Frame)
 * @param dBaX Delta Angle Bias in X-Direction (XYZ-Frame)
 * @param dBaY Delta Angle Bias in Y-Direction (XYZ-Frame)
 * @param dBaZ Delta Angle Bias in Z-Direction (XYZ-Frame)
 * @param dBvZ Delta Velocity Bias in Z-Direction (XYZ-Frame)
 * @param windX Wind Estimate in X-Direction (XYZ-Frame)
 * @param windY Wind Estimate in Y-Direction (XYZ-Frame)
 * @param magN Magnetic Vector in N-Direction (NED-Frame)
 * @param magE Magnetic Vector In E-Direction (NED-Frame)
 * @param magD Magnetic Vector In D-Direction (NED-Frame)
 * @param BmagX Magnetic Vector Bias in X-Direction (XYZ-Frame)
 * @param BmagY Magnetic Vector Bias in Y-Direction (XYZ-Frame)
 * @param BmagZ Magnetic Vector Bias in Z-Direction (XYZ-Frame)
 * @param s_qw Sigma: Quaternion qNEDXYZ
 * @param s_qx Sigma: Quaternion qNEDXYZ
 * @param s_qy Sigma: Quaternion qNEDXYZ
 * @param s_qz Sigma: Quaternion qNEDXYZ
 * @param s_vN Sigma: Velocity N-Direction (NED-Frame)
 * @param s_vE Sigma: Velocity E-Direction (NED-Frame)
 * @param s_vD Sigma: Velocity D-Direction (NED-Frame)
 * @param s_pN Sigma: Position N-Direction (NED-Frame)
 * @param s_pE Sigma: Position E-Direction (NED-Frame)
 * @param s_pD Sigma: Position D-Direction (NED-Frame)
 * @param s_dBaX Sigma: Delta Angle Bias in X-Direction (XYZ-Frame)
 * @param s_dBaY Sigma: Delta Angle Bias in Y-Direction (XYZ-Frame)
 * @param s_dBaZ Sigma: Delta Angle Bias in Z-Direction (XYZ-Frame)
 * @param s_dBvZ Sigma: Delta Velocity Bias in Z-Direction (XYZ-Frame)
 * @param s_windX Sigma: Wind Estimate in X-Direction (XYZ-Frame)
 * @param s_windY Sigma: Wind Estimate in Y-Direction (XYZ-Frame)
 * @param s_magN Sigma: Magnetic Vector in N-Direction (NED-Frame)
 * @param s_magE Sigma: Magnetic Vector in E-Direction (NED-Frame)
 * @param s_magD Sigma: Magnetic Vector in D-Direction (NED-Frame)
 * @param s_BmagX Sigma: Magnetic Vector Bias in X-Direction (XYZ-Frame)
 * @param s_BmagY Sigma: Magnetic Vector Bias in Y-Direction (XYZ-Frame)
 * @param s_BmagZ Sigma: Magnetic Vector Bias in Z-Direction (XYZ-Frame)
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ekf_state_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
						       uint64_t time_usec, float qw, float qx, float qy, float qz, float vN, float vE, float vD, float pN, float pE, float pD, float dBaX, float dBaY, float dBaZ, float dBvZ, float windX, float windY, float magN, float magE, float magD, float BmagX, float BmagY, float BmagZ, float s_qw, float s_qx, float s_qy, float s_qz, float s_vN, float s_vE, float s_vD, float s_pN, float s_pE, float s_pD, float s_dBaX, float s_dBaY, float s_dBaZ, float s_dBvZ, float s_windX, float s_windY, float s_magN, float s_magE, float s_magD, float s_BmagX, float s_BmagY, float s_BmagZ)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_EKF_STATE_LEN];
	_mav_put_uint64_t(buf, 0, time_usec);
	_mav_put_float(buf, 8, qw);
	_mav_put_float(buf, 12, qx);
	_mav_put_float(buf, 16, qy);
	_mav_put_float(buf, 20, qz);
	_mav_put_float(buf, 24, vN);
	_mav_put_float(buf, 28, vE);
	_mav_put_float(buf, 32, vD);
	_mav_put_float(buf, 36, pN);
	_mav_put_float(buf, 40, pE);
	_mav_put_float(buf, 44, pD);
	_mav_put_float(buf, 48, dBaX);
	_mav_put_float(buf, 52, dBaY);
	_mav_put_float(buf, 56, dBaZ);
	_mav_put_float(buf, 60, dBvZ);
	_mav_put_float(buf, 64, windX);
	_mav_put_float(buf, 68, windY);
	_mav_put_float(buf, 72, magN);
	_mav_put_float(buf, 76, magE);
	_mav_put_float(buf, 80, magD);
	_mav_put_float(buf, 84, BmagX);
	_mav_put_float(buf, 88, BmagY);
	_mav_put_float(buf, 92, BmagZ);
	_mav_put_float(buf, 96, s_qw);
	_mav_put_float(buf, 100, s_qx);
	_mav_put_float(buf, 104, s_qy);
	_mav_put_float(buf, 108, s_qz);
	_mav_put_float(buf, 112, s_vN);
	_mav_put_float(buf, 116, s_vE);
	_mav_put_float(buf, 120, s_vD);
	_mav_put_float(buf, 124, s_pN);
	_mav_put_float(buf, 128, s_pE);
	_mav_put_float(buf, 132, s_pD);
	_mav_put_float(buf, 136, s_dBaX);
	_mav_put_float(buf, 140, s_dBaY);
	_mav_put_float(buf, 144, s_dBaZ);
	_mav_put_float(buf, 148, s_dBvZ);
	_mav_put_float(buf, 152, s_windX);
	_mav_put_float(buf, 156, s_windY);
	_mav_put_float(buf, 160, s_magN);
	_mav_put_float(buf, 164, s_magE);
	_mav_put_float(buf, 168, s_magD);
	_mav_put_float(buf, 172, s_BmagX);
	_mav_put_float(buf, 176, s_BmagY);
	_mav_put_float(buf, 180, s_BmagZ);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_EKF_STATE_LEN);
#elif MAVLINK_C2000
		mav_put_uint64_t_c2000(&(msg->payload64[0]), 0, time_usec);
		mav_put_float_c2000(&(msg->payload64[0]), 8, qw);
		mav_put_float_c2000(&(msg->payload64[0]), 12, qx);
		mav_put_float_c2000(&(msg->payload64[0]), 16, qy);
		mav_put_float_c2000(&(msg->payload64[0]), 20, qz);
		mav_put_float_c2000(&(msg->payload64[0]), 24, vN);
		mav_put_float_c2000(&(msg->payload64[0]), 28, vE);
		mav_put_float_c2000(&(msg->payload64[0]), 32, vD);
		mav_put_float_c2000(&(msg->payload64[0]), 36, pN);
		mav_put_float_c2000(&(msg->payload64[0]), 40, pE);
		mav_put_float_c2000(&(msg->payload64[0]), 44, pD);
		mav_put_float_c2000(&(msg->payload64[0]), 48, dBaX);
		mav_put_float_c2000(&(msg->payload64[0]), 52, dBaY);
		mav_put_float_c2000(&(msg->payload64[0]), 56, dBaZ);
		mav_put_float_c2000(&(msg->payload64[0]), 60, dBvZ);
		mav_put_float_c2000(&(msg->payload64[0]), 64, windX);
		mav_put_float_c2000(&(msg->payload64[0]), 68, windY);
		mav_put_float_c2000(&(msg->payload64[0]), 72, magN);
		mav_put_float_c2000(&(msg->payload64[0]), 76, magE);
		mav_put_float_c2000(&(msg->payload64[0]), 80, magD);
		mav_put_float_c2000(&(msg->payload64[0]), 84, BmagX);
		mav_put_float_c2000(&(msg->payload64[0]), 88, BmagY);
		mav_put_float_c2000(&(msg->payload64[0]), 92, BmagZ);
		mav_put_float_c2000(&(msg->payload64[0]), 96, s_qw);
		mav_put_float_c2000(&(msg->payload64[0]), 100, s_qx);
		mav_put_float_c2000(&(msg->payload64[0]), 104, s_qy);
		mav_put_float_c2000(&(msg->payload64[0]), 108, s_qz);
		mav_put_float_c2000(&(msg->payload64[0]), 112, s_vN);
		mav_put_float_c2000(&(msg->payload64[0]), 116, s_vE);
		mav_put_float_c2000(&(msg->payload64[0]), 120, s_vD);
		mav_put_float_c2000(&(msg->payload64[0]), 124, s_pN);
		mav_put_float_c2000(&(msg->payload64[0]), 128, s_pE);
		mav_put_float_c2000(&(msg->payload64[0]), 132, s_pD);
		mav_put_float_c2000(&(msg->payload64[0]), 136, s_dBaX);
		mav_put_float_c2000(&(msg->payload64[0]), 140, s_dBaY);
		mav_put_float_c2000(&(msg->payload64[0]), 144, s_dBaZ);
		mav_put_float_c2000(&(msg->payload64[0]), 148, s_dBvZ);
		mav_put_float_c2000(&(msg->payload64[0]), 152, s_windX);
		mav_put_float_c2000(&(msg->payload64[0]), 156, s_windY);
		mav_put_float_c2000(&(msg->payload64[0]), 160, s_magN);
		mav_put_float_c2000(&(msg->payload64[0]), 164, s_magE);
		mav_put_float_c2000(&(msg->payload64[0]), 168, s_magD);
		mav_put_float_c2000(&(msg->payload64[0]), 172, s_BmagX);
		mav_put_float_c2000(&(msg->payload64[0]), 176, s_BmagY);
		mav_put_float_c2000(&(msg->payload64[0]), 180, s_BmagZ);
	
	
#else
	mavlink_ekf_state_t packet;
	packet.time_usec = time_usec;
	packet.qw = qw;
	packet.qx = qx;
	packet.qy = qy;
	packet.qz = qz;
	packet.vN = vN;
	packet.vE = vE;
	packet.vD = vD;
	packet.pN = pN;
	packet.pE = pE;
	packet.pD = pD;
	packet.dBaX = dBaX;
	packet.dBaY = dBaY;
	packet.dBaZ = dBaZ;
	packet.dBvZ = dBvZ;
	packet.windX = windX;
	packet.windY = windY;
	packet.magN = magN;
	packet.magE = magE;
	packet.magD = magD;
	packet.BmagX = BmagX;
	packet.BmagY = BmagY;
	packet.BmagZ = BmagZ;
	packet.s_qw = s_qw;
	packet.s_qx = s_qx;
	packet.s_qy = s_qy;
	packet.s_qz = s_qz;
	packet.s_vN = s_vN;
	packet.s_vE = s_vE;
	packet.s_vD = s_vD;
	packet.s_pN = s_pN;
	packet.s_pE = s_pE;
	packet.s_pD = s_pD;
	packet.s_dBaX = s_dBaX;
	packet.s_dBaY = s_dBaY;
	packet.s_dBaZ = s_dBaZ;
	packet.s_dBvZ = s_dBvZ;
	packet.s_windX = s_windX;
	packet.s_windY = s_windY;
	packet.s_magN = s_magN;
	packet.s_magE = s_magE;
	packet.s_magD = s_magD;
	packet.s_BmagX = s_BmagX;
	packet.s_BmagY = s_BmagY;
	packet.s_BmagZ = s_BmagZ;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_EKF_STATE_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_EKF_STATE;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_EKF_STATE_LEN, MAVLINK_MSG_ID_EKF_STATE_CRC);
#else
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_EKF_STATE_LEN);
#endif
}

/**
 * @brief Pack a ekf_state message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param time_usec Timestamp
 * @param qw Quaternion qNEDXYZ
 * @param qx Quaternion qNEDXYZ
 * @param qy Quaternion qNEDXYZ
 * @param qz Quaternion qNEDXYZ
 * @param vN Velocity N-Direction (NED-Frame)
 * @param vE Velocity E-Direction (NED-Frame)
 * @param vD Velocity D-Direction (NED-Frame)
 * @param pN Position N-Direction (NED-Frame)
 * @param pE Position E-Direction (NED-Frame)
 * @param pD Position D-Direction (NED-Frame)
 * @param dBaX Delta Angle Bias in X-Direction (XYZ-Frame)
 * @param dBaY Delta Angle Bias in Y-Direction (XYZ-Frame)
 * @param dBaZ Delta Angle Bias in Z-Direction (XYZ-Frame)
 * @param dBvZ Delta Velocity Bias in Z-Direction (XYZ-Frame)
 * @param windX Wind Estimate in X-Direction (XYZ-Frame)
 * @param windY Wind Estimate in Y-Direction (XYZ-Frame)
 * @param magN Magnetic Vector in N-Direction (NED-Frame)
 * @param magE Magnetic Vector In E-Direction (NED-Frame)
 * @param magD Magnetic Vector In D-Direction (NED-Frame)
 * @param BmagX Magnetic Vector Bias in X-Direction (XYZ-Frame)
 * @param BmagY Magnetic Vector Bias in Y-Direction (XYZ-Frame)
 * @param BmagZ Magnetic Vector Bias in Z-Direction (XYZ-Frame)
 * @param s_qw Sigma: Quaternion qNEDXYZ
 * @param s_qx Sigma: Quaternion qNEDXYZ
 * @param s_qy Sigma: Quaternion qNEDXYZ
 * @param s_qz Sigma: Quaternion qNEDXYZ
 * @param s_vN Sigma: Velocity N-Direction (NED-Frame)
 * @param s_vE Sigma: Velocity E-Direction (NED-Frame)
 * @param s_vD Sigma: Velocity D-Direction (NED-Frame)
 * @param s_pN Sigma: Position N-Direction (NED-Frame)
 * @param s_pE Sigma: Position E-Direction (NED-Frame)
 * @param s_pD Sigma: Position D-Direction (NED-Frame)
 * @param s_dBaX Sigma: Delta Angle Bias in X-Direction (XYZ-Frame)
 * @param s_dBaY Sigma: Delta Angle Bias in Y-Direction (XYZ-Frame)
 * @param s_dBaZ Sigma: Delta Angle Bias in Z-Direction (XYZ-Frame)
 * @param s_dBvZ Sigma: Delta Velocity Bias in Z-Direction (XYZ-Frame)
 * @param s_windX Sigma: Wind Estimate in X-Direction (XYZ-Frame)
 * @param s_windY Sigma: Wind Estimate in Y-Direction (XYZ-Frame)
 * @param s_magN Sigma: Magnetic Vector in N-Direction (NED-Frame)
 * @param s_magE Sigma: Magnetic Vector in E-Direction (NED-Frame)
 * @param s_magD Sigma: Magnetic Vector in D-Direction (NED-Frame)
 * @param s_BmagX Sigma: Magnetic Vector Bias in X-Direction (XYZ-Frame)
 * @param s_BmagY Sigma: Magnetic Vector Bias in Y-Direction (XYZ-Frame)
 * @param s_BmagZ Sigma: Magnetic Vector Bias in Z-Direction (XYZ-Frame)
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_ekf_state_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
							   mavlink_message_t* msg,
						           uint64_t time_usec,float qw,float qx,float qy,float qz,float vN,float vE,float vD,float pN,float pE,float pD,float dBaX,float dBaY,float dBaZ,float dBvZ,float windX,float windY,float magN,float magE,float magD,float BmagX,float BmagY,float BmagZ,float s_qw,float s_qx,float s_qy,float s_qz,float s_vN,float s_vE,float s_vD,float s_pN,float s_pE,float s_pD,float s_dBaX,float s_dBaY,float s_dBaZ,float s_dBvZ,float s_windX,float s_windY,float s_magN,float s_magE,float s_magD,float s_BmagX,float s_BmagY,float s_BmagZ)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_EKF_STATE_LEN];
	_mav_put_uint64_t(buf, 0, time_usec);
	_mav_put_float(buf, 8, qw);
	_mav_put_float(buf, 12, qx);
	_mav_put_float(buf, 16, qy);
	_mav_put_float(buf, 20, qz);
	_mav_put_float(buf, 24, vN);
	_mav_put_float(buf, 28, vE);
	_mav_put_float(buf, 32, vD);
	_mav_put_float(buf, 36, pN);
	_mav_put_float(buf, 40, pE);
	_mav_put_float(buf, 44, pD);
	_mav_put_float(buf, 48, dBaX);
	_mav_put_float(buf, 52, dBaY);
	_mav_put_float(buf, 56, dBaZ);
	_mav_put_float(buf, 60, dBvZ);
	_mav_put_float(buf, 64, windX);
	_mav_put_float(buf, 68, windY);
	_mav_put_float(buf, 72, magN);
	_mav_put_float(buf, 76, magE);
	_mav_put_float(buf, 80, magD);
	_mav_put_float(buf, 84, BmagX);
	_mav_put_float(buf, 88, BmagY);
	_mav_put_float(buf, 92, BmagZ);
	_mav_put_float(buf, 96, s_qw);
	_mav_put_float(buf, 100, s_qx);
	_mav_put_float(buf, 104, s_qy);
	_mav_put_float(buf, 108, s_qz);
	_mav_put_float(buf, 112, s_vN);
	_mav_put_float(buf, 116, s_vE);
	_mav_put_float(buf, 120, s_vD);
	_mav_put_float(buf, 124, s_pN);
	_mav_put_float(buf, 128, s_pE);
	_mav_put_float(buf, 132, s_pD);
	_mav_put_float(buf, 136, s_dBaX);
	_mav_put_float(buf, 140, s_dBaY);
	_mav_put_float(buf, 144, s_dBaZ);
	_mav_put_float(buf, 148, s_dBvZ);
	_mav_put_float(buf, 152, s_windX);
	_mav_put_float(buf, 156, s_windY);
	_mav_put_float(buf, 160, s_magN);
	_mav_put_float(buf, 164, s_magE);
	_mav_put_float(buf, 168, s_magD);
	_mav_put_float(buf, 172, s_BmagX);
	_mav_put_float(buf, 176, s_BmagY);
	_mav_put_float(buf, 180, s_BmagZ);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_EKF_STATE_LEN);
#else
	mavlink_ekf_state_t packet;
	packet.time_usec = time_usec;
	packet.qw = qw;
	packet.qx = qx;
	packet.qy = qy;
	packet.qz = qz;
	packet.vN = vN;
	packet.vE = vE;
	packet.vD = vD;
	packet.pN = pN;
	packet.pE = pE;
	packet.pD = pD;
	packet.dBaX = dBaX;
	packet.dBaY = dBaY;
	packet.dBaZ = dBaZ;
	packet.dBvZ = dBvZ;
	packet.windX = windX;
	packet.windY = windY;
	packet.magN = magN;
	packet.magE = magE;
	packet.magD = magD;
	packet.BmagX = BmagX;
	packet.BmagY = BmagY;
	packet.BmagZ = BmagZ;
	packet.s_qw = s_qw;
	packet.s_qx = s_qx;
	packet.s_qy = s_qy;
	packet.s_qz = s_qz;
	packet.s_vN = s_vN;
	packet.s_vE = s_vE;
	packet.s_vD = s_vD;
	packet.s_pN = s_pN;
	packet.s_pE = s_pE;
	packet.s_pD = s_pD;
	packet.s_dBaX = s_dBaX;
	packet.s_dBaY = s_dBaY;
	packet.s_dBaZ = s_dBaZ;
	packet.s_dBvZ = s_dBvZ;
	packet.s_windX = s_windX;
	packet.s_windY = s_windY;
	packet.s_magN = s_magN;
	packet.s_magE = s_magE;
	packet.s_magD = s_magD;
	packet.s_BmagX = s_BmagX;
	packet.s_BmagY = s_BmagY;
	packet.s_BmagZ = s_BmagZ;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_EKF_STATE_LEN);
#endif

	msg->msgid = MAVLINK_MSG_ID_EKF_STATE;
#if MAVLINK_CRC_EXTRA
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_EKF_STATE_LEN, MAVLINK_MSG_ID_EKF_STATE_CRC);
#else
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_EKF_STATE_LEN);
#endif
}

/**
 * @brief Encode a ekf_state struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param ekf_state C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ekf_state_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_ekf_state_t* ekf_state)
{
	return mavlink_msg_ekf_state_pack(system_id, component_id, msg, ekf_state->time_usec, ekf_state->qw, ekf_state->qx, ekf_state->qy, ekf_state->qz, ekf_state->vN, ekf_state->vE, ekf_state->vD, ekf_state->pN, ekf_state->pE, ekf_state->pD, ekf_state->dBaX, ekf_state->dBaY, ekf_state->dBaZ, ekf_state->dBvZ, ekf_state->windX, ekf_state->windY, ekf_state->magN, ekf_state->magE, ekf_state->magD, ekf_state->BmagX, ekf_state->BmagY, ekf_state->BmagZ, ekf_state->s_qw, ekf_state->s_qx, ekf_state->s_qy, ekf_state->s_qz, ekf_state->s_vN, ekf_state->s_vE, ekf_state->s_vD, ekf_state->s_pN, ekf_state->s_pE, ekf_state->s_pD, ekf_state->s_dBaX, ekf_state->s_dBaY, ekf_state->s_dBaZ, ekf_state->s_dBvZ, ekf_state->s_windX, ekf_state->s_windY, ekf_state->s_magN, ekf_state->s_magE, ekf_state->s_magD, ekf_state->s_BmagX, ekf_state->s_BmagY, ekf_state->s_BmagZ);
}

/**
 * @brief Encode a ekf_state struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param ekf_state C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_ekf_state_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_ekf_state_t* ekf_state)
{
	return mavlink_msg_ekf_state_pack_chan(system_id, component_id, chan, msg, ekf_state->time_usec, ekf_state->qw, ekf_state->qx, ekf_state->qy, ekf_state->qz, ekf_state->vN, ekf_state->vE, ekf_state->vD, ekf_state->pN, ekf_state->pE, ekf_state->pD, ekf_state->dBaX, ekf_state->dBaY, ekf_state->dBaZ, ekf_state->dBvZ, ekf_state->windX, ekf_state->windY, ekf_state->magN, ekf_state->magE, ekf_state->magD, ekf_state->BmagX, ekf_state->BmagY, ekf_state->BmagZ, ekf_state->s_qw, ekf_state->s_qx, ekf_state->s_qy, ekf_state->s_qz, ekf_state->s_vN, ekf_state->s_vE, ekf_state->s_vD, ekf_state->s_pN, ekf_state->s_pE, ekf_state->s_pD, ekf_state->s_dBaX, ekf_state->s_dBaY, ekf_state->s_dBaZ, ekf_state->s_dBvZ, ekf_state->s_windX, ekf_state->s_windY, ekf_state->s_magN, ekf_state->s_magE, ekf_state->s_magD, ekf_state->s_BmagX, ekf_state->s_BmagY, ekf_state->s_BmagZ);
}

/**
 * @brief Send a ekf_state message
 * @param chan MAVLink channel to send the message
 *
 * @param time_usec Timestamp
 * @param qw Quaternion qNEDXYZ
 * @param qx Quaternion qNEDXYZ
 * @param qy Quaternion qNEDXYZ
 * @param qz Quaternion qNEDXYZ
 * @param vN Velocity N-Direction (NED-Frame)
 * @param vE Velocity E-Direction (NED-Frame)
 * @param vD Velocity D-Direction (NED-Frame)
 * @param pN Position N-Direction (NED-Frame)
 * @param pE Position E-Direction (NED-Frame)
 * @param pD Position D-Direction (NED-Frame)
 * @param dBaX Delta Angle Bias in X-Direction (XYZ-Frame)
 * @param dBaY Delta Angle Bias in Y-Direction (XYZ-Frame)
 * @param dBaZ Delta Angle Bias in Z-Direction (XYZ-Frame)
 * @param dBvZ Delta Velocity Bias in Z-Direction (XYZ-Frame)
 * @param windX Wind Estimate in X-Direction (XYZ-Frame)
 * @param windY Wind Estimate in Y-Direction (XYZ-Frame)
 * @param magN Magnetic Vector in N-Direction (NED-Frame)
 * @param magE Magnetic Vector In E-Direction (NED-Frame)
 * @param magD Magnetic Vector In D-Direction (NED-Frame)
 * @param BmagX Magnetic Vector Bias in X-Direction (XYZ-Frame)
 * @param BmagY Magnetic Vector Bias in Y-Direction (XYZ-Frame)
 * @param BmagZ Magnetic Vector Bias in Z-Direction (XYZ-Frame)
 * @param s_qw Sigma: Quaternion qNEDXYZ
 * @param s_qx Sigma: Quaternion qNEDXYZ
 * @param s_qy Sigma: Quaternion qNEDXYZ
 * @param s_qz Sigma: Quaternion qNEDXYZ
 * @param s_vN Sigma: Velocity N-Direction (NED-Frame)
 * @param s_vE Sigma: Velocity E-Direction (NED-Frame)
 * @param s_vD Sigma: Velocity D-Direction (NED-Frame)
 * @param s_pN Sigma: Position N-Direction (NED-Frame)
 * @param s_pE Sigma: Position E-Direction (NED-Frame)
 * @param s_pD Sigma: Position D-Direction (NED-Frame)
 * @param s_dBaX Sigma: Delta Angle Bias in X-Direction (XYZ-Frame)
 * @param s_dBaY Sigma: Delta Angle Bias in Y-Direction (XYZ-Frame)
 * @param s_dBaZ Sigma: Delta Angle Bias in Z-Direction (XYZ-Frame)
 * @param s_dBvZ Sigma: Delta Velocity Bias in Z-Direction (XYZ-Frame)
 * @param s_windX Sigma: Wind Estimate in X-Direction (XYZ-Frame)
 * @param s_windY Sigma: Wind Estimate in Y-Direction (XYZ-Frame)
 * @param s_magN Sigma: Magnetic Vector in N-Direction (NED-Frame)
 * @param s_magE Sigma: Magnetic Vector in E-Direction (NED-Frame)
 * @param s_magD Sigma: Magnetic Vector in D-Direction (NED-Frame)
 * @param s_BmagX Sigma: Magnetic Vector Bias in X-Direction (XYZ-Frame)
 * @param s_BmagY Sigma: Magnetic Vector Bias in Y-Direction (XYZ-Frame)
 * @param s_BmagZ Sigma: Magnetic Vector Bias in Z-Direction (XYZ-Frame)
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_ekf_state_send(mavlink_channel_t chan, uint64_t time_usec, float qw, float qx, float qy, float qz, float vN, float vE, float vD, float pN, float pE, float pD, float dBaX, float dBaY, float dBaZ, float dBvZ, float windX, float windY, float magN, float magE, float magD, float BmagX, float BmagY, float BmagZ, float s_qw, float s_qx, float s_qy, float s_qz, float s_vN, float s_vE, float s_vD, float s_pN, float s_pE, float s_pD, float s_dBaX, float s_dBaY, float s_dBaZ, float s_dBvZ, float s_windX, float s_windY, float s_magN, float s_magE, float s_magD, float s_BmagX, float s_BmagY, float s_BmagZ)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char buf[MAVLINK_MSG_ID_EKF_STATE_LEN];
	_mav_put_uint64_t(buf, 0, time_usec);
	_mav_put_float(buf, 8, qw);
	_mav_put_float(buf, 12, qx);
	_mav_put_float(buf, 16, qy);
	_mav_put_float(buf, 20, qz);
	_mav_put_float(buf, 24, vN);
	_mav_put_float(buf, 28, vE);
	_mav_put_float(buf, 32, vD);
	_mav_put_float(buf, 36, pN);
	_mav_put_float(buf, 40, pE);
	_mav_put_float(buf, 44, pD);
	_mav_put_float(buf, 48, dBaX);
	_mav_put_float(buf, 52, dBaY);
	_mav_put_float(buf, 56, dBaZ);
	_mav_put_float(buf, 60, dBvZ);
	_mav_put_float(buf, 64, windX);
	_mav_put_float(buf, 68, windY);
	_mav_put_float(buf, 72, magN);
	_mav_put_float(buf, 76, magE);
	_mav_put_float(buf, 80, magD);
	_mav_put_float(buf, 84, BmagX);
	_mav_put_float(buf, 88, BmagY);
	_mav_put_float(buf, 92, BmagZ);
	_mav_put_float(buf, 96, s_qw);
	_mav_put_float(buf, 100, s_qx);
	_mav_put_float(buf, 104, s_qy);
	_mav_put_float(buf, 108, s_qz);
	_mav_put_float(buf, 112, s_vN);
	_mav_put_float(buf, 116, s_vE);
	_mav_put_float(buf, 120, s_vD);
	_mav_put_float(buf, 124, s_pN);
	_mav_put_float(buf, 128, s_pE);
	_mav_put_float(buf, 132, s_pD);
	_mav_put_float(buf, 136, s_dBaX);
	_mav_put_float(buf, 140, s_dBaY);
	_mav_put_float(buf, 144, s_dBaZ);
	_mav_put_float(buf, 148, s_dBvZ);
	_mav_put_float(buf, 152, s_windX);
	_mav_put_float(buf, 156, s_windY);
	_mav_put_float(buf, 160, s_magN);
	_mav_put_float(buf, 164, s_magE);
	_mav_put_float(buf, 168, s_magD);
	_mav_put_float(buf, 172, s_BmagX);
	_mav_put_float(buf, 176, s_BmagY);
	_mav_put_float(buf, 180, s_BmagZ);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_EKF_STATE, buf, MAVLINK_MSG_ID_EKF_STATE_LEN, MAVLINK_MSG_ID_EKF_STATE_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_EKF_STATE, buf, MAVLINK_MSG_ID_EKF_STATE_LEN);
#endif
#else
	mavlink_ekf_state_t packet;
	packet.time_usec = time_usec;
	packet.qw = qw;
	packet.qx = qx;
	packet.qy = qy;
	packet.qz = qz;
	packet.vN = vN;
	packet.vE = vE;
	packet.vD = vD;
	packet.pN = pN;
	packet.pE = pE;
	packet.pD = pD;
	packet.dBaX = dBaX;
	packet.dBaY = dBaY;
	packet.dBaZ = dBaZ;
	packet.dBvZ = dBvZ;
	packet.windX = windX;
	packet.windY = windY;
	packet.magN = magN;
	packet.magE = magE;
	packet.magD = magD;
	packet.BmagX = BmagX;
	packet.BmagY = BmagY;
	packet.BmagZ = BmagZ;
	packet.s_qw = s_qw;
	packet.s_qx = s_qx;
	packet.s_qy = s_qy;
	packet.s_qz = s_qz;
	packet.s_vN = s_vN;
	packet.s_vE = s_vE;
	packet.s_vD = s_vD;
	packet.s_pN = s_pN;
	packet.s_pE = s_pE;
	packet.s_pD = s_pD;
	packet.s_dBaX = s_dBaX;
	packet.s_dBaY = s_dBaY;
	packet.s_dBaZ = s_dBaZ;
	packet.s_dBvZ = s_dBvZ;
	packet.s_windX = s_windX;
	packet.s_windY = s_windY;
	packet.s_magN = s_magN;
	packet.s_magE = s_magE;
	packet.s_magD = s_magD;
	packet.s_BmagX = s_BmagX;
	packet.s_BmagY = s_BmagY;
	packet.s_BmagZ = s_BmagZ;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_EKF_STATE, (const char *)&packet, MAVLINK_MSG_ID_EKF_STATE_LEN, MAVLINK_MSG_ID_EKF_STATE_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_EKF_STATE, (const char *)&packet, MAVLINK_MSG_ID_EKF_STATE_LEN);
#endif
#endif
}

#if MAVLINK_MSG_ID_EKF_STATE_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_ekf_state_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint64_t time_usec, float qw, float qx, float qy, float qz, float vN, float vE, float vD, float pN, float pE, float pD, float dBaX, float dBaY, float dBaZ, float dBvZ, float windX, float windY, float magN, float magE, float magD, float BmagX, float BmagY, float BmagZ, float s_qw, float s_qx, float s_qy, float s_qz, float s_vN, float s_vE, float s_vD, float s_pN, float s_pE, float s_pD, float s_dBaX, float s_dBaY, float s_dBaZ, float s_dBvZ, float s_windX, float s_windY, float s_magN, float s_magE, float s_magD, float s_BmagX, float s_BmagY, float s_BmagZ)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
	char *buf = (char *)msgbuf;
	_mav_put_uint64_t(buf, 0, time_usec);
	_mav_put_float(buf, 8, qw);
	_mav_put_float(buf, 12, qx);
	_mav_put_float(buf, 16, qy);
	_mav_put_float(buf, 20, qz);
	_mav_put_float(buf, 24, vN);
	_mav_put_float(buf, 28, vE);
	_mav_put_float(buf, 32, vD);
	_mav_put_float(buf, 36, pN);
	_mav_put_float(buf, 40, pE);
	_mav_put_float(buf, 44, pD);
	_mav_put_float(buf, 48, dBaX);
	_mav_put_float(buf, 52, dBaY);
	_mav_put_float(buf, 56, dBaZ);
	_mav_put_float(buf, 60, dBvZ);
	_mav_put_float(buf, 64, windX);
	_mav_put_float(buf, 68, windY);
	_mav_put_float(buf, 72, magN);
	_mav_put_float(buf, 76, magE);
	_mav_put_float(buf, 80, magD);
	_mav_put_float(buf, 84, BmagX);
	_mav_put_float(buf, 88, BmagY);
	_mav_put_float(buf, 92, BmagZ);
	_mav_put_float(buf, 96, s_qw);
	_mav_put_float(buf, 100, s_qx);
	_mav_put_float(buf, 104, s_qy);
	_mav_put_float(buf, 108, s_qz);
	_mav_put_float(buf, 112, s_vN);
	_mav_put_float(buf, 116, s_vE);
	_mav_put_float(buf, 120, s_vD);
	_mav_put_float(buf, 124, s_pN);
	_mav_put_float(buf, 128, s_pE);
	_mav_put_float(buf, 132, s_pD);
	_mav_put_float(buf, 136, s_dBaX);
	_mav_put_float(buf, 140, s_dBaY);
	_mav_put_float(buf, 144, s_dBaZ);
	_mav_put_float(buf, 148, s_dBvZ);
	_mav_put_float(buf, 152, s_windX);
	_mav_put_float(buf, 156, s_windY);
	_mav_put_float(buf, 160, s_magN);
	_mav_put_float(buf, 164, s_magE);
	_mav_put_float(buf, 168, s_magD);
	_mav_put_float(buf, 172, s_BmagX);
	_mav_put_float(buf, 176, s_BmagY);
	_mav_put_float(buf, 180, s_BmagZ);

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_EKF_STATE, buf, MAVLINK_MSG_ID_EKF_STATE_LEN, MAVLINK_MSG_ID_EKF_STATE_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_EKF_STATE, buf, MAVLINK_MSG_ID_EKF_STATE_LEN);
#endif
#else
	mavlink_ekf_state_t *packet = (mavlink_ekf_state_t *)msgbuf;
	packet->time_usec = time_usec;
	packet->qw = qw;
	packet->qx = qx;
	packet->qy = qy;
	packet->qz = qz;
	packet->vN = vN;
	packet->vE = vE;
	packet->vD = vD;
	packet->pN = pN;
	packet->pE = pE;
	packet->pD = pD;
	packet->dBaX = dBaX;
	packet->dBaY = dBaY;
	packet->dBaZ = dBaZ;
	packet->dBvZ = dBvZ;
	packet->windX = windX;
	packet->windY = windY;
	packet->magN = magN;
	packet->magE = magE;
	packet->magD = magD;
	packet->BmagX = BmagX;
	packet->BmagY = BmagY;
	packet->BmagZ = BmagZ;
	packet->s_qw = s_qw;
	packet->s_qx = s_qx;
	packet->s_qy = s_qy;
	packet->s_qz = s_qz;
	packet->s_vN = s_vN;
	packet->s_vE = s_vE;
	packet->s_vD = s_vD;
	packet->s_pN = s_pN;
	packet->s_pE = s_pE;
	packet->s_pD = s_pD;
	packet->s_dBaX = s_dBaX;
	packet->s_dBaY = s_dBaY;
	packet->s_dBaZ = s_dBaZ;
	packet->s_dBvZ = s_dBvZ;
	packet->s_windX = s_windX;
	packet->s_windY = s_windY;
	packet->s_magN = s_magN;
	packet->s_magE = s_magE;
	packet->s_magD = s_magD;
	packet->s_BmagX = s_BmagX;
	packet->s_BmagY = s_BmagY;
	packet->s_BmagZ = s_BmagZ;

#if MAVLINK_CRC_EXTRA
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_EKF_STATE, (const char *)packet, MAVLINK_MSG_ID_EKF_STATE_LEN, MAVLINK_MSG_ID_EKF_STATE_CRC);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_EKF_STATE, (const char *)packet, MAVLINK_MSG_ID_EKF_STATE_LEN);
#endif
#endif
}
#endif

#endif

// MESSAGE EKF_STATE UNPACKING


/**
 * @brief Get field time_usec from ekf_state message
 *
 * @return Timestamp
 */
static inline uint64_t mavlink_msg_ekf_state_get_time_usec(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_uint64_t(msg,  0);
#else
	return mav_get_uint64_t_c2000(&(msg->payload64[0]),  0);
#endif
}

/**
 * @brief Get field qw from ekf_state message
 *
 * @return Quaternion qNEDXYZ
 */
static inline float mavlink_msg_ekf_state_get_qw(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  8);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  8);
#endif
}

/**
 * @brief Get field qx from ekf_state message
 *
 * @return Quaternion qNEDXYZ
 */
static inline float mavlink_msg_ekf_state_get_qx(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  12);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  12);
#endif
}

/**
 * @brief Get field qy from ekf_state message
 *
 * @return Quaternion qNEDXYZ
 */
static inline float mavlink_msg_ekf_state_get_qy(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  16);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  16);
#endif
}

/**
 * @brief Get field qz from ekf_state message
 *
 * @return Quaternion qNEDXYZ
 */
static inline float mavlink_msg_ekf_state_get_qz(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  20);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  20);
#endif
}

/**
 * @brief Get field vN from ekf_state message
 *
 * @return Velocity N-Direction (NED-Frame)
 */
static inline float mavlink_msg_ekf_state_get_vN(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  24);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  24);
#endif
}

/**
 * @brief Get field vE from ekf_state message
 *
 * @return Velocity E-Direction (NED-Frame)
 */
static inline float mavlink_msg_ekf_state_get_vE(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  28);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  28);
#endif
}

/**
 * @brief Get field vD from ekf_state message
 *
 * @return Velocity D-Direction (NED-Frame)
 */
static inline float mavlink_msg_ekf_state_get_vD(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  32);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  32);
#endif
}

/**
 * @brief Get field pN from ekf_state message
 *
 * @return Position N-Direction (NED-Frame)
 */
static inline float mavlink_msg_ekf_state_get_pN(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  36);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  36);
#endif
}

/**
 * @brief Get field pE from ekf_state message
 *
 * @return Position E-Direction (NED-Frame)
 */
static inline float mavlink_msg_ekf_state_get_pE(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  40);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  40);
#endif
}

/**
 * @brief Get field pD from ekf_state message
 *
 * @return Position D-Direction (NED-Frame)
 */
static inline float mavlink_msg_ekf_state_get_pD(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  44);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  44);
#endif
}

/**
 * @brief Get field dBaX from ekf_state message
 *
 * @return Delta Angle Bias in X-Direction (XYZ-Frame)
 */
static inline float mavlink_msg_ekf_state_get_dBaX(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  48);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  48);
#endif
}

/**
 * @brief Get field dBaY from ekf_state message
 *
 * @return Delta Angle Bias in Y-Direction (XYZ-Frame)
 */
static inline float mavlink_msg_ekf_state_get_dBaY(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  52);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  52);
#endif
}

/**
 * @brief Get field dBaZ from ekf_state message
 *
 * @return Delta Angle Bias in Z-Direction (XYZ-Frame)
 */
static inline float mavlink_msg_ekf_state_get_dBaZ(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  56);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  56);
#endif
}

/**
 * @brief Get field dBvZ from ekf_state message
 *
 * @return Delta Velocity Bias in Z-Direction (XYZ-Frame)
 */
static inline float mavlink_msg_ekf_state_get_dBvZ(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  60);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  60);
#endif
}

/**
 * @brief Get field windX from ekf_state message
 *
 * @return Wind Estimate in X-Direction (XYZ-Frame)
 */
static inline float mavlink_msg_ekf_state_get_windX(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  64);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  64);
#endif
}

/**
 * @brief Get field windY from ekf_state message
 *
 * @return Wind Estimate in Y-Direction (XYZ-Frame)
 */
static inline float mavlink_msg_ekf_state_get_windY(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  68);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  68);
#endif
}

/**
 * @brief Get field magN from ekf_state message
 *
 * @return Magnetic Vector in N-Direction (NED-Frame)
 */
static inline float mavlink_msg_ekf_state_get_magN(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  72);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  72);
#endif
}

/**
 * @brief Get field magE from ekf_state message
 *
 * @return Magnetic Vector In E-Direction (NED-Frame)
 */
static inline float mavlink_msg_ekf_state_get_magE(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  76);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  76);
#endif
}

/**
 * @brief Get field magD from ekf_state message
 *
 * @return Magnetic Vector In D-Direction (NED-Frame)
 */
static inline float mavlink_msg_ekf_state_get_magD(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  80);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  80);
#endif
}

/**
 * @brief Get field BmagX from ekf_state message
 *
 * @return Magnetic Vector Bias in X-Direction (XYZ-Frame)
 */
static inline float mavlink_msg_ekf_state_get_BmagX(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  84);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  84);
#endif
}

/**
 * @brief Get field BmagY from ekf_state message
 *
 * @return Magnetic Vector Bias in Y-Direction (XYZ-Frame)
 */
static inline float mavlink_msg_ekf_state_get_BmagY(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  88);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  88);
#endif
}

/**
 * @brief Get field BmagZ from ekf_state message
 *
 * @return Magnetic Vector Bias in Z-Direction (XYZ-Frame)
 */
static inline float mavlink_msg_ekf_state_get_BmagZ(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  92);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  92);
#endif
}

/**
 * @brief Get field s_qw from ekf_state message
 *
 * @return Sigma: Quaternion qNEDXYZ
 */
static inline float mavlink_msg_ekf_state_get_s_qw(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  96);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  96);
#endif
}

/**
 * @brief Get field s_qx from ekf_state message
 *
 * @return Sigma: Quaternion qNEDXYZ
 */
static inline float mavlink_msg_ekf_state_get_s_qx(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  100);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  100);
#endif
}

/**
 * @brief Get field s_qy from ekf_state message
 *
 * @return Sigma: Quaternion qNEDXYZ
 */
static inline float mavlink_msg_ekf_state_get_s_qy(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  104);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  104);
#endif
}

/**
 * @brief Get field s_qz from ekf_state message
 *
 * @return Sigma: Quaternion qNEDXYZ
 */
static inline float mavlink_msg_ekf_state_get_s_qz(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  108);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  108);
#endif
}

/**
 * @brief Get field s_vN from ekf_state message
 *
 * @return Sigma: Velocity N-Direction (NED-Frame)
 */
static inline float mavlink_msg_ekf_state_get_s_vN(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  112);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  112);
#endif
}

/**
 * @brief Get field s_vE from ekf_state message
 *
 * @return Sigma: Velocity E-Direction (NED-Frame)
 */
static inline float mavlink_msg_ekf_state_get_s_vE(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  116);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  116);
#endif
}

/**
 * @brief Get field s_vD from ekf_state message
 *
 * @return Sigma: Velocity D-Direction (NED-Frame)
 */
static inline float mavlink_msg_ekf_state_get_s_vD(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  120);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  120);
#endif
}

/**
 * @brief Get field s_pN from ekf_state message
 *
 * @return Sigma: Position N-Direction (NED-Frame)
 */
static inline float mavlink_msg_ekf_state_get_s_pN(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  124);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  124);
#endif
}

/**
 * @brief Get field s_pE from ekf_state message
 *
 * @return Sigma: Position E-Direction (NED-Frame)
 */
static inline float mavlink_msg_ekf_state_get_s_pE(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  128);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  128);
#endif
}

/**
 * @brief Get field s_pD from ekf_state message
 *
 * @return Sigma: Position D-Direction (NED-Frame)
 */
static inline float mavlink_msg_ekf_state_get_s_pD(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  132);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  132);
#endif
}

/**
 * @brief Get field s_dBaX from ekf_state message
 *
 * @return Sigma: Delta Angle Bias in X-Direction (XYZ-Frame)
 */
static inline float mavlink_msg_ekf_state_get_s_dBaX(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  136);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  136);
#endif
}

/**
 * @brief Get field s_dBaY from ekf_state message
 *
 * @return Sigma: Delta Angle Bias in Y-Direction (XYZ-Frame)
 */
static inline float mavlink_msg_ekf_state_get_s_dBaY(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  140);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  140);
#endif
}

/**
 * @brief Get field s_dBaZ from ekf_state message
 *
 * @return Sigma: Delta Angle Bias in Z-Direction (XYZ-Frame)
 */
static inline float mavlink_msg_ekf_state_get_s_dBaZ(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  144);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  144);
#endif
}

/**
 * @brief Get field s_dBvZ from ekf_state message
 *
 * @return Sigma: Delta Velocity Bias in Z-Direction (XYZ-Frame)
 */
static inline float mavlink_msg_ekf_state_get_s_dBvZ(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  148);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  148);
#endif
}

/**
 * @brief Get field s_windX from ekf_state message
 *
 * @return Sigma: Wind Estimate in X-Direction (XYZ-Frame)
 */
static inline float mavlink_msg_ekf_state_get_s_windX(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  152);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  152);
#endif
}

/**
 * @brief Get field s_windY from ekf_state message
 *
 * @return Sigma: Wind Estimate in Y-Direction (XYZ-Frame)
 */
static inline float mavlink_msg_ekf_state_get_s_windY(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  156);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  156);
#endif
}

/**
 * @brief Get field s_magN from ekf_state message
 *
 * @return Sigma: Magnetic Vector in N-Direction (NED-Frame)
 */
static inline float mavlink_msg_ekf_state_get_s_magN(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  160);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  160);
#endif
}

/**
 * @brief Get field s_magE from ekf_state message
 *
 * @return Sigma: Magnetic Vector in E-Direction (NED-Frame)
 */
static inline float mavlink_msg_ekf_state_get_s_magE(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  164);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  164);
#endif
}

/**
 * @brief Get field s_magD from ekf_state message
 *
 * @return Sigma: Magnetic Vector in D-Direction (NED-Frame)
 */
static inline float mavlink_msg_ekf_state_get_s_magD(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  168);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  168);
#endif
}

/**
 * @brief Get field s_BmagX from ekf_state message
 *
 * @return Sigma: Magnetic Vector Bias in X-Direction (XYZ-Frame)
 */
static inline float mavlink_msg_ekf_state_get_s_BmagX(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  172);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  172);
#endif
}

/**
 * @brief Get field s_BmagY from ekf_state message
 *
 * @return Sigma: Magnetic Vector Bias in Y-Direction (XYZ-Frame)
 */
static inline float mavlink_msg_ekf_state_get_s_BmagY(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  176);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  176);
#endif
}

/**
 * @brief Get field s_BmagZ from ekf_state message
 *
 * @return Sigma: Magnetic Vector Bias in Z-Direction (XYZ-Frame)
 */
static inline float mavlink_msg_ekf_state_get_s_BmagZ(const mavlink_message_t* msg)
{
#if !MAVLINK_C2000
	return _MAV_RETURN_float(msg,  180);
#else
	return mav_get_float_c2000(&(msg->payload64[0]),  180);
#endif
}

/**
 * @brief Decode a ekf_state message into a struct
 *
 * @param msg The message to decode
 * @param ekf_state C-struct to decode the message contents into
 */
static inline void mavlink_msg_ekf_state_decode(const mavlink_message_t* msg, mavlink_ekf_state_t* ekf_state)
{
#if MAVLINK_NEED_BYTE_SWAP || MAVLINK_C2000
	ekf_state->time_usec = mavlink_msg_ekf_state_get_time_usec(msg);
	ekf_state->qw = mavlink_msg_ekf_state_get_qw(msg);
	ekf_state->qx = mavlink_msg_ekf_state_get_qx(msg);
	ekf_state->qy = mavlink_msg_ekf_state_get_qy(msg);
	ekf_state->qz = mavlink_msg_ekf_state_get_qz(msg);
	ekf_state->vN = mavlink_msg_ekf_state_get_vN(msg);
	ekf_state->vE = mavlink_msg_ekf_state_get_vE(msg);
	ekf_state->vD = mavlink_msg_ekf_state_get_vD(msg);
	ekf_state->pN = mavlink_msg_ekf_state_get_pN(msg);
	ekf_state->pE = mavlink_msg_ekf_state_get_pE(msg);
	ekf_state->pD = mavlink_msg_ekf_state_get_pD(msg);
	ekf_state->dBaX = mavlink_msg_ekf_state_get_dBaX(msg);
	ekf_state->dBaY = mavlink_msg_ekf_state_get_dBaY(msg);
	ekf_state->dBaZ = mavlink_msg_ekf_state_get_dBaZ(msg);
	ekf_state->dBvZ = mavlink_msg_ekf_state_get_dBvZ(msg);
	ekf_state->windX = mavlink_msg_ekf_state_get_windX(msg);
	ekf_state->windY = mavlink_msg_ekf_state_get_windY(msg);
	ekf_state->magN = mavlink_msg_ekf_state_get_magN(msg);
	ekf_state->magE = mavlink_msg_ekf_state_get_magE(msg);
	ekf_state->magD = mavlink_msg_ekf_state_get_magD(msg);
	ekf_state->BmagX = mavlink_msg_ekf_state_get_BmagX(msg);
	ekf_state->BmagY = mavlink_msg_ekf_state_get_BmagY(msg);
	ekf_state->BmagZ = mavlink_msg_ekf_state_get_BmagZ(msg);
	ekf_state->s_qw = mavlink_msg_ekf_state_get_s_qw(msg);
	ekf_state->s_qx = mavlink_msg_ekf_state_get_s_qx(msg);
	ekf_state->s_qy = mavlink_msg_ekf_state_get_s_qy(msg);
	ekf_state->s_qz = mavlink_msg_ekf_state_get_s_qz(msg);
	ekf_state->s_vN = mavlink_msg_ekf_state_get_s_vN(msg);
	ekf_state->s_vE = mavlink_msg_ekf_state_get_s_vE(msg);
	ekf_state->s_vD = mavlink_msg_ekf_state_get_s_vD(msg);
	ekf_state->s_pN = mavlink_msg_ekf_state_get_s_pN(msg);
	ekf_state->s_pE = mavlink_msg_ekf_state_get_s_pE(msg);
	ekf_state->s_pD = mavlink_msg_ekf_state_get_s_pD(msg);
	ekf_state->s_dBaX = mavlink_msg_ekf_state_get_s_dBaX(msg);
	ekf_state->s_dBaY = mavlink_msg_ekf_state_get_s_dBaY(msg);
	ekf_state->s_dBaZ = mavlink_msg_ekf_state_get_s_dBaZ(msg);
	ekf_state->s_dBvZ = mavlink_msg_ekf_state_get_s_dBvZ(msg);
	ekf_state->s_windX = mavlink_msg_ekf_state_get_s_windX(msg);
	ekf_state->s_windY = mavlink_msg_ekf_state_get_s_windY(msg);
	ekf_state->s_magN = mavlink_msg_ekf_state_get_s_magN(msg);
	ekf_state->s_magE = mavlink_msg_ekf_state_get_s_magE(msg);
	ekf_state->s_magD = mavlink_msg_ekf_state_get_s_magD(msg);
	ekf_state->s_BmagX = mavlink_msg_ekf_state_get_s_BmagX(msg);
	ekf_state->s_BmagY = mavlink_msg_ekf_state_get_s_BmagY(msg);
	ekf_state->s_BmagZ = mavlink_msg_ekf_state_get_s_BmagZ(msg);
#else
	memcpy(ekf_state, _MAV_PAYLOAD(msg), MAVLINK_MSG_ID_EKF_STATE_LEN);
#endif
}
