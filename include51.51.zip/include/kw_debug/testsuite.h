/** @file
 *	@brief MAVLink comm protocol testsuite generated from kw_debug.xml
 *	@see http://qgroundcontrol.org/mavlink/
 */
#ifndef KW_DEBUG_TESTSUITE_H
#define KW_DEBUG_TESTSUITE_H

#ifdef __cplusplus
extern "C" {
#endif

#ifndef MAVLINK_TEST_ALL
#define MAVLINK_TEST_ALL

static void mavlink_test_kw_debug(uint8_t, uint8_t, mavlink_message_t *last_msg);

static void mavlink_test_all(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{

	mavlink_test_kw_debug(system_id, component_id, last_msg);
}
#endif




static void mavlink_test_ekf_state(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
	mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
	mavlink_ekf_state_t packet_in = {
		93372036854775807ULL,73.0,101.0,129.0,157.0,185.0,213.0,241.0,269.0,297.0,325.0,353.0,381.0,409.0,437.0,465.0,493.0,521.0,549.0,577.0,605.0,633.0,661.0,689.0,717.0,745.0,773.0,801.0,829.0,857.0,885.0,913.0,941.0,969.0,997.0,1025.0,1053.0,1081.0,1109.0,1137.0,1165.0,1193.0,1221.0,1249.0,1277.0
    };
	mavlink_ekf_state_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        	packet1.time_usec = packet_in.time_usec;
        	packet1.qw = packet_in.qw;
        	packet1.qx = packet_in.qx;
        	packet1.qy = packet_in.qy;
        	packet1.qz = packet_in.qz;
        	packet1.vN = packet_in.vN;
        	packet1.vE = packet_in.vE;
        	packet1.vD = packet_in.vD;
        	packet1.pN = packet_in.pN;
        	packet1.pE = packet_in.pE;
        	packet1.pD = packet_in.pD;
        	packet1.dBaX = packet_in.dBaX;
        	packet1.dBaY = packet_in.dBaY;
        	packet1.dBaZ = packet_in.dBaZ;
        	packet1.dBvZ = packet_in.dBvZ;
        	packet1.windX = packet_in.windX;
        	packet1.windY = packet_in.windY;
        	packet1.magN = packet_in.magN;
        	packet1.magE = packet_in.magE;
        	packet1.magD = packet_in.magD;
        	packet1.BmagX = packet_in.BmagX;
        	packet1.BmagY = packet_in.BmagY;
        	packet1.BmagZ = packet_in.BmagZ;
        	packet1.s_qw = packet_in.s_qw;
        	packet1.s_qx = packet_in.s_qx;
        	packet1.s_qy = packet_in.s_qy;
        	packet1.s_qz = packet_in.s_qz;
        	packet1.s_vN = packet_in.s_vN;
        	packet1.s_vE = packet_in.s_vE;
        	packet1.s_vD = packet_in.s_vD;
        	packet1.s_pN = packet_in.s_pN;
        	packet1.s_pE = packet_in.s_pE;
        	packet1.s_pD = packet_in.s_pD;
        	packet1.s_dBaX = packet_in.s_dBaX;
        	packet1.s_dBaY = packet_in.s_dBaY;
        	packet1.s_dBaZ = packet_in.s_dBaZ;
        	packet1.s_dBvZ = packet_in.s_dBvZ;
        	packet1.s_windX = packet_in.s_windX;
        	packet1.s_windY = packet_in.s_windY;
        	packet1.s_magN = packet_in.s_magN;
        	packet1.s_magE = packet_in.s_magE;
        	packet1.s_magD = packet_in.s_magD;
        	packet1.s_BmagX = packet_in.s_BmagX;
        	packet1.s_BmagY = packet_in.s_BmagY;
        	packet1.s_BmagZ = packet_in.s_BmagZ;
        
        

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_ekf_state_encode(system_id, component_id, &msg, &packet1);
	mavlink_msg_ekf_state_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_ekf_state_pack(system_id, component_id, &msg , packet1.time_usec , packet1.qw , packet1.qx , packet1.qy , packet1.qz , packet1.vN , packet1.vE , packet1.vD , packet1.pN , packet1.pE , packet1.pD , packet1.dBaX , packet1.dBaY , packet1.dBaZ , packet1.dBvZ , packet1.windX , packet1.windY , packet1.magN , packet1.magE , packet1.magD , packet1.BmagX , packet1.BmagY , packet1.BmagZ , packet1.s_qw , packet1.s_qx , packet1.s_qy , packet1.s_qz , packet1.s_vN , packet1.s_vE , packet1.s_vD , packet1.s_pN , packet1.s_pE , packet1.s_pD , packet1.s_dBaX , packet1.s_dBaY , packet1.s_dBaZ , packet1.s_dBvZ , packet1.s_windX , packet1.s_windY , packet1.s_magN , packet1.s_magE , packet1.s_magD , packet1.s_BmagX , packet1.s_BmagY , packet1.s_BmagZ );
	mavlink_msg_ekf_state_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_ekf_state_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.time_usec , packet1.qw , packet1.qx , packet1.qy , packet1.qz , packet1.vN , packet1.vE , packet1.vD , packet1.pN , packet1.pE , packet1.pD , packet1.dBaX , packet1.dBaY , packet1.dBaZ , packet1.dBvZ , packet1.windX , packet1.windY , packet1.magN , packet1.magE , packet1.magD , packet1.BmagX , packet1.BmagY , packet1.BmagZ , packet1.s_qw , packet1.s_qx , packet1.s_qy , packet1.s_qz , packet1.s_vN , packet1.s_vE , packet1.s_vD , packet1.s_pN , packet1.s_pE , packet1.s_pD , packet1.s_dBaX , packet1.s_dBaY , packet1.s_dBaZ , packet1.s_dBvZ , packet1.s_windX , packet1.s_windY , packet1.s_magN , packet1.s_magE , packet1.s_magD , packet1.s_BmagX , packet1.s_BmagY , packet1.s_BmagZ );
	mavlink_msg_ekf_state_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
        	comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
	mavlink_msg_ekf_state_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_ekf_state_send(MAVLINK_COMM_1 , packet1.time_usec , packet1.qw , packet1.qx , packet1.qy , packet1.qz , packet1.vN , packet1.vE , packet1.vD , packet1.pN , packet1.pE , packet1.pD , packet1.dBaX , packet1.dBaY , packet1.dBaZ , packet1.dBvZ , packet1.windX , packet1.windY , packet1.magN , packet1.magE , packet1.magD , packet1.BmagX , packet1.BmagY , packet1.BmagZ , packet1.s_qw , packet1.s_qx , packet1.s_qy , packet1.s_qz , packet1.s_vN , packet1.s_vE , packet1.s_vD , packet1.s_pN , packet1.s_pE , packet1.s_pD , packet1.s_dBaX , packet1.s_dBaY , packet1.s_dBaZ , packet1.s_dBvZ , packet1.s_windX , packet1.s_windY , packet1.s_magN , packet1.s_magE , packet1.s_magD , packet1.s_BmagX , packet1.s_BmagY , packet1.s_BmagZ );
	mavlink_msg_ekf_state_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
}

static void mavlink_test_ekf_innov(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
	mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
	mavlink_ekf_innov_t packet_in = {
		93372036854775807ULL,73.0,101.0,129.0,157.0,185.0,213.0,241.0,269.0,297.0,325.0,353.0,381.0,409.0,437.0,465.0,493.0,521.0,549.0,577.0,605.0,633.0,661.0,37,104,171,238,49,116
    };
	mavlink_ekf_innov_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        	packet1.time_usec = packet_in.time_usec;
        	packet1.vN = packet_in.vN;
        	packet1.vE = packet_in.vE;
        	packet1.vD = packet_in.vD;
        	packet1.pN = packet_in.pN;
        	packet1.pE = packet_in.pE;
        	packet1.pD = packet_in.pD;
        	packet1.magX = packet_in.magX;
        	packet1.magY = packet_in.magY;
        	packet1.magZ = packet_in.magZ;
        	packet1.vtas = packet_in.vtas;
        	packet1.rng = packet_in.rng;
        	packet1.s_vN = packet_in.s_vN;
        	packet1.s_vE = packet_in.s_vE;
        	packet1.s_vD = packet_in.s_vD;
        	packet1.s_pN = packet_in.s_pN;
        	packet1.s_pE = packet_in.s_pE;
        	packet1.s_pD = packet_in.s_pD;
        	packet1.s_magX = packet_in.s_magX;
        	packet1.s_magY = packet_in.s_magY;
        	packet1.s_magZ = packet_in.s_magZ;
        	packet1.s_vtas = packet_in.s_vtas;
        	packet1.s_rng = packet_in.s_rng;
        	packet1.fused_vNED = packet_in.fused_vNED;
        	packet1.fused_pNE = packet_in.fused_pNE;
        	packet1.fused_pD = packet_in.fused_pD;
        	packet1.fused_magXYZ = packet_in.fused_magXYZ;
        	packet1.fused_vtas = packet_in.fused_vtas;
        	packet1.fused_rng = packet_in.fused_rng;
        
        

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_ekf_innov_encode(system_id, component_id, &msg, &packet1);
	mavlink_msg_ekf_innov_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_ekf_innov_pack(system_id, component_id, &msg , packet1.time_usec , packet1.vN , packet1.vE , packet1.vD , packet1.pN , packet1.pE , packet1.pD , packet1.magX , packet1.magY , packet1.magZ , packet1.vtas , packet1.rng , packet1.s_vN , packet1.s_vE , packet1.s_vD , packet1.s_pN , packet1.s_pE , packet1.s_pD , packet1.s_magX , packet1.s_magY , packet1.s_magZ , packet1.s_vtas , packet1.s_rng , packet1.fused_vNED , packet1.fused_pNE , packet1.fused_pD , packet1.fused_magXYZ , packet1.fused_vtas , packet1.fused_rng );
	mavlink_msg_ekf_innov_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_ekf_innov_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.time_usec , packet1.vN , packet1.vE , packet1.vD , packet1.pN , packet1.pE , packet1.pD , packet1.magX , packet1.magY , packet1.magZ , packet1.vtas , packet1.rng , packet1.s_vN , packet1.s_vE , packet1.s_vD , packet1.s_pN , packet1.s_pE , packet1.s_pD , packet1.s_magX , packet1.s_magY , packet1.s_magZ , packet1.s_vtas , packet1.s_rng , packet1.fused_vNED , packet1.fused_pNE , packet1.fused_pD , packet1.fused_magXYZ , packet1.fused_vtas , packet1.fused_rng );
	mavlink_msg_ekf_innov_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
        	comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
	mavlink_msg_ekf_innov_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_ekf_innov_send(MAVLINK_COMM_1 , packet1.time_usec , packet1.vN , packet1.vE , packet1.vD , packet1.pN , packet1.pE , packet1.pD , packet1.magX , packet1.magY , packet1.magZ , packet1.vtas , packet1.rng , packet1.s_vN , packet1.s_vE , packet1.s_vD , packet1.s_pN , packet1.s_pE , packet1.s_pD , packet1.s_magX , packet1.s_magY , packet1.s_magZ , packet1.s_vtas , packet1.s_rng , packet1.fused_vNED , packet1.fused_pNE , packet1.fused_pD , packet1.fused_magXYZ , packet1.fused_vtas , packet1.fused_rng );
	mavlink_msg_ekf_innov_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
}

static void mavlink_test_baro2(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
	mavlink_message_t msg;
        uint8_t buffer[MAVLINK_MAX_PACKET_LEN];
        uint16_t i;
	mavlink_baro2_t packet_in = {
		93372036854775807ULL,73.0,101.0,129.0,157.0
    };
	mavlink_baro2_t packet1, packet2;
        memset(&packet1, 0, sizeof(packet1));
        	packet1.time_usec = packet_in.time_usec;
        	packet1.abs_pressure = packet_in.abs_pressure;
        	packet1.diff_pressure = packet_in.diff_pressure;
        	packet1.pressure_alt = packet_in.pressure_alt;
        	packet1.temperature = packet_in.temperature;
        
        

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_baro2_encode(system_id, component_id, &msg, &packet1);
	mavlink_msg_baro2_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_baro2_pack(system_id, component_id, &msg , packet1.time_usec , packet1.abs_pressure , packet1.diff_pressure , packet1.pressure_alt , packet1.temperature );
	mavlink_msg_baro2_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_baro2_pack_chan(system_id, component_id, MAVLINK_COMM_0, &msg , packet1.time_usec , packet1.abs_pressure , packet1.diff_pressure , packet1.pressure_alt , packet1.temperature );
	mavlink_msg_baro2_decode(&msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
        mavlink_msg_to_send_buffer(buffer, &msg);
        for (i=0; i<mavlink_msg_get_send_buffer_length(&msg); i++) {
        	comm_send_ch(MAVLINK_COMM_0, buffer[i]);
        }
	mavlink_msg_baro2_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);

        memset(&packet2, 0, sizeof(packet2));
	mavlink_msg_baro2_send(MAVLINK_COMM_1 , packet1.time_usec , packet1.abs_pressure , packet1.diff_pressure , packet1.pressure_alt , packet1.temperature );
	mavlink_msg_baro2_decode(last_msg, &packet2);
        MAVLINK_ASSERT(memcmp(&packet1, &packet2, sizeof(packet1)) == 0);
}

static void mavlink_test_kw_debug(uint8_t system_id, uint8_t component_id, mavlink_message_t *last_msg)
{
	mavlink_test_ekf_state(system_id, component_id, last_msg);
	mavlink_test_ekf_innov(system_id, component_id, last_msg);
	mavlink_test_baro2(system_id, component_id, last_msg);
}

#ifdef __cplusplus
}
#endif // __cplusplus
#endif // KW_DEBUG_TESTSUITE_H
